(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var RestMiddleware = Package['simple:json-routes'].RestMiddleware;
var Accounts = Package['accounts-base'].Accounts;

/* Package-scope variables */
var __coffeescriptShare, ironRouterSendErrorToResponse, msg, Restivus;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/mrest_restivus/lib/auth.coffee.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var getUserQuerySelector, userValidator;

this.Auth || (this.Auth = {});


/*
  A valid user will have exactly one of the following identification fields: id, username, or email
 */

userValidator = Match.Where(function(user) {
  check(user, {
    id: Match.Optional(String),
    username: Match.Optional(String),
    email: Match.Optional(String)
  });
  if (_.keys(user).length === !1) {
    throw new Match.Error('User must have exactly one identifier field');
  }
  return true;
});


/*
  Return a MongoDB query selector for finding the given user
 */

getUserQuerySelector = function(user) {
  if (user.id) {
    return {
      '_id': user.id
    };
  } else if (user.username) {
    return {
      'username': user.username
    };
  } else if (user.email) {
    return {
      'emails.address': user.email
    };
  }
  throw new Error('Cannot create selector from invalid user');
};


/*
  Log a user in with their password
 */

this.Auth.loginWithPassword = function(user, password) {
  var authToken, authenticatingUser, authenticatingUserSelector, hashedToken, passwordVerification, ref;
  if (!user || !password) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  check(user, userValidator);
  check(password, String);
  authenticatingUserSelector = getUserQuerySelector(user);
  authenticatingUser = Meteor.users.findOne(authenticatingUserSelector);
  if (!authenticatingUser) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  if (!((ref = authenticatingUser.services) != null ? ref.password : void 0)) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  passwordVerification = Accounts._checkPassword(authenticatingUser, password);
  if (passwordVerification.error) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  authToken = Accounts._generateStampedLoginToken();
  hashedToken = Accounts._hashLoginToken(authToken.token);
  Accounts._insertHashedLoginToken(authenticatingUser._id, {
    hashedToken: hashedToken
  });
  return {
    authToken: authToken.token,
    userId: authenticatingUser._id
  };
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/mrest_restivus/lib/iron-router-error-to-response.js                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// We need a function that treats thrown errors exactly like Iron Router would.
// This file is written in JavaScript to enable copy-pasting Iron Router code.

// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L3
var env = process.env.NODE_ENV || 'development';

// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L47
ironRouterSendErrorToResponse = function (err, req, res) {
  if (res.statusCode < 400)
    res.statusCode = 500;

  if (err.status)
    res.statusCode = err.status;

  if (env === 'development')
    msg = (err.stack || err.toString()) + '\n';
  else
    //XXX get this from standard dict of error messages?
    msg = 'Server error.';

  console.error(err.stack || err.toString());

  if (res.headersSent)
    return req.socket.destroy();

  res.setHeader('Content-Type', 'text/html');
  res.setHeader('Content-Length', Buffer.byteLength(msg));
  if (req.method === 'HEAD')
    return res.end();
  res.end(msg);
  return;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/mrest_restivus/lib/route.coffee.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.Route = (function() {
  function Route(api, path, options, endpoints1) {
    this.api = api;
    this.path = path;
    this.options = options;
    this.endpoints = endpoints1;
    if (!this.endpoints) {
      this.endpoints = this.options;
      this.options = {};
    }
  }

  Route.prototype.addToApi = (function() {
    var availableMethods;
    availableMethods = ['get', 'post', 'put', 'patch', 'delete', 'options'];
    return function() {
      var allowedMethods, fullPath, rejectedMethods, self;
      self = this;
      if (_.contains(this.api._config.paths, this.path)) {
        throw new Error("Cannot add a route at an existing path: " + this.path);
      }
      this.endpoints = _.extend({
        options: this.api._config.defaultOptionsEndpoint
      }, this.endpoints);
      this._resolveEndpoints();
      this._configureEndpoints();
      this.api._config.paths.push(this.path);
      allowedMethods = _.filter(availableMethods, function(method) {
        return _.contains(_.keys(self.endpoints), method);
      });
      rejectedMethods = _.reject(availableMethods, function(method) {
        return _.contains(_.keys(self.endpoints), method);
      });
      fullPath = this.api._config.apiPath + this.path;
      _.each(allowedMethods, function(method) {
        var endpoint;
        endpoint = self.endpoints[method];
        return JsonRoutes.add(method, fullPath, function(req, res) {
          var doneFunc, endpointContext, error, responseData, responseInitiated;
          responseInitiated = false;
          doneFunc = function() {
            return responseInitiated = true;
          };
          endpointContext = {
            urlParams: req.params,
            queryParams: req.query,
            bodyParams: req.body,
            request: req,
            response: res,
            done: doneFunc
          };
          _.extend(endpointContext, endpoint);
          responseData = null;
          try {
            responseData = self._callEndpoint(endpointContext, endpoint);
          } catch (_error) {
            error = _error;
            ironRouterSendErrorToResponse(error, req, res);
            return;
          }
          if (responseInitiated) {
            res.end();
            return;
          } else {
            if (res.headersSent) {
              throw new Error("Must call this.done() after handling endpoint response manually: " + method + " " + fullPath);
            } else if (responseData === null || responseData === void 0) {
              throw new Error("Cannot return null or undefined from an endpoint: " + method + " " + fullPath);
            }
          }
          if (responseData.body && (responseData.statusCode || responseData.headers)) {
            return self._respond(res, responseData.body, responseData.statusCode, responseData.headers);
          } else {
            return self._respond(res, responseData);
          }
        });
      });
      return _.each(rejectedMethods, function(method) {
        return JsonRoutes.add(method, fullPath, function(req, res) {
          var headers, responseData;
          responseData = {
            status: 'error',
            message: 'API endpoint does not exist'
          };
          headers = {
            'Allow': allowedMethods.join(', ').toUpperCase()
          };
          return self._respond(res, responseData, 405, headers);
        });
      });
    };
  })();


  /*
    Convert all endpoints on the given route into our expected endpoint object if it is a bare
    function
  
    @param {Route} route The route the endpoints belong to
   */

  Route.prototype._resolveEndpoints = function() {
    _.each(this.endpoints, function(endpoint, method, endpoints) {
      if (_.isFunction(endpoint)) {
        return endpoints[method] = {
          action: endpoint
        };
      }
    });
  };


  /*
    Configure the authentication and role requirement on all endpoints (except OPTIONS, which must
    be configured directly on the endpoint)
  
    Authentication can be required on an entire route or individual endpoints. If required on an
    entire route, that serves as the default. If required in any individual endpoints, that will
    override the default.
  
    After the endpoint is configured, all authentication and role requirements of an endpoint can be
    accessed at <code>endpoint.authRequired</code> and <code>endpoint.roleRequired</code>,
    respectively.
  
    @param {Route} route The route the endpoints belong to
    @param {Endpoint} endpoint The endpoint to configure
   */

  Route.prototype._configureEndpoints = function() {
    _.each(this.endpoints, function(endpoint, method) {
      var ref, ref1;
      if (method !== 'options') {
        if (!((ref = this.options) != null ? ref.roleRequired : void 0)) {
          this.options.roleRequired = [];
        }
        if (!endpoint.roleRequired) {
          endpoint.roleRequired = [];
        }
        endpoint.roleRequired = _.union(endpoint.roleRequired, this.options.roleRequired);
        if (_.isEmpty(endpoint.roleRequired)) {
          endpoint.roleRequired = false;
        }
        if (endpoint.authRequired === void 0) {
          if (((ref1 = this.options) != null ? ref1.authRequired : void 0) || endpoint.roleRequired) {
            endpoint.authRequired = true;
          } else {
            endpoint.authRequired = false;
          }
        }
      }
    }, this);
  };


  /*
    Authenticate an endpoint if required, and return the result of calling it
  
    @returns The endpoint response or a 401 if authentication fails
   */

  Route.prototype._callEndpoint = function(endpointContext, endpoint) {
    if (this._authAccepted(endpointContext, endpoint)) {
      if (this._roleAccepted(endpointContext, endpoint)) {
        return endpoint.action.call(endpointContext);
      } else {
        return {
          statusCode: 403,
          body: {
            status: 'error',
            message: 'You do not have permission to do this.'
          }
        };
      }
    } else {
      return {
        statusCode: 401,
        body: {
          status: 'error',
          message: 'You must be logged in to do this.'
        }
      };
    }
  };


  /*
    Authenticate the given endpoint if required
  
    Once it's globally configured in the API, authentication can be required on an entire route or
    individual endpoints. If required on an entire endpoint, that serves as the default. If required
    in any individual endpoints, that will override the default.
  
    @returns False if authentication fails, and true otherwise
   */

  Route.prototype._authAccepted = function(endpointContext, endpoint) {
    if (endpoint.authRequired) {
      return this._authenticate(endpointContext);
    } else {
      return true;
    }
  };


  /*
    Verify the request is being made by an actively logged in user
  
    If verified, attach the authenticated user to the context.
  
    @returns {Boolean} True if the authentication was successful
   */

  Route.prototype._authenticate = function(endpointContext) {
    var auth, userSelector;
    auth = this.api._config.auth.user.call(endpointContext);
    if ((auth != null ? auth.userId : void 0) && (auth != null ? auth.token : void 0) && !(auth != null ? auth.user : void 0)) {
      userSelector = {};
      userSelector._id = auth.userId;
      userSelector[this.api._config.auth.token] = auth.token;
      auth.user = Meteor.users.findOne(userSelector);
    }
    if (auth != null ? auth.user : void 0) {
      endpointContext.user = auth.user;
      endpointContext.userId = auth.user._id;
      return true;
    } else {
      return false;
    }
  };


  /*
    Authenticate the user role if required
  
    Must be called after _authAccepted().
  
    @returns True if the authenticated user belongs to <i>any</i> of the acceptable roles on the
             endpoint
   */

  Route.prototype._roleAccepted = function(endpointContext, endpoint) {
    if (endpoint.roleRequired) {
      if (_.isEmpty(_.intersection(endpoint.roleRequired, endpointContext.user.roles))) {
        return false;
      }
    }
    return true;
  };


  /*
    Respond to an HTTP request
   */

  Route.prototype._respond = function(response, body, statusCode, headers) {
    var defaultHeaders, delayInMilliseconds, minimumDelayInMilliseconds, randomMultiplierBetweenOneAndTwo, sendResponse;
    if (statusCode == null) {
      statusCode = 200;
    }
    if (headers == null) {
      headers = {};
    }
    defaultHeaders = this._lowerCaseKeys(this.api._config.defaultHeaders);
    headers = this._lowerCaseKeys(headers);
    headers = _.extend(defaultHeaders, headers);
    if (headers['content-type'].match(/json|javascript/) !== null) {
      if (this.api._config.prettyJson) {
        body = JSON.stringify(body, void 0, 2);
      } else {
        body = JSON.stringify(body);
      }
    }
    sendResponse = function() {
      response.writeHead(statusCode, headers);
      response.write(body);
      return response.end();
    };
    if (statusCode === 401 || statusCode === 403) {
      minimumDelayInMilliseconds = 500;
      randomMultiplierBetweenOneAndTwo = 1 + Math.random();
      delayInMilliseconds = minimumDelayInMilliseconds * randomMultiplierBetweenOneAndTwo;
      return Meteor.setTimeout(sendResponse, delayInMilliseconds);
    } else {
      return sendResponse();
    }
  };


  /*
    Return the object with all of the keys converted to lowercase
   */

  Route.prototype._lowerCaseKeys = function(object) {
    return _.chain(object).pairs().map(function(attr) {
      return [attr[0].toLowerCase(), attr[1]];
    }).object().value();
  };

  return Route;

})();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/mrest_restivus/lib/restivus.coffee.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var          
  indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

this.Restivus = (function() {
  function Restivus(options) {
    var corsHeaders;
    this._routes = [];
    this._config = {
      paths: [],
      useDefaultAuth: false,
      apiPath: 'api/',
      version: null,
      prettyJson: false,
      auth: {
        token: 'services.resume.loginTokens.hashedToken',
        user: function() {
          var token;
          if (this.request.headers['x-auth-token']) {
            token = Accounts._hashLoginToken(this.request.headers['x-auth-token']);
          }
          return {
            userId: this.request.headers['x-user-id'],
            token: token
          };
        }
      },
      defaultHeaders: {
        'Content-Type': 'application/json'
      },
      enableCors: true
    };
    _.extend(this._config, options);
    if (this._config.enableCors) {
      corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
      };
      if (this._config.useDefaultAuth) {
        corsHeaders['Access-Control-Allow-Headers'] += ', X-User-Id, X-Auth-Token';
      }
      _.extend(this._config.defaultHeaders, corsHeaders);
      if (!this._config.defaultOptionsEndpoint) {
        this._config.defaultOptionsEndpoint = function() {
          this.response.writeHead(200, corsHeaders);
          return this.done();
        };
      }
    }
    if (this._config.apiPath[0] === '/') {
      this._config.apiPath = this._config.apiPath.slice(1);
    }
    if (_.last(this._config.apiPath) !== '/') {
      this._config.apiPath = this._config.apiPath + '/';
    }
    if (this._config.version) {
      this._config.apiPath += this._config.version + '/';
    }
    if (this._config.useDefaultAuth) {
      this._initAuth();
    } else if (this._config.useAuth) {
      this._initAuth();
      console.warn('Warning: useAuth API config option will be removed in Restivus v1.0 ' + '\n    Use the useDefaultAuth option instead');
    }
    return this;
  }


  /**
    Add endpoints for the given HTTP methods at the given path
  
    @param path {String} The extended URL path (will be appended to base path of the API)
    @param options {Object} Route configuration options
    @param options.authRequired {Boolean} The default auth requirement for each endpoint on the route
    @param options.roleRequired {String or String[]} The default role required for each endpoint on the route
    @param endpoints {Object} A set of endpoints available on the new route (get, post, put, patch, delete, options)
    @param endpoints.<method> {Function or Object} If a function is provided, all default route
        configuration options will be applied to the endpoint. Otherwise an object with an `action`
        and all other route config options available. An `action` must be provided with the object.
   */

  Restivus.prototype.addRoute = function(path, options, endpoints) {
    var route;
    route = new share.Route(this, path, options, endpoints);
    this._routes.push(route);
    route.addToApi();
    return this;
  };


  /**
    Generate routes for the Meteor Collection with the given name
   */

  Restivus.prototype.addCollection = function(collection, options) {
    var collectionEndpoints, collectionRouteEndpoints, endpointsAwaitingConfiguration, entityRouteEndpoints, excludedEndpoints, methods, methodsOnCollection, path, routeOptions;
    if (options == null) {
      options = {};
    }
    methods = ['get', 'post', 'put', 'delete', 'getAll'];
    methodsOnCollection = ['post', 'getAll'];
    if (collection === Meteor.users) {
      collectionEndpoints = this._userCollectionEndpoints;
    } else {
      collectionEndpoints = this._collectionEndpoints;
    }
    endpointsAwaitingConfiguration = options.endpoints || {};
    routeOptions = options.routeOptions || {};
    excludedEndpoints = options.excludedEndpoints || [];
    path = options.path || collection._name;
    collectionRouteEndpoints = {};
    entityRouteEndpoints = {};
    if (_.isEmpty(endpointsAwaitingConfiguration) && _.isEmpty(excludedEndpoints)) {
      _.each(methods, function(method) {
        if (indexOf.call(methodsOnCollection, method) >= 0) {
          _.extend(collectionRouteEndpoints, collectionEndpoints[method].call(this, collection));
        } else {
          _.extend(entityRouteEndpoints, collectionEndpoints[method].call(this, collection));
        }
      }, this);
    } else {
      _.each(methods, function(method) {
        var configuredEndpoint, endpointOptions;
        if (indexOf.call(excludedEndpoints, method) < 0 && endpointsAwaitingConfiguration[method] !== false) {
          endpointOptions = endpointsAwaitingConfiguration[method];
          configuredEndpoint = {};
          _.each(collectionEndpoints[method].call(this, collection), function(action, methodType) {
            return configuredEndpoint[methodType] = _.chain(action).clone().extend(endpointOptions).value();
          });
          if (indexOf.call(methodsOnCollection, method) >= 0) {
            _.extend(collectionRouteEndpoints, configuredEndpoint);
          } else {
            _.extend(entityRouteEndpoints, configuredEndpoint);
          }
        }
      }, this);
    }
    this.addRoute(path, routeOptions, collectionRouteEndpoints);
    this.addRoute(path + "/:id", routeOptions, entityRouteEndpoints);
    return this;
  };


  /**
    A set of endpoints that can be applied to a Collection Route
   */

  Restivus.prototype._collectionEndpoints = {
    get: function(collection) {
      return {
        get: {
          action: function() {
            var entity;
            entity = collection.findOne(this.urlParams.id);
            if (entity) {
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    put: function(collection) {
      return {
        put: {
          action: function() {
            var entity, entityIsUpdated;
            entityIsUpdated = collection.update(this.urlParams.id, this.bodyParams);
            if (entityIsUpdated) {
              entity = collection.findOne(this.urlParams.id);
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    "delete": function(collection) {
      return {
        "delete": {
          action: function() {
            if (collection.remove(this.urlParams.id)) {
              return {
                status: 'success',
                data: {
                  message: 'Item removed'
                }
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    post: function(collection) {
      return {
        post: {
          action: function() {
            var entity, entityId;
            entityId = collection.insert(this.bodyParams);
            entity = collection.findOne(entityId);
            if (entity) {
              return {
                statusCode: 201,
                body: {
                  status: 'success',
                  data: entity
                }
              };
            } else {
              return {
                statusCode: 400,
                body: {
                  status: 'fail',
                  message: 'No item added'
                }
              };
            }
          }
        }
      };
    },
    getAll: function(collection) {
      return {
        get: {
          action: function() {
            var entities;
            entities = collection.find().fetch();
            if (entities) {
              return {
                status: 'success',
                data: entities
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Unable to retrieve items from collection'
                }
              };
            }
          }
        }
      };
    }
  };


  /**
    A set of endpoints that can be applied to a Meteor.users Collection Route
   */

  Restivus.prototype._userCollectionEndpoints = {
    get: function(collection) {
      return {
        get: {
          action: function() {
            var entity;
            entity = collection.findOne(this.urlParams.id, {
              fields: {
                profile: 1
              }
            });
            if (entity) {
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    put: function(collection) {
      return {
        put: {
          action: function() {
            var entity, entityIsUpdated;
            entityIsUpdated = collection.update(this.urlParams.id, {
              $set: {
                profile: this.bodyParams
              }
            });
            if (entityIsUpdated) {
              entity = collection.findOne(this.urlParams.id, {
                fields: {
                  profile: 1
                }
              });
              return {
                status: "success",
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    "delete": function(collection) {
      return {
        "delete": {
          action: function() {
            if (collection.remove(this.urlParams.id)) {
              return {
                status: 'success',
                data: {
                  message: 'User removed'
                }
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    post: function(collection) {
      return {
        post: {
          action: function() {
            var entity, entityId;
            entityId = Accounts.createUser(this.bodyParams);
            entity = collection.findOne(entityId, {
              fields: {
                profile: 1
              }
            });
            if (entity) {
              return {
                statusCode: 201,
                body: {
                  status: 'success',
                  data: entity
                }
              };
            } else {
              ({
                statusCode: 400
              });
              return {
                status: 'fail',
                message: 'No user added'
              };
            }
          }
        }
      };
    },
    getAll: function(collection) {
      return {
        get: {
          action: function() {
            var entities;
            entities = collection.find({}, {
              fields: {
                profile: 1
              }
            }).fetch();
            if (entities) {
              return {
                status: 'success',
                data: entities
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Unable to retrieve users'
                }
              };
            }
          }
        }
      };
    }
  };


  /*
    Add /login and /logout endpoints to the API
   */

  Restivus.prototype._initAuth = function() {
    var logout, self;
    self = this;

    /*
      Add a login endpoint to the API
    
      After the user is logged in, the onLoggedIn hook is called (see Restfully.configure() for
      adding hook).
     */
    this.addRoute('login', {
      authRequired: false
    }, {
      post: function() {
        var auth, e, extraData, ref, ref1, response, searchQuery, user;
        user = {};
        if (this.bodyParams.user) {
          if (this.bodyParams.user.indexOf('@') === -1) {
            user.username = this.bodyParams.user;
          } else {
            user.email = this.bodyParams.user;
          }
        } else if (this.bodyParams.username) {
          user.username = this.bodyParams.username;
        } else if (this.bodyParams.email) {
          user.email = this.bodyParams.email;
        }
        try {
          auth = Auth.loginWithPassword(user, this.bodyParams.password);
        } catch (_error) {
          e = _error;
          return {
            statusCode: e.error,
            body: {
              status: 'error',
              message: e.reason
            }
          };
        }
        if (auth.userId && auth.authToken) {
          searchQuery = {};
          searchQuery[self._config.auth.token] = Accounts._hashLoginToken(auth.authToken);
          this.user = Meteor.users.findOne({
            '_id': auth.userId
          }, searchQuery);
          this.userId = (ref = this.user) != null ? ref._id : void 0;
        }
        response = {
          status: 'success',
          data: auth
        };
        extraData = (ref1 = self._config.onLoggedIn) != null ? ref1.call(this) : void 0;
        if (extraData != null) {
          _.extend(response.data, {
            extra: extraData
          });
        }
        return response;
      }
    });
    logout = function() {
      var authToken, extraData, hashedToken, index, ref, response, tokenFieldName, tokenLocation, tokenPath, tokenRemovalQuery, tokenToRemove;
      authToken = this.request.headers['x-auth-token'];
      hashedToken = Accounts._hashLoginToken(authToken);
      tokenLocation = self._config.auth.token;
      index = tokenLocation.lastIndexOf('.');
      tokenPath = tokenLocation.substring(0, index);
      tokenFieldName = tokenLocation.substring(index + 1);
      tokenToRemove = {};
      tokenToRemove[tokenFieldName] = hashedToken;
      tokenRemovalQuery = {};
      tokenRemovalQuery[tokenPath] = tokenToRemove;
      Meteor.users.update(this.user._id, {
        $pull: tokenRemovalQuery
      });
      response = {
        status: 'success',
        data: {
          message: 'You\'ve been logged out!'
        }
      };
      extraData = (ref = self._config.onLoggedOut) != null ? ref.call(this) : void 0;
      if (extraData != null) {
        _.extend(response.data, {
          extra: extraData
        });
      }
      return response;
    };

    /*
      Add a logout endpoint to the API
    
      After the user is logged out, the onLoggedOut hook is called (see Restfully.configure() for
      adding hook).
     */
    return this.addRoute('logout', {
      authRequired: true
    }, {
      get: function() {
        console.warn("Warning: Default logout via GET will be removed in Restivus v1.0. Use POST instead.");
        console.warn("    See https://github.com/kahmali/meteor-restivus/issues/100");
        return logout.call(this);
      },
      post: logout
    });
  };

  return Restivus;

})();

Restivus = this.Restivus;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("mrest:restivus", {
  Restivus: Restivus
});

})();

//# sourceURL=meteor://💻app/packages/mrest_restivus.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbXJlc3RfcmVzdGl2dXMvbGliL2F1dGguY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tcmVzdF9yZXN0aXZ1cy9saWIvcm91dGUuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tcmVzdF9yZXN0aXZ1cy9saWIvcmVzdGl2dXMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFBQSxJQUFDLFVBQUQsSUFBQyxRQUFTLEdBQVY7O0FBRUE7QUFBQTs7R0FGQTs7QUFBQSxhQUtBLEdBQWdCLEtBQUssQ0FBQyxLQUFOLENBQVksU0FBQyxJQUFEO0FBQzFCLFFBQU0sSUFBTixFQUNFO0FBQUEsUUFBSSxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FBSjtBQUFBLElBQ0EsVUFBVSxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FEVjtBQUFBLElBRUEsT0FBTyxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FGUDtHQURGO0FBS0EsTUFBRyxDQUFDLENBQUMsSUFBRixDQUFPLElBQVAsQ0FBWSxDQUFDLE1BQWIsS0FBdUIsRUFBMUI7QUFDRSxVQUFVLFNBQUssQ0FBQyxLQUFOLENBQVksNkNBQVosQ0FBVixDQURGO0dBTEE7QUFRQSxTQUFPLElBQVAsQ0FUMEI7QUFBQSxDQUFaLENBTGhCOztBQWlCQTtBQUFBOztHQWpCQTs7QUFBQSxvQkFvQkEsR0FBdUIsU0FBQyxJQUFEO0FBQ3JCLE1BQUcsSUFBSSxDQUFDLEVBQVI7QUFDRSxXQUFPO0FBQUEsTUFBQyxPQUFPLElBQUksQ0FBQyxFQUFiO0tBQVAsQ0FERjtHQUFBLE1BRUssSUFBRyxJQUFJLENBQUMsUUFBUjtBQUNILFdBQU87QUFBQSxNQUFDLFlBQVksSUFBSSxDQUFDLFFBQWxCO0tBQVAsQ0FERztHQUFBLE1BRUEsSUFBRyxJQUFJLENBQUMsS0FBUjtBQUNILFdBQU87QUFBQSxNQUFDLGtCQUFrQixJQUFJLENBQUMsS0FBeEI7S0FBUCxDQURHO0dBSkw7QUFRQSxRQUFVLFVBQU0sMENBQU4sQ0FBVixDQVRxQjtBQUFBLENBcEJ2Qjs7QUFnQ0E7QUFBQTs7R0FoQ0E7O0FBQUEsSUFtQ0MsS0FBSSxDQUFDLGlCQUFOLEdBQTBCLFNBQUMsSUFBRCxFQUFPLFFBQVA7QUFDeEI7QUFBQSxNQUFHLFNBQVksU0FBZjtBQUNFLFVBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLGNBQWxCLENBQVYsQ0FERjtHQUFBO0FBQUEsRUFJQSxNQUFNLElBQU4sRUFBWSxhQUFaLENBSkE7QUFBQSxFQUtBLE1BQU0sUUFBTixFQUFnQixNQUFoQixDQUxBO0FBQUEsRUFRQSw2QkFBNkIscUJBQXFCLElBQXJCLENBUjdCO0FBQUEsRUFTQSxxQkFBcUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFiLENBQXFCLDBCQUFyQixDQVRyQjtBQVdBLE1BQUcsbUJBQUg7QUFDRSxVQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsR0FBYixFQUFrQixjQUFsQixDQUFWLENBREY7R0FYQTtBQWFBLE1BQUcsbURBQStCLENBQUUsa0JBQXBDO0FBQ0UsVUFBVSxVQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsY0FBbEIsQ0FBVixDQURGO0dBYkE7QUFBQSxFQWlCQSx1QkFBdUIsUUFBUSxDQUFDLGNBQVQsQ0FBd0Isa0JBQXhCLEVBQTRDLFFBQTVDLENBakJ2QjtBQWtCQSxNQUFHLG9CQUFvQixDQUFDLEtBQXhCO0FBQ0UsVUFBVSxVQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsY0FBbEIsQ0FBVixDQURGO0dBbEJBO0FBQUEsRUFzQkEsWUFBWSxRQUFRLENBQUMsMEJBQVQsRUF0Qlo7QUFBQSxFQXVCQSxjQUFjLFFBQVEsQ0FBQyxlQUFULENBQXlCLFNBQVMsQ0FBQyxLQUFuQyxDQXZCZDtBQUFBLEVBd0JBLFFBQVEsQ0FBQyx1QkFBVCxDQUFpQyxrQkFBa0IsQ0FBQyxHQUFwRCxFQUF5RDtBQUFBLElBQUMsd0JBQUQ7R0FBekQsQ0F4QkE7QUEwQkEsU0FBTztBQUFBLElBQUMsV0FBVyxTQUFTLENBQUMsS0FBdEI7QUFBQSxJQUE2QixRQUFRLGtCQUFrQixDQUFDLEdBQXhEO0dBQVAsQ0EzQndCO0FBQUEsQ0FuQzFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsS0FBVyxDQUFDO0FBRUcsaUJBQUMsR0FBRCxFQUFPLElBQVAsRUFBYyxPQUFkLEVBQXdCLFVBQXhCO0FBRVgsSUFGWSxJQUFDLE9BQUQsR0FFWjtBQUFBLElBRmtCLElBQUMsUUFBRCxJQUVsQjtBQUFBLElBRnlCLElBQUMsV0FBRCxPQUV6QjtBQUFBLElBRm1DLElBQUMsYUFBRCxVQUVuQztBQUFBLFFBQUcsS0FBSyxVQUFSO0FBQ0UsVUFBQyxVQUFELEdBQWEsSUFBQyxRQUFkO0FBQUEsTUFDQSxJQUFDLFFBQUQsR0FBVyxFQURYLENBREY7S0FGVztFQUFBLENBQWI7O0FBQUEsa0JBT0EsV0FBYTtBQUNYO0FBQUEsdUJBQW1CLENBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsS0FBaEIsRUFBdUIsT0FBdkIsRUFBZ0MsUUFBaEMsRUFBMEMsU0FBMUMsQ0FBbkI7QUFFQSxXQUFPO0FBQ0w7QUFBQSxhQUFPLElBQVA7QUFJQSxVQUFHLENBQUMsQ0FBQyxRQUFGLENBQVcsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLEtBQXhCLEVBQStCLElBQUMsS0FBaEMsQ0FBSDtBQUNFLGNBQVUsVUFBTSw2Q0FBMkMsSUFBQyxLQUFsRCxDQUFWLENBREY7T0FKQTtBQUFBLE1BUUEsSUFBQyxVQUFELEdBQWEsQ0FBQyxDQUFDLE1BQUYsQ0FBUztBQUFBLGlCQUFTLElBQUMsSUFBRyxDQUFDLE9BQU8sQ0FBQyxzQkFBdEI7T0FBVCxFQUF1RCxJQUFDLFVBQXhELENBUmI7QUFBQSxNQVdBLElBQUMsa0JBQUQsRUFYQTtBQUFBLE1BWUEsSUFBQyxvQkFBRCxFQVpBO0FBQUEsTUFlQSxJQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQW5CLENBQXdCLElBQUMsS0FBekIsQ0FmQTtBQUFBLE1BaUJBLGlCQUFpQixDQUFDLENBQUMsTUFBRixDQUFTLGdCQUFULEVBQTJCLFNBQUMsTUFBRDtlQUMxQyxDQUFDLENBQUMsUUFBRixDQUFXLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBSSxDQUFDLFNBQVosQ0FBWCxFQUFtQyxNQUFuQyxFQUQwQztNQUFBLENBQTNCLENBakJqQjtBQUFBLE1BbUJBLGtCQUFrQixDQUFDLENBQUMsTUFBRixDQUFTLGdCQUFULEVBQTJCLFNBQUMsTUFBRDtlQUMzQyxDQUFDLENBQUMsUUFBRixDQUFXLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBSSxDQUFDLFNBQVosQ0FBWCxFQUFtQyxNQUFuQyxFQUQyQztNQUFBLENBQTNCLENBbkJsQjtBQUFBLE1BdUJBLFdBQVcsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLE9BQWIsR0FBdUIsSUFBQyxLQXZCbkM7QUFBQSxNQXdCQSxDQUFDLENBQUMsSUFBRixDQUFPLGNBQVAsRUFBdUIsU0FBQyxNQUFEO0FBQ3JCO0FBQUEsbUJBQVcsSUFBSSxDQUFDLFNBQVUsUUFBMUI7ZUFDQSxVQUFVLENBQUMsR0FBWCxDQUFlLE1BQWYsRUFBdUIsUUFBdkIsRUFBaUMsU0FBQyxHQUFELEVBQU0sR0FBTjtBQUUvQjtBQUFBLDhCQUFvQixLQUFwQjtBQUFBLFVBQ0EsV0FBVzttQkFDVCxvQkFBb0IsS0FEWDtVQUFBLENBRFg7QUFBQSxVQUlBLGtCQUNFO0FBQUEsdUJBQVcsR0FBRyxDQUFDLE1BQWY7QUFBQSxZQUNBLGFBQWEsR0FBRyxDQUFDLEtBRGpCO0FBQUEsWUFFQSxZQUFZLEdBQUcsQ0FBQyxJQUZoQjtBQUFBLFlBR0EsU0FBUyxHQUhUO0FBQUEsWUFJQSxVQUFVLEdBSlY7QUFBQSxZQUtBLE1BQU0sUUFMTjtXQUxGO0FBQUEsVUFZQSxDQUFDLENBQUMsTUFBRixDQUFTLGVBQVQsRUFBMEIsUUFBMUIsQ0FaQTtBQUFBLFVBZUEsZUFBZSxJQWZmO0FBZ0JBO0FBQ0UsMkJBQWUsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsZUFBbkIsRUFBb0MsUUFBcEMsQ0FBZixDQURGO1dBQUE7QUFJRSxZQUZJLGNBRUo7QUFBQSwwQ0FBOEIsS0FBOUIsRUFBcUMsR0FBckMsRUFBMEMsR0FBMUM7QUFDQSxtQkFMRjtXQWhCQTtBQXVCQSxjQUFHLGlCQUFIO0FBRUUsZUFBRyxDQUFDLEdBQUo7QUFDQSxtQkFIRjtXQUFBO0FBS0UsZ0JBQUcsR0FBRyxDQUFDLFdBQVA7QUFDRSxvQkFBVSxVQUFNLHNFQUFvRSxNQUFwRSxHQUEyRSxHQUEzRSxHQUE4RSxRQUFwRixDQUFWLENBREY7YUFBQSxNQUVLLElBQUcsaUJBQWdCLElBQWhCLElBQXdCLGlCQUFnQixNQUEzQztBQUNILG9CQUFVLFVBQU0sdURBQXFELE1BQXJELEdBQTRELEdBQTVELEdBQStELFFBQXJFLENBQVYsQ0FERzthQVBQO1dBdkJBO0FBa0NBLGNBQUcsWUFBWSxDQUFDLElBQWIsSUFBc0IsQ0FBQyxZQUFZLENBQUMsVUFBYixJQUEyQixZQUFZLENBQUMsT0FBekMsQ0FBekI7bUJBQ0UsSUFBSSxDQUFDLFFBQUwsQ0FBYyxHQUFkLEVBQW1CLFlBQVksQ0FBQyxJQUFoQyxFQUFzQyxZQUFZLENBQUMsVUFBbkQsRUFBK0QsWUFBWSxDQUFDLE9BQTVFLEVBREY7V0FBQTttQkFHRSxJQUFJLENBQUMsUUFBTCxDQUFjLEdBQWQsRUFBbUIsWUFBbkIsRUFIRjtXQXBDK0I7UUFBQSxDQUFqQyxFQUZxQjtNQUFBLENBQXZCLENBeEJBO2FBbUVBLENBQUMsQ0FBQyxJQUFGLENBQU8sZUFBUCxFQUF3QixTQUFDLE1BQUQ7ZUFDdEIsVUFBVSxDQUFDLEdBQVgsQ0FBZSxNQUFmLEVBQXVCLFFBQXZCLEVBQWlDLFNBQUMsR0FBRCxFQUFNLEdBQU47QUFDL0I7QUFBQSx5QkFBZTtBQUFBLG9CQUFRLE9BQVI7QUFBQSxZQUFpQixTQUFTLDZCQUExQjtXQUFmO0FBQUEsVUFDQSxVQUFVO0FBQUEscUJBQVMsY0FBYyxDQUFDLElBQWYsQ0FBb0IsSUFBcEIsQ0FBeUIsQ0FBQyxXQUExQixFQUFUO1dBRFY7aUJBRUEsSUFBSSxDQUFDLFFBQUwsQ0FBYyxHQUFkLEVBQW1CLFlBQW5CLEVBQWlDLEdBQWpDLEVBQXNDLE9BQXRDLEVBSCtCO1FBQUEsQ0FBakMsRUFEc0I7TUFBQSxDQUF4QixFQXBFSztJQUFBLENBQVAsQ0FIVztFQUFBLEVBQUgsRUFQVjs7QUFxRkE7QUFBQTs7Ozs7S0FyRkE7O0FBQUEsa0JBMkZBLG9CQUFtQjtBQUNqQixLQUFDLENBQUMsSUFBRixDQUFPLElBQUMsVUFBUixFQUFtQixTQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFNBQW5CO0FBQ2pCLFVBQUcsQ0FBQyxDQUFDLFVBQUYsQ0FBYSxRQUFiLENBQUg7ZUFDRSxTQUFVLFFBQVYsR0FBb0I7QUFBQSxVQUFDLFFBQVEsUUFBVDtVQUR0QjtPQURpQjtJQUFBLENBQW5CLEVBRGlCO0VBQUEsQ0EzRm5COztBQWtHQTtBQUFBOzs7Ozs7Ozs7Ozs7OztLQWxHQTs7QUFBQSxrQkFpSEEsc0JBQXFCO0FBQ25CLEtBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxVQUFSLEVBQW1CLFNBQUMsUUFBRCxFQUFXLE1BQVg7QUFDakI7QUFBQSxVQUFHLFdBQVksU0FBZjtBQUVFLFlBQUcsb0NBQVksQ0FBRSxzQkFBakI7QUFDRSxjQUFDLFFBQU8sQ0FBQyxZQUFULEdBQXdCLEVBQXhCLENBREY7U0FBQTtBQUVBLFlBQUcsU0FBWSxDQUFDLFlBQWhCO0FBQ0Usa0JBQVEsQ0FBQyxZQUFULEdBQXdCLEVBQXhCLENBREY7U0FGQTtBQUFBLFFBSUEsUUFBUSxDQUFDLFlBQVQsR0FBd0IsQ0FBQyxDQUFDLEtBQUYsQ0FBUSxRQUFRLENBQUMsWUFBakIsRUFBK0IsSUFBQyxRQUFPLENBQUMsWUFBeEMsQ0FKeEI7QUFNQSxZQUFHLENBQUMsQ0FBQyxPQUFGLENBQVUsUUFBUSxDQUFDLFlBQW5CLENBQUg7QUFDRSxrQkFBUSxDQUFDLFlBQVQsR0FBd0IsS0FBeEIsQ0FERjtTQU5BO0FBVUEsWUFBRyxRQUFRLENBQUMsWUFBVCxLQUF5QixNQUE1QjtBQUNFLG1EQUFXLENBQUUsc0JBQVYsSUFBMEIsUUFBUSxDQUFDLFlBQXRDO0FBQ0Usb0JBQVEsQ0FBQyxZQUFULEdBQXdCLElBQXhCLENBREY7V0FBQTtBQUdFLG9CQUFRLENBQUMsWUFBVCxHQUF3QixLQUF4QixDQUhGO1dBREY7U0FaRjtPQURpQjtJQUFBLENBQW5CLEVBbUJFLElBbkJGLEVBRG1CO0VBQUEsQ0FqSHJCOztBQXlJQTtBQUFBOzs7O0tBeklBOztBQUFBLGtCQThJQSxnQkFBZSxTQUFDLGVBQUQsRUFBa0IsUUFBbEI7QUFFYixRQUFHLElBQUMsY0FBRCxDQUFlLGVBQWYsRUFBZ0MsUUFBaEMsQ0FBSDtBQUNFLFVBQUcsSUFBQyxjQUFELENBQWUsZUFBZixFQUFnQyxRQUFoQyxDQUFIO2VBQ0UsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFoQixDQUFxQixlQUFyQixFQURGO09BQUE7ZUFHRTtBQUFBLHNCQUFZLEdBQVo7QUFBQSxVQUNBLE1BQU07QUFBQSxZQUFDLFFBQVEsT0FBVDtBQUFBLFlBQWtCLFNBQVMsd0NBQTNCO1dBRE47VUFIRjtPQURGO0tBQUE7YUFPRTtBQUFBLG9CQUFZLEdBQVo7QUFBQSxRQUNBLE1BQU07QUFBQSxVQUFDLFFBQVEsT0FBVDtBQUFBLFVBQWtCLFNBQVMsbUNBQTNCO1NBRE47UUFQRjtLQUZhO0VBQUEsQ0E5SWY7O0FBMkpBO0FBQUE7Ozs7Ozs7O0tBM0pBOztBQUFBLGtCQW9LQSxnQkFBZSxTQUFDLGVBQUQsRUFBa0IsUUFBbEI7QUFDYixRQUFHLFFBQVEsQ0FBQyxZQUFaO2FBQ0UsSUFBQyxjQUFELENBQWUsZUFBZixFQURGO0tBQUE7YUFFSyxLQUZMO0tBRGE7RUFBQSxDQXBLZjs7QUEwS0E7QUFBQTs7Ozs7O0tBMUtBOztBQUFBLGtCQWlMQSxnQkFBZSxTQUFDLGVBQUQ7QUFFYjtBQUFBLFdBQU8sSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBdkIsQ0FBNEIsZUFBNUIsQ0FBUDtBQUdBLHdCQUFHLElBQUksQ0FBRSxnQkFBTixvQkFBaUIsSUFBSSxDQUFFLGVBQXZCLElBQWlDLGlCQUFJLElBQUksQ0FBRSxjQUE5QztBQUNFLHFCQUFlLEVBQWY7QUFBQSxNQUNBLFlBQVksQ0FBQyxHQUFiLEdBQW1CLElBQUksQ0FBQyxNQUR4QjtBQUFBLE1BRUEsWUFBYSxLQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQWxCLENBQWIsR0FBd0MsSUFBSSxDQUFDLEtBRjdDO0FBQUEsTUFHQSxJQUFJLENBQUMsSUFBTCxHQUFZLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBYixDQUFxQixZQUFyQixDQUhaLENBREY7S0FIQTtBQVVBLHVCQUFHLElBQUksQ0FBRSxhQUFUO0FBQ0UscUJBQWUsQ0FBQyxJQUFoQixHQUF1QixJQUFJLENBQUMsSUFBNUI7QUFBQSxNQUNBLGVBQWUsQ0FBQyxNQUFoQixHQUF5QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBRG5DO2FBRUEsS0FIRjtLQUFBO2FBSUssTUFKTDtLQVphO0VBQUEsQ0FqTGY7O0FBb01BO0FBQUE7Ozs7Ozs7S0FwTUE7O0FBQUEsa0JBNE1BLGdCQUFlLFNBQUMsZUFBRCxFQUFrQixRQUFsQjtBQUNiLFFBQUcsUUFBUSxDQUFDLFlBQVo7QUFDRSxVQUFHLENBQUMsQ0FBQyxPQUFGLENBQVUsQ0FBQyxDQUFDLFlBQUYsQ0FBZSxRQUFRLENBQUMsWUFBeEIsRUFBc0MsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUEzRCxDQUFWLENBQUg7QUFDRSxlQUFPLEtBQVAsQ0FERjtPQURGO0tBQUE7V0FHQSxLQUphO0VBQUEsQ0E1TWY7O0FBbU5BO0FBQUE7O0tBbk5BOztBQUFBLGtCQXNOQSxXQUFVLFNBQUMsUUFBRCxFQUFXLElBQVgsRUFBaUIsVUFBakIsRUFBaUMsT0FBakM7QUFHUjs7TUFIeUIsYUFBVztLQUdwQzs7TUFIeUMsVUFBUTtLQUdqRDtBQUFBLHFCQUFpQixJQUFDLGVBQUQsQ0FBZ0IsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLGNBQTdCLENBQWpCO0FBQUEsSUFDQSxVQUFVLElBQUMsZUFBRCxDQUFnQixPQUFoQixDQURWO0FBQUEsSUFFQSxVQUFVLENBQUMsQ0FBQyxNQUFGLENBQVMsY0FBVCxFQUF5QixPQUF6QixDQUZWO0FBS0EsUUFBRyxPQUFRLGdCQUFlLENBQUMsS0FBeEIsQ0FBOEIsaUJBQTlCLE1BQXNELElBQXpEO0FBQ0UsVUFBRyxJQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsVUFBaEI7QUFDRSxlQUFPLElBQUksQ0FBQyxTQUFMLENBQWUsSUFBZixFQUFxQixNQUFyQixFQUFnQyxDQUFoQyxDQUFQLENBREY7T0FBQTtBQUdFLGVBQU8sSUFBSSxDQUFDLFNBQUwsQ0FBZSxJQUFmLENBQVAsQ0FIRjtPQURGO0tBTEE7QUFBQSxJQVlBLGVBQWU7QUFDYixjQUFRLENBQUMsU0FBVCxDQUFtQixVQUFuQixFQUErQixPQUEvQjtBQUFBLE1BQ0EsUUFBUSxDQUFDLEtBQVQsQ0FBZSxJQUFmLENBREE7YUFFQSxRQUFRLENBQUMsR0FBVCxHQUhhO0lBQUEsQ0FaZjtBQWdCQSxRQUFHLGVBQWUsR0FBZixtQkFBb0IsR0FBdkI7QUFPRSxtQ0FBNkIsR0FBN0I7QUFBQSxNQUNBLG1DQUFtQyxJQUFJLElBQUksQ0FBQyxNQUFMLEVBRHZDO0FBQUEsTUFFQSxzQkFBc0IsNkJBQTZCLGdDQUZuRDthQUdBLE1BQU0sQ0FBQyxVQUFQLENBQWtCLFlBQWxCLEVBQWdDLG1CQUFoQyxFQVZGO0tBQUE7YUFZRSxlQVpGO0tBbkJRO0VBQUEsQ0F0TlY7O0FBdVBBO0FBQUE7O0tBdlBBOztBQUFBLGtCQTBQQSxpQkFBZ0IsU0FBQyxNQUFEO1dBQ2QsQ0FBQyxDQUFDLEtBQUYsQ0FBUSxNQUFSLENBQ0EsQ0FBQyxLQURELEVBRUEsQ0FBQyxHQUZELENBRUssU0FBQyxJQUFEO2FBQ0gsQ0FBQyxJQUFLLEdBQUUsQ0FBQyxXQUFSLEVBQUQsRUFBd0IsSUFBSyxHQUE3QixFQURHO0lBQUEsQ0FGTCxDQUlBLENBQUMsTUFKRCxFQUtBLENBQUMsS0FMRCxHQURjO0VBQUEsQ0ExUGhCOztlQUFBOztJQUZGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0VBQUE7O0FBQUEsSUFBTztBQUVRLG9CQUFDLE9BQUQ7QUFDWDtBQUFBLFFBQUMsUUFBRCxHQUFXLEVBQVg7QUFBQSxJQUNBLElBQUMsUUFBRCxHQUNFO0FBQUEsYUFBTyxFQUFQO0FBQUEsTUFDQSxnQkFBZ0IsS0FEaEI7QUFBQSxNQUVBLFNBQVMsTUFGVDtBQUFBLE1BR0EsU0FBUyxJQUhUO0FBQUEsTUFJQSxZQUFZLEtBSlo7QUFBQSxNQUtBLE1BQ0U7QUFBQSxlQUFPLHlDQUFQO0FBQUEsUUFDQSxNQUFNO0FBQ0o7QUFBQSxjQUFHLElBQUMsUUFBTyxDQUFDLE9BQVEsZ0JBQXBCO0FBQ0Usb0JBQVEsUUFBUSxDQUFDLGVBQVQsQ0FBeUIsSUFBQyxRQUFPLENBQUMsT0FBUSxnQkFBMUMsQ0FBUixDQURGO1dBQUE7aUJBRUE7QUFBQSxvQkFBUSxJQUFDLFFBQU8sQ0FBQyxPQUFRLGFBQXpCO0FBQUEsWUFDQSxPQUFPLEtBRFA7WUFISTtRQUFBLENBRE47T0FORjtBQUFBLE1BWUEsZ0JBQ0U7QUFBQSx3QkFBZ0Isa0JBQWhCO09BYkY7QUFBQSxNQWNBLFlBQVksSUFkWjtLQUZGO0FBQUEsSUFtQkEsQ0FBQyxDQUFDLE1BQUYsQ0FBUyxJQUFDLFFBQVYsRUFBbUIsT0FBbkIsQ0FuQkE7QUFxQkEsUUFBRyxJQUFDLFFBQU8sQ0FBQyxVQUFaO0FBQ0Usb0JBQ0U7QUFBQSx1Q0FBK0IsR0FBL0I7QUFBQSxRQUNBLGdDQUFnQyxnREFEaEM7T0FERjtBQUlBLFVBQUcsSUFBQyxRQUFPLENBQUMsY0FBWjtBQUNFLG1CQUFZLGdDQUFaLElBQStDLDJCQUEvQyxDQURGO09BSkE7QUFBQSxNQVFBLENBQUMsQ0FBQyxNQUFGLENBQVMsSUFBQyxRQUFPLENBQUMsY0FBbEIsRUFBa0MsV0FBbEMsQ0FSQTtBQVVBLFVBQUcsS0FBSyxRQUFPLENBQUMsc0JBQWhCO0FBQ0UsWUFBQyxRQUFPLENBQUMsc0JBQVQsR0FBa0M7QUFDaEMsY0FBQyxTQUFRLENBQUMsU0FBVixDQUFvQixHQUFwQixFQUF5QixXQUF6QjtpQkFDQSxJQUFDLEtBQUQsR0FGZ0M7UUFBQSxDQUFsQyxDQURGO09BWEY7S0FyQkE7QUFzQ0EsUUFBRyxJQUFDLFFBQU8sQ0FBQyxPQUFRLEdBQWpCLEtBQXVCLEdBQTFCO0FBQ0UsVUFBQyxRQUFPLENBQUMsT0FBVCxHQUFtQixJQUFDLFFBQU8sQ0FBQyxPQUFPLENBQUMsS0FBakIsQ0FBdUIsQ0FBdkIsQ0FBbkIsQ0FERjtLQXRDQTtBQXdDQSxRQUFHLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxRQUFPLENBQUMsT0FBaEIsTUFBOEIsR0FBakM7QUFDRSxVQUFDLFFBQU8sQ0FBQyxPQUFULEdBQW1CLElBQUMsUUFBTyxDQUFDLE9BQVQsR0FBbUIsR0FBdEMsQ0FERjtLQXhDQTtBQTZDQSxRQUFHLElBQUMsUUFBTyxDQUFDLE9BQVo7QUFDRSxVQUFDLFFBQU8sQ0FBQyxPQUFULElBQW9CLElBQUMsUUFBTyxDQUFDLE9BQVQsR0FBbUIsR0FBdkMsQ0FERjtLQTdDQTtBQWlEQSxRQUFHLElBQUMsUUFBTyxDQUFDLGNBQVo7QUFDRSxVQUFDLFVBQUQsR0FERjtLQUFBLE1BRUssSUFBRyxJQUFDLFFBQU8sQ0FBQyxPQUFaO0FBQ0gsVUFBQyxVQUFEO0FBQUEsTUFDQSxPQUFPLENBQUMsSUFBUixDQUFhLHlFQUNULDZDQURKLENBREEsQ0FERztLQW5ETDtBQXdEQSxXQUFPLElBQVAsQ0F6RFc7RUFBQSxDQUFiOztBQTREQTtBQUFBOzs7Ozs7Ozs7OztLQTVEQTs7QUFBQSxxQkF3RUEsV0FBVSxTQUFDLElBQUQsRUFBTyxPQUFQLEVBQWdCLFNBQWhCO0FBRVI7QUFBQSxZQUFZLFNBQUssQ0FBQyxLQUFOLENBQVksSUFBWixFQUFrQixJQUFsQixFQUF3QixPQUF4QixFQUFpQyxTQUFqQyxDQUFaO0FBQUEsSUFDQSxJQUFDLFFBQU8sQ0FBQyxJQUFULENBQWMsS0FBZCxDQURBO0FBQUEsSUFHQSxLQUFLLENBQUMsUUFBTixFQUhBO0FBS0EsV0FBTyxJQUFQLENBUFE7RUFBQSxDQXhFVjs7QUFrRkE7QUFBQTs7S0FsRkE7O0FBQUEscUJBcUZBLGdCQUFlLFNBQUMsVUFBRCxFQUFhLE9BQWI7QUFDYjs7TUFEMEIsVUFBUTtLQUNsQztBQUFBLGNBQVUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixLQUFoQixFQUF1QixRQUF2QixFQUFpQyxRQUFqQyxDQUFWO0FBQUEsSUFDQSxzQkFBc0IsQ0FBQyxNQUFELEVBQVMsUUFBVCxDQUR0QjtBQUlBLFFBQUcsZUFBYyxNQUFNLENBQUMsS0FBeEI7QUFDRSw0QkFBc0IsSUFBQyx5QkFBdkIsQ0FERjtLQUFBO0FBR0UsNEJBQXNCLElBQUMscUJBQXZCLENBSEY7S0FKQTtBQUFBLElBVUEsaUNBQWlDLE9BQU8sQ0FBQyxTQUFSLElBQXFCLEVBVnREO0FBQUEsSUFXQSxlQUFlLE9BQU8sQ0FBQyxZQUFSLElBQXdCLEVBWHZDO0FBQUEsSUFZQSxvQkFBb0IsT0FBTyxDQUFDLGlCQUFSLElBQTZCLEVBWmpEO0FBQUEsSUFjQSxPQUFPLE9BQU8sQ0FBQyxJQUFSLElBQWdCLFVBQVUsQ0FBQyxLQWRsQztBQUFBLElBa0JBLDJCQUEyQixFQWxCM0I7QUFBQSxJQW1CQSx1QkFBdUIsRUFuQnZCO0FBb0JBLFFBQUcsQ0FBQyxDQUFDLE9BQUYsQ0FBVSw4QkFBVixLQUE4QyxDQUFDLENBQUMsT0FBRixDQUFVLGlCQUFWLENBQWpEO0FBRUUsT0FBQyxDQUFDLElBQUYsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsTUFBRDtBQUVkLFlBQUcsYUFBVSxtQkFBVixjQUFIO0FBQ0UsV0FBQyxDQUFDLE1BQUYsQ0FBUyx3QkFBVCxFQUFtQyxtQkFBb0IsUUFBTyxDQUFDLElBQTVCLENBQWlDLElBQWpDLEVBQXVDLFVBQXZDLENBQW5DLEVBREY7U0FBQTtBQUVLLFdBQUMsQ0FBQyxNQUFGLENBQVMsb0JBQVQsRUFBK0IsbUJBQW9CLFFBQU8sQ0FBQyxJQUE1QixDQUFpQyxJQUFqQyxFQUF1QyxVQUF2QyxDQUEvQixFQUZMO1NBRmM7TUFBQSxDQUFoQixFQU1FLElBTkYsRUFGRjtLQUFBO0FBV0UsT0FBQyxDQUFDLElBQUYsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsTUFBRDtBQUNkO0FBQUEsWUFBRyxhQUFjLGlCQUFkLGlCQUFvQyw4QkFBK0IsUUFBL0IsS0FBNEMsS0FBbkY7QUFHRSw0QkFBa0IsOEJBQStCLFFBQWpEO0FBQUEsVUFDQSxxQkFBcUIsRUFEckI7QUFBQSxVQUVBLENBQUMsQ0FBQyxJQUFGLENBQU8sbUJBQW9CLFFBQU8sQ0FBQyxJQUE1QixDQUFpQyxJQUFqQyxFQUF1QyxVQUF2QyxDQUFQLEVBQTJELFNBQUMsTUFBRCxFQUFTLFVBQVQ7bUJBQ3pELGtCQUFtQixZQUFuQixHQUNFLENBQUMsQ0FBQyxLQUFGLENBQVEsTUFBUixDQUNBLENBQUMsS0FERCxFQUVBLENBQUMsTUFGRCxDQUVRLGVBRlIsQ0FHQSxDQUFDLEtBSEQsR0FGdUQ7VUFBQSxDQUEzRCxDQUZBO0FBU0EsY0FBRyxhQUFVLG1CQUFWLGNBQUg7QUFDRSxhQUFDLENBQUMsTUFBRixDQUFTLHdCQUFULEVBQW1DLGtCQUFuQyxFQURGO1dBQUE7QUFFSyxhQUFDLENBQUMsTUFBRixDQUFTLG9CQUFULEVBQStCLGtCQUEvQixFQUZMO1dBWkY7U0FEYztNQUFBLENBQWhCLEVBaUJFLElBakJGLEVBWEY7S0FwQkE7QUFBQSxJQW1EQSxJQUFDLFNBQUQsQ0FBVSxJQUFWLEVBQWdCLFlBQWhCLEVBQThCLHdCQUE5QixDQW5EQTtBQUFBLElBb0RBLElBQUMsU0FBRCxDQUFhLElBQUQsR0FBTSxNQUFsQixFQUF5QixZQUF6QixFQUF1QyxvQkFBdkMsQ0FwREE7QUFzREEsV0FBTyxJQUFQLENBdkRhO0VBQUEsQ0FyRmY7O0FBK0lBO0FBQUE7O0tBL0lBOztBQUFBLHFCQWtKQSx1QkFDRTtBQUFBLFNBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHFCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLENBQVQ7QUFDQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsZ0JBQUMsUUFBUSxTQUFUO0FBQUEsZ0JBQW9CLE1BQU0sTUFBMUI7Z0JBREY7YUFBQTtxQkFHRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUhGO2FBRk07VUFBQSxDQUFSO1NBREY7UUFERztJQUFBLENBQUw7QUFBQSxJQVNBLEtBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLDhCQUFrQixVQUFVLENBQUMsTUFBWCxDQUFrQixJQUFDLFVBQVMsQ0FBQyxFQUE3QixFQUFpQyxJQUFDLFdBQWxDLENBQWxCO0FBQ0EsZ0JBQUcsZUFBSDtBQUNFLHVCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLENBQVQ7cUJBQ0E7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxNQUExQjtnQkFGRjthQUFBO3FCQUlFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxnQkFBMUI7aUJBRE47Z0JBSkY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURHO0lBQUEsQ0FUTDtBQUFBLElBbUJBLFVBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxrQkFDRTtBQUFBLGtCQUFRO0FBQ04sZ0JBQUcsVUFBVSxDQUFDLE1BQVgsQ0FBa0IsSUFBQyxVQUFTLENBQUMsRUFBN0IsQ0FBSDtxQkFDRTtBQUFBLGdCQUFDLFFBQVEsU0FBVDtBQUFBLGdCQUFvQixNQUFNO0FBQUEsMkJBQVMsY0FBVDtpQkFBMUI7Z0JBREY7YUFBQTtxQkFHRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUhGO2FBRE07VUFBQSxDQUFSO1NBREY7UUFETTtJQUFBLENBbkJSO0FBQUEsSUEyQkEsTUFBTSxTQUFDLFVBQUQ7YUFDSjtBQUFBLGNBQ0U7QUFBQSxrQkFBUTtBQUNOO0FBQUEsdUJBQVcsVUFBVSxDQUFDLE1BQVgsQ0FBa0IsSUFBQyxXQUFuQixDQUFYO0FBQUEsWUFDQSxTQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLFFBQW5CLENBRFQ7QUFFQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLFNBQVQ7QUFBQSxrQkFBb0IsTUFBTSxNQUExQjtpQkFETjtnQkFERjthQUFBO3FCQUlFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxlQUExQjtpQkFETjtnQkFKRjthQUhNO1VBQUEsQ0FBUjtTQURGO1FBREk7SUFBQSxDQTNCTjtBQUFBLElBc0NBLFFBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHVCQUFXLFVBQVUsQ0FBQyxJQUFYLEVBQWlCLENBQUMsS0FBbEIsRUFBWDtBQUNBLGdCQUFHLFFBQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxRQUExQjtnQkFERjthQUFBO3FCQUdFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUywwQ0FBMUI7aUJBRE47Z0JBSEY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURNO0lBQUEsQ0F0Q1I7R0FuSkY7O0FBb01BO0FBQUE7O0tBcE1BOztBQUFBLHFCQXVNQSwyQkFDRTtBQUFBLFNBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHFCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLEVBQWtDO0FBQUEsc0JBQVE7QUFBQSx5QkFBUyxDQUFUO2VBQVI7YUFBbEMsQ0FBVDtBQUNBLGdCQUFHLE1BQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxNQUExQjtnQkFERjthQUFBO3FCQUdFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxnQkFBMUI7aUJBRE47Z0JBSEY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURHO0lBQUEsQ0FBTDtBQUFBLElBU0EsS0FBSyxTQUFDLFVBQUQ7YUFDSDtBQUFBLGFBQ0U7QUFBQSxrQkFBUTtBQUNOO0FBQUEsOEJBQWtCLFVBQVUsQ0FBQyxNQUFYLENBQWtCLElBQUMsVUFBUyxDQUFDLEVBQTdCLEVBQWlDO0FBQUEsb0JBQU07QUFBQSx5QkFBUyxJQUFDLFdBQVY7ZUFBTjthQUFqQyxDQUFsQjtBQUNBLGdCQUFHLGVBQUg7QUFDRSx1QkFBUyxVQUFVLENBQUMsT0FBWCxDQUFtQixJQUFDLFVBQVMsQ0FBQyxFQUE5QixFQUFrQztBQUFBLHdCQUFRO0FBQUEsMkJBQVMsQ0FBVDtpQkFBUjtlQUFsQyxDQUFUO3FCQUNBO0FBQUEsZ0JBQUMsUUFBUSxTQUFUO0FBQUEsZ0JBQW9CLE1BQU0sTUFBMUI7Z0JBRkY7YUFBQTtxQkFJRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUpGO2FBRk07VUFBQSxDQUFSO1NBREY7UUFERztJQUFBLENBVEw7QUFBQSxJQW1CQSxVQUFRLFNBQUMsVUFBRDthQUNOO0FBQUEsa0JBQ0U7QUFBQSxrQkFBUTtBQUNOLGdCQUFHLFVBQVUsQ0FBQyxNQUFYLENBQWtCLElBQUMsVUFBUyxDQUFDLEVBQTdCLENBQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTTtBQUFBLDJCQUFTLGNBQVQ7aUJBQTFCO2dCQURGO2FBQUE7cUJBR0U7QUFBQSw0QkFBWSxHQUFaO0FBQUEsZ0JBQ0EsTUFBTTtBQUFBLGtCQUFDLFFBQVEsTUFBVDtBQUFBLGtCQUFpQixTQUFTLGdCQUExQjtpQkFETjtnQkFIRjthQURNO1VBQUEsQ0FBUjtTQURGO1FBRE07SUFBQSxDQW5CUjtBQUFBLElBMkJBLE1BQU0sU0FBQyxVQUFEO2FBQ0o7QUFBQSxjQUNFO0FBQUEsa0JBQVE7QUFFTjtBQUFBLHVCQUFXLFFBQVEsQ0FBQyxVQUFULENBQW9CLElBQUMsV0FBckIsQ0FBWDtBQUFBLFlBQ0EsU0FBUyxVQUFVLENBQUMsT0FBWCxDQUFtQixRQUFuQixFQUE2QjtBQUFBLHNCQUFRO0FBQUEseUJBQVMsQ0FBVDtlQUFSO2FBQTdCLENBRFQ7QUFFQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLFNBQVQ7QUFBQSxrQkFBb0IsTUFBTSxNQUExQjtpQkFETjtnQkFERjthQUFBO0FBSUU7QUFBQSw0QkFBWSxHQUFaO2VBQUE7cUJBQ0E7QUFBQSxnQkFBQyxRQUFRLE1BQVQ7QUFBQSxnQkFBaUIsU0FBUyxlQUExQjtnQkFMRjthQUpNO1VBQUEsQ0FBUjtTQURGO1FBREk7SUFBQSxDQTNCTjtBQUFBLElBdUNBLFFBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHVCQUFXLFVBQVUsQ0FBQyxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUEsc0JBQVE7QUFBQSx5QkFBUyxDQUFUO2VBQVI7YUFBcEIsQ0FBdUMsQ0FBQyxLQUF4QyxFQUFYO0FBQ0EsZ0JBQUcsUUFBSDtxQkFDRTtBQUFBLGdCQUFDLFFBQVEsU0FBVDtBQUFBLGdCQUFvQixNQUFNLFFBQTFCO2dCQURGO2FBQUE7cUJBR0U7QUFBQSw0QkFBWSxHQUFaO0FBQUEsZ0JBQ0EsTUFBTTtBQUFBLGtCQUFDLFFBQVEsTUFBVDtBQUFBLGtCQUFpQixTQUFTLDBCQUExQjtpQkFETjtnQkFIRjthQUZNO1VBQUEsQ0FBUjtTQURGO1FBRE07SUFBQSxDQXZDUjtHQXhNRjs7QUEwUEE7QUFBQTs7S0ExUEE7O0FBQUEscUJBNlBBLFlBQVc7QUFDVDtBQUFBLFdBQU8sSUFBUDtBQUNBO0FBQUE7Ozs7O09BREE7QUFBQSxJQU9BLElBQUMsU0FBRCxDQUFVLE9BQVYsRUFBbUI7QUFBQSxNQUFDLGNBQWMsS0FBZjtLQUFuQixFQUNFO0FBQUEsWUFBTTtBQUVKO0FBQUEsZUFBTyxFQUFQO0FBQ0EsWUFBRyxJQUFDLFdBQVUsQ0FBQyxJQUFmO0FBQ0UsY0FBRyxJQUFDLFdBQVUsQ0FBQyxJQUFJLENBQUMsT0FBakIsQ0FBeUIsR0FBekIsTUFBaUMsRUFBcEM7QUFDRSxnQkFBSSxDQUFDLFFBQUwsR0FBZ0IsSUFBQyxXQUFVLENBQUMsSUFBNUIsQ0FERjtXQUFBO0FBR0UsZ0JBQUksQ0FBQyxLQUFMLEdBQWEsSUFBQyxXQUFVLENBQUMsSUFBekIsQ0FIRjtXQURGO1NBQUEsTUFLSyxJQUFHLElBQUMsV0FBVSxDQUFDLFFBQWY7QUFDSCxjQUFJLENBQUMsUUFBTCxHQUFnQixJQUFDLFdBQVUsQ0FBQyxRQUE1QixDQURHO1NBQUEsTUFFQSxJQUFHLElBQUMsV0FBVSxDQUFDLEtBQWY7QUFDSCxjQUFJLENBQUMsS0FBTCxHQUFhLElBQUMsV0FBVSxDQUFDLEtBQXpCLENBREc7U0FSTDtBQVlBO0FBQ0UsaUJBQU8sSUFBSSxDQUFDLGlCQUFMLENBQXVCLElBQXZCLEVBQTZCLElBQUMsV0FBVSxDQUFDLFFBQXpDLENBQVAsQ0FERjtTQUFBO0FBR0UsVUFESSxVQUNKO0FBQUEsaUJBQ0U7QUFBQSx3QkFBWSxDQUFDLENBQUMsS0FBZDtBQUFBLFlBQ0EsTUFBTTtBQUFBLHNCQUFRLE9BQVI7QUFBQSxjQUFpQixTQUFTLENBQUMsQ0FBQyxNQUE1QjthQUROO1dBREYsQ0FIRjtTQVpBO0FBcUJBLFlBQUcsSUFBSSxDQUFDLE1BQUwsSUFBZ0IsSUFBSSxDQUFDLFNBQXhCO0FBQ0Usd0JBQWMsRUFBZDtBQUFBLFVBQ0EsV0FBWSxLQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFsQixDQUFaLEdBQXVDLFFBQVEsQ0FBQyxlQUFULENBQXlCLElBQUksQ0FBQyxTQUE5QixDQUR2QztBQUFBLFVBRUEsSUFBQyxLQUFELEdBQVEsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFiLENBQ047QUFBQSxtQkFBTyxJQUFJLENBQUMsTUFBWjtXQURNLEVBRU4sV0FGTSxDQUZSO0FBQUEsVUFLQSxJQUFDLE9BQUQsa0NBQWUsQ0FBRSxZQUxqQixDQURGO1NBckJBO0FBQUEsUUE2QkEsV0FBVztBQUFBLFVBQUMsUUFBUSxTQUFUO0FBQUEsVUFBb0IsTUFBTSxJQUExQjtTQTdCWDtBQUFBLFFBZ0NBLDJEQUFtQyxDQUFFLElBQXpCLENBQThCLElBQTlCLFVBaENaO0FBaUNBLFlBQUcsaUJBQUg7QUFDRSxXQUFDLENBQUMsTUFBRixDQUFTLFFBQVEsQ0FBQyxJQUFsQixFQUF3QjtBQUFBLFlBQUMsT0FBTyxTQUFSO1dBQXhCLEVBREY7U0FqQ0E7ZUFvQ0EsU0F0Q0k7TUFBQSxDQUFOO0tBREYsQ0FQQTtBQUFBLElBZ0RBLFNBQVM7QUFFUDtBQUFBLGtCQUFZLElBQUMsUUFBTyxDQUFDLE9BQVEsZ0JBQTdCO0FBQUEsTUFDQSxjQUFjLFFBQVEsQ0FBQyxlQUFULENBQXlCLFNBQXpCLENBRGQ7QUFBQSxNQUVBLGdCQUFnQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUZsQztBQUFBLE1BR0EsUUFBUSxhQUFhLENBQUMsV0FBZCxDQUEwQixHQUExQixDQUhSO0FBQUEsTUFJQSxZQUFZLGFBQWEsQ0FBQyxTQUFkLENBQXdCLENBQXhCLEVBQTJCLEtBQTNCLENBSlo7QUFBQSxNQUtBLGlCQUFpQixhQUFhLENBQUMsU0FBZCxDQUF3QixRQUFRLENBQWhDLENBTGpCO0FBQUEsTUFNQSxnQkFBZ0IsRUFOaEI7QUFBQSxNQU9BLGFBQWMsZ0JBQWQsR0FBZ0MsV0FQaEM7QUFBQSxNQVFBLG9CQUFvQixFQVJwQjtBQUFBLE1BU0EsaUJBQWtCLFdBQWxCLEdBQStCLGFBVC9CO0FBQUEsTUFVQSxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQWIsQ0FBb0IsSUFBQyxLQUFJLENBQUMsR0FBMUIsRUFBK0I7QUFBQSxRQUFDLE9BQU8saUJBQVI7T0FBL0IsQ0FWQTtBQUFBLE1BWUEsV0FBVztBQUFBLFFBQUMsUUFBUSxTQUFUO0FBQUEsUUFBb0IsTUFBTTtBQUFBLFVBQUMsU0FBUywwQkFBVjtTQUExQjtPQVpYO0FBQUEsTUFlQSwwREFBb0MsQ0FBRSxJQUExQixDQUErQixJQUEvQixVQWZaO0FBZ0JBLFVBQUcsaUJBQUg7QUFDRSxTQUFDLENBQUMsTUFBRixDQUFTLFFBQVEsQ0FBQyxJQUFsQixFQUF3QjtBQUFBLFVBQUMsT0FBTyxTQUFSO1NBQXhCLEVBREY7T0FoQkE7YUFtQkEsU0FyQk87SUFBQSxDQWhEVDtBQXVFQTtBQUFBOzs7OztPQXZFQTtXQTZFQSxJQUFDLFNBQUQsQ0FBVSxRQUFWLEVBQW9CO0FBQUEsTUFBQyxjQUFjLElBQWY7S0FBcEIsRUFDRTtBQUFBLFdBQUs7QUFDSCxlQUFPLENBQUMsSUFBUixDQUFhLHFGQUFiO0FBQUEsUUFDQSxPQUFPLENBQUMsSUFBUixDQUFhLCtEQUFiLENBREE7QUFFQSxlQUFPLE1BQU0sQ0FBQyxJQUFQLENBQVksSUFBWixDQUFQLENBSEc7TUFBQSxDQUFMO0FBQUEsTUFJQSxNQUFNLE1BSk47S0FERixFQTlFUztFQUFBLENBN1BYOztrQkFBQTs7SUFGRjs7QUFBQSxRQW9WQSxHQUFXLElBQUMsU0FwVloiLCJmaWxlIjoiL3BhY2thZ2VzL21yZXN0X3Jlc3RpdnVzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiQEF1dGggb3I9IHt9XG5cbiMjI1xuICBBIHZhbGlkIHVzZXIgd2lsbCBoYXZlIGV4YWN0bHkgb25lIG9mIHRoZSBmb2xsb3dpbmcgaWRlbnRpZmljYXRpb24gZmllbGRzOiBpZCwgdXNlcm5hbWUsIG9yIGVtYWlsXG4jIyNcbnVzZXJWYWxpZGF0b3IgPSBNYXRjaC5XaGVyZSAodXNlcikgLT5cbiAgY2hlY2sgdXNlcixcbiAgICBpZDogTWF0Y2guT3B0aW9uYWwgU3RyaW5nXG4gICAgdXNlcm5hbWU6IE1hdGNoLk9wdGlvbmFsIFN0cmluZ1xuICAgIGVtYWlsOiBNYXRjaC5PcHRpb25hbCBTdHJpbmdcblxuICBpZiBfLmtleXModXNlcikubGVuZ3RoIGlzIG5vdCAxXG4gICAgdGhyb3cgbmV3IE1hdGNoLkVycm9yICdVc2VyIG11c3QgaGF2ZSBleGFjdGx5IG9uZSBpZGVudGlmaWVyIGZpZWxkJ1xuXG4gIHJldHVybiB0cnVlXG5cblxuIyMjXG4gIFJldHVybiBhIE1vbmdvREIgcXVlcnkgc2VsZWN0b3IgZm9yIGZpbmRpbmcgdGhlIGdpdmVuIHVzZXJcbiMjI1xuZ2V0VXNlclF1ZXJ5U2VsZWN0b3IgPSAodXNlcikgLT5cbiAgaWYgdXNlci5pZFxuICAgIHJldHVybiB7J19pZCc6IHVzZXIuaWR9XG4gIGVsc2UgaWYgdXNlci51c2VybmFtZVxuICAgIHJldHVybiB7J3VzZXJuYW1lJzogdXNlci51c2VybmFtZX1cbiAgZWxzZSBpZiB1c2VyLmVtYWlsXG4gICAgcmV0dXJuIHsnZW1haWxzLmFkZHJlc3MnOiB1c2VyLmVtYWlsfVxuXG4gICMgV2Ugc2hvdWxkbid0IGJlIGhlcmUgaWYgdGhlIHVzZXIgb2JqZWN0IHdhcyBwcm9wZXJseSB2YWxpZGF0ZWRcbiAgdGhyb3cgbmV3IEVycm9yICdDYW5ub3QgY3JlYXRlIHNlbGVjdG9yIGZyb20gaW52YWxpZCB1c2VyJ1xuXG5cbiMjI1xuICBMb2cgYSB1c2VyIGluIHdpdGggdGhlaXIgcGFzc3dvcmRcbiMjI1xuQEF1dGgubG9naW5XaXRoUGFzc3dvcmQgPSAodXNlciwgcGFzc3dvcmQpIC0+XG4gIGlmIG5vdCB1c2VyIG9yIG5vdCBwYXNzd29yZFxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IgNDAxLCAnVW5hdXRob3JpemVkJ1xuXG4gICMgVmFsaWRhdGUgdGhlIGxvZ2luIGlucHV0IHR5cGVzXG4gIGNoZWNrIHVzZXIsIHVzZXJWYWxpZGF0b3JcbiAgY2hlY2sgcGFzc3dvcmQsIFN0cmluZ1xuXG4gICMgUmV0cmlldmUgdGhlIHVzZXIgZnJvbSB0aGUgZGF0YWJhc2VcbiAgYXV0aGVudGljYXRpbmdVc2VyU2VsZWN0b3IgPSBnZXRVc2VyUXVlcnlTZWxlY3Rvcih1c2VyKVxuICBhdXRoZW50aWNhdGluZ1VzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZShhdXRoZW50aWNhdGluZ1VzZXJTZWxlY3RvcilcblxuICBpZiBub3QgYXV0aGVudGljYXRpbmdVc2VyXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciA0MDEsICdVbmF1dGhvcml6ZWQnXG4gIGlmIG5vdCBhdXRoZW50aWNhdGluZ1VzZXIuc2VydmljZXM/LnBhc3N3b3JkXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciA0MDEsICdVbmF1dGhvcml6ZWQnXG5cbiAgIyBBdXRoZW50aWNhdGUgdGhlIHVzZXIncyBwYXNzd29yZFxuICBwYXNzd29yZFZlcmlmaWNhdGlvbiA9IEFjY291bnRzLl9jaGVja1Bhc3N3b3JkIGF1dGhlbnRpY2F0aW5nVXNlciwgcGFzc3dvcmRcbiAgaWYgcGFzc3dvcmRWZXJpZmljYXRpb24uZXJyb3JcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIDQwMSwgJ1VuYXV0aG9yaXplZCdcblxuICAjIEFkZCBhIG5ldyBhdXRoIHRva2VuIHRvIHRoZSB1c2VyJ3MgYWNjb3VudFxuICBhdXRoVG9rZW4gPSBBY2NvdW50cy5fZ2VuZXJhdGVTdGFtcGVkTG9naW5Ub2tlbigpXG4gIGhhc2hlZFRva2VuID0gQWNjb3VudHMuX2hhc2hMb2dpblRva2VuIGF1dGhUb2tlbi50b2tlblxuICBBY2NvdW50cy5faW5zZXJ0SGFzaGVkTG9naW5Ub2tlbiBhdXRoZW50aWNhdGluZ1VzZXIuX2lkLCB7aGFzaGVkVG9rZW59XG5cbiAgcmV0dXJuIHthdXRoVG9rZW46IGF1dGhUb2tlbi50b2tlbiwgdXNlcklkOiBhdXRoZW50aWNhdGluZ1VzZXIuX2lkfVxuIiwiY2xhc3Mgc2hhcmUuUm91dGVcblxuICBjb25zdHJ1Y3RvcjogKEBhcGksIEBwYXRoLCBAb3B0aW9ucywgQGVuZHBvaW50cykgLT5cbiAgICAjIENoZWNrIGlmIG9wdGlvbnMgd2VyZSBwcm92aWRlZFxuICAgIGlmIG5vdCBAZW5kcG9pbnRzXG4gICAgICBAZW5kcG9pbnRzID0gQG9wdGlvbnNcbiAgICAgIEBvcHRpb25zID0ge31cblxuXG4gIGFkZFRvQXBpOiBkbyAtPlxuICAgIGF2YWlsYWJsZU1ldGhvZHMgPSBbJ2dldCcsICdwb3N0JywgJ3B1dCcsICdwYXRjaCcsICdkZWxldGUnLCAnb3B0aW9ucyddXG5cbiAgICByZXR1cm4gLT5cbiAgICAgIHNlbGYgPSB0aGlzXG5cbiAgICAgICMgVGhyb3cgYW4gZXJyb3IgaWYgYSByb3V0ZSBoYXMgYWxyZWFkeSBiZWVuIGFkZGVkIGF0IHRoaXMgcGF0aFxuICAgICAgIyBUT0RPOiBDaGVjayBmb3IgY29sbGlzaW9ucyB3aXRoIHBhdGhzIHRoYXQgZm9sbG93IHNhbWUgcGF0dGVybiB3aXRoIGRpZmZlcmVudCBwYXJhbWV0ZXIgbmFtZXNcbiAgICAgIGlmIF8uY29udGFpbnMgQGFwaS5fY29uZmlnLnBhdGhzLCBAcGF0aFxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IgXCJDYW5ub3QgYWRkIGEgcm91dGUgYXQgYW4gZXhpc3RpbmcgcGF0aDogI3tAcGF0aH1cIlxuXG4gICAgICAjIE92ZXJyaWRlIHRoZSBkZWZhdWx0IE9QVElPTlMgZW5kcG9pbnQgd2l0aCBvdXIgb3duXG4gICAgICBAZW5kcG9pbnRzID0gXy5leHRlbmQgb3B0aW9uczogQGFwaS5fY29uZmlnLmRlZmF1bHRPcHRpb25zRW5kcG9pbnQsIEBlbmRwb2ludHNcblxuICAgICAgIyBDb25maWd1cmUgZWFjaCBlbmRwb2ludCBvbiB0aGlzIHJvdXRlXG4gICAgICBAX3Jlc29sdmVFbmRwb2ludHMoKVxuICAgICAgQF9jb25maWd1cmVFbmRwb2ludHMoKVxuXG4gICAgICAjIEFkZCB0byBvdXIgbGlzdCBvZiBleGlzdGluZyBwYXRoc1xuICAgICAgQGFwaS5fY29uZmlnLnBhdGhzLnB1c2ggQHBhdGhcblxuICAgICAgYWxsb3dlZE1ldGhvZHMgPSBfLmZpbHRlciBhdmFpbGFibGVNZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICBfLmNvbnRhaW5zKF8ua2V5cyhzZWxmLmVuZHBvaW50cyksIG1ldGhvZClcbiAgICAgIHJlamVjdGVkTWV0aG9kcyA9IF8ucmVqZWN0IGF2YWlsYWJsZU1ldGhvZHMsIChtZXRob2QpIC0+XG4gICAgICAgIF8uY29udGFpbnMoXy5rZXlzKHNlbGYuZW5kcG9pbnRzKSwgbWV0aG9kKVxuXG4gICAgICAjIFNldHVwIGVuZHBvaW50cyBvbiByb3V0ZVxuICAgICAgZnVsbFBhdGggPSBAYXBpLl9jb25maWcuYXBpUGF0aCArIEBwYXRoXG4gICAgICBfLmVhY2ggYWxsb3dlZE1ldGhvZHMsIChtZXRob2QpIC0+XG4gICAgICAgIGVuZHBvaW50ID0gc2VsZi5lbmRwb2ludHNbbWV0aG9kXVxuICAgICAgICBKc29uUm91dGVzLmFkZCBtZXRob2QsIGZ1bGxQYXRoLCAocmVxLCByZXMpIC0+XG4gICAgICAgICAgIyBBZGQgZnVuY3Rpb24gdG8gZW5kcG9pbnQgY29udGV4dCBmb3IgaW5kaWNhdGluZyBhIHJlc3BvbnNlIGhhcyBiZWVuIGluaXRpYXRlZCBtYW51YWxseVxuICAgICAgICAgIHJlc3BvbnNlSW5pdGlhdGVkID0gZmFsc2VcbiAgICAgICAgICBkb25lRnVuYyA9IC0+XG4gICAgICAgICAgICByZXNwb25zZUluaXRpYXRlZCA9IHRydWVcblxuICAgICAgICAgIGVuZHBvaW50Q29udGV4dCA9XG4gICAgICAgICAgICB1cmxQYXJhbXM6IHJlcS5wYXJhbXNcbiAgICAgICAgICAgIHF1ZXJ5UGFyYW1zOiByZXEucXVlcnlcbiAgICAgICAgICAgIGJvZHlQYXJhbXM6IHJlcS5ib2R5XG4gICAgICAgICAgICByZXF1ZXN0OiByZXFcbiAgICAgICAgICAgIHJlc3BvbnNlOiByZXNcbiAgICAgICAgICAgIGRvbmU6IGRvbmVGdW5jXG4gICAgICAgICAgIyBBZGQgZW5kcG9pbnQgY29uZmlnIG9wdGlvbnMgdG8gY29udGV4dFxuICAgICAgICAgIF8uZXh0ZW5kIGVuZHBvaW50Q29udGV4dCwgZW5kcG9pbnRcblxuICAgICAgICAgICMgUnVuIHRoZSByZXF1ZXN0ZWQgZW5kcG9pbnRcbiAgICAgICAgICByZXNwb25zZURhdGEgPSBudWxsXG4gICAgICAgICAgdHJ5XG4gICAgICAgICAgICByZXNwb25zZURhdGEgPSBzZWxmLl9jYWxsRW5kcG9pbnQgZW5kcG9pbnRDb250ZXh0LCBlbmRwb2ludFxuICAgICAgICAgIGNhdGNoIGVycm9yXG4gICAgICAgICAgICAjIERvIGV4YWN0bHkgd2hhdCBJcm9uIFJvdXRlciB3b3VsZCBoYXZlIGRvbmUsIHRvIGF2b2lkIGNoYW5naW5nIHRoZSBBUElcbiAgICAgICAgICAgIGlyb25Sb3V0ZXJTZW5kRXJyb3JUb1Jlc3BvbnNlKGVycm9yLCByZXEsIHJlcyk7XG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgICAgIGlmIHJlc3BvbnNlSW5pdGlhdGVkXG4gICAgICAgICAgICAjIEVuc3VyZSB0aGUgcmVzcG9uc2UgaXMgcHJvcGVybHkgY29tcGxldGVkXG4gICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIGlmIHJlcy5oZWFkZXJzU2VudFxuICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IgXCJNdXN0IGNhbGwgdGhpcy5kb25lKCkgYWZ0ZXIgaGFuZGxpbmcgZW5kcG9pbnQgcmVzcG9uc2UgbWFudWFsbHk6ICN7bWV0aG9kfSAje2Z1bGxQYXRofVwiXG4gICAgICAgICAgICBlbHNlIGlmIHJlc3BvbnNlRGF0YSBpcyBudWxsIG9yIHJlc3BvbnNlRGF0YSBpcyB1bmRlZmluZWRcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yIFwiQ2Fubm90IHJldHVybiBudWxsIG9yIHVuZGVmaW5lZCBmcm9tIGFuIGVuZHBvaW50OiAje21ldGhvZH0gI3tmdWxsUGF0aH1cIlxuXG4gICAgICAgICAgIyBHZW5lcmF0ZSBhbmQgcmV0dXJuIHRoZSBodHRwIHJlc3BvbnNlLCBoYW5kbGluZyB0aGUgZGlmZmVyZW50IGVuZHBvaW50IHJlc3BvbnNlIHR5cGVzXG4gICAgICAgICAgaWYgcmVzcG9uc2VEYXRhLmJvZHkgYW5kIChyZXNwb25zZURhdGEuc3RhdHVzQ29kZSBvciByZXNwb25zZURhdGEuaGVhZGVycylcbiAgICAgICAgICAgIHNlbGYuX3Jlc3BvbmQgcmVzLCByZXNwb25zZURhdGEuYm9keSwgcmVzcG9uc2VEYXRhLnN0YXR1c0NvZGUsIHJlc3BvbnNlRGF0YS5oZWFkZXJzXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc2VsZi5fcmVzcG9uZCByZXMsIHJlc3BvbnNlRGF0YVxuXG4gICAgICBfLmVhY2ggcmVqZWN0ZWRNZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICBKc29uUm91dGVzLmFkZCBtZXRob2QsIGZ1bGxQYXRoLCAocmVxLCByZXMpIC0+XG4gICAgICAgICAgcmVzcG9uc2VEYXRhID0gc3RhdHVzOiAnZXJyb3InLCBtZXNzYWdlOiAnQVBJIGVuZHBvaW50IGRvZXMgbm90IGV4aXN0J1xuICAgICAgICAgIGhlYWRlcnMgPSAnQWxsb3cnOiBhbGxvd2VkTWV0aG9kcy5qb2luKCcsICcpLnRvVXBwZXJDYXNlKClcbiAgICAgICAgICBzZWxmLl9yZXNwb25kIHJlcywgcmVzcG9uc2VEYXRhLCA0MDUsIGhlYWRlcnNcblxuXG4gICMjI1xuICAgIENvbnZlcnQgYWxsIGVuZHBvaW50cyBvbiB0aGUgZ2l2ZW4gcm91dGUgaW50byBvdXIgZXhwZWN0ZWQgZW5kcG9pbnQgb2JqZWN0IGlmIGl0IGlzIGEgYmFyZVxuICAgIGZ1bmN0aW9uXG5cbiAgICBAcGFyYW0ge1JvdXRlfSByb3V0ZSBUaGUgcm91dGUgdGhlIGVuZHBvaW50cyBiZWxvbmcgdG9cbiAgIyMjXG4gIF9yZXNvbHZlRW5kcG9pbnRzOiAtPlxuICAgIF8uZWFjaCBAZW5kcG9pbnRzLCAoZW5kcG9pbnQsIG1ldGhvZCwgZW5kcG9pbnRzKSAtPlxuICAgICAgaWYgXy5pc0Z1bmN0aW9uKGVuZHBvaW50KVxuICAgICAgICBlbmRwb2ludHNbbWV0aG9kXSA9IHthY3Rpb246IGVuZHBvaW50fVxuICAgIHJldHVyblxuXG5cbiAgIyMjXG4gICAgQ29uZmlndXJlIHRoZSBhdXRoZW50aWNhdGlvbiBhbmQgcm9sZSByZXF1aXJlbWVudCBvbiBhbGwgZW5kcG9pbnRzIChleGNlcHQgT1BUSU9OUywgd2hpY2ggbXVzdFxuICAgIGJlIGNvbmZpZ3VyZWQgZGlyZWN0bHkgb24gdGhlIGVuZHBvaW50KVxuXG4gICAgQXV0aGVudGljYXRpb24gY2FuIGJlIHJlcXVpcmVkIG9uIGFuIGVudGlyZSByb3V0ZSBvciBpbmRpdmlkdWFsIGVuZHBvaW50cy4gSWYgcmVxdWlyZWQgb24gYW5cbiAgICBlbnRpcmUgcm91dGUsIHRoYXQgc2VydmVzIGFzIHRoZSBkZWZhdWx0LiBJZiByZXF1aXJlZCBpbiBhbnkgaW5kaXZpZHVhbCBlbmRwb2ludHMsIHRoYXQgd2lsbFxuICAgIG92ZXJyaWRlIHRoZSBkZWZhdWx0LlxuXG4gICAgQWZ0ZXIgdGhlIGVuZHBvaW50IGlzIGNvbmZpZ3VyZWQsIGFsbCBhdXRoZW50aWNhdGlvbiBhbmQgcm9sZSByZXF1aXJlbWVudHMgb2YgYW4gZW5kcG9pbnQgY2FuIGJlXG4gICAgYWNjZXNzZWQgYXQgPGNvZGU+ZW5kcG9pbnQuYXV0aFJlcXVpcmVkPC9jb2RlPiBhbmQgPGNvZGU+ZW5kcG9pbnQucm9sZVJlcXVpcmVkPC9jb2RlPixcbiAgICByZXNwZWN0aXZlbHkuXG5cbiAgICBAcGFyYW0ge1JvdXRlfSByb3V0ZSBUaGUgcm91dGUgdGhlIGVuZHBvaW50cyBiZWxvbmcgdG9cbiAgICBAcGFyYW0ge0VuZHBvaW50fSBlbmRwb2ludCBUaGUgZW5kcG9pbnQgdG8gY29uZmlndXJlXG4gICMjI1xuICBfY29uZmlndXJlRW5kcG9pbnRzOiAtPlxuICAgIF8uZWFjaCBAZW5kcG9pbnRzLCAoZW5kcG9pbnQsIG1ldGhvZCkgLT5cbiAgICAgIGlmIG1ldGhvZCBpc250ICdvcHRpb25zJ1xuICAgICAgICAjIENvbmZpZ3VyZSBhY2NlcHRhYmxlIHJvbGVzXG4gICAgICAgIGlmIG5vdCBAb3B0aW9ucz8ucm9sZVJlcXVpcmVkXG4gICAgICAgICAgQG9wdGlvbnMucm9sZVJlcXVpcmVkID0gW11cbiAgICAgICAgaWYgbm90IGVuZHBvaW50LnJvbGVSZXF1aXJlZFxuICAgICAgICAgIGVuZHBvaW50LnJvbGVSZXF1aXJlZCA9IFtdXG4gICAgICAgIGVuZHBvaW50LnJvbGVSZXF1aXJlZCA9IF8udW5pb24gZW5kcG9pbnQucm9sZVJlcXVpcmVkLCBAb3B0aW9ucy5yb2xlUmVxdWlyZWRcbiAgICAgICAgIyBNYWtlIGl0IGVhc2llciB0byBjaGVjayBpZiBubyByb2xlcyBhcmUgcmVxdWlyZWRcbiAgICAgICAgaWYgXy5pc0VtcHR5IGVuZHBvaW50LnJvbGVSZXF1aXJlZFxuICAgICAgICAgIGVuZHBvaW50LnJvbGVSZXF1aXJlZCA9IGZhbHNlXG5cbiAgICAgICAgIyBDb25maWd1cmUgYXV0aCByZXF1aXJlbWVudFxuICAgICAgICBpZiBlbmRwb2ludC5hdXRoUmVxdWlyZWQgaXMgdW5kZWZpbmVkXG4gICAgICAgICAgaWYgQG9wdGlvbnM/LmF1dGhSZXF1aXJlZCBvciBlbmRwb2ludC5yb2xlUmVxdWlyZWRcbiAgICAgICAgICAgIGVuZHBvaW50LmF1dGhSZXF1aXJlZCA9IHRydWVcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBlbmRwb2ludC5hdXRoUmVxdWlyZWQgPSBmYWxzZVxuICAgICAgICByZXR1cm5cbiAgICAsIHRoaXNcbiAgICByZXR1cm5cblxuXG4gICMjI1xuICAgIEF1dGhlbnRpY2F0ZSBhbiBlbmRwb2ludCBpZiByZXF1aXJlZCwgYW5kIHJldHVybiB0aGUgcmVzdWx0IG9mIGNhbGxpbmcgaXRcblxuICAgIEByZXR1cm5zIFRoZSBlbmRwb2ludCByZXNwb25zZSBvciBhIDQwMSBpZiBhdXRoZW50aWNhdGlvbiBmYWlsc1xuICAjIyNcbiAgX2NhbGxFbmRwb2ludDogKGVuZHBvaW50Q29udGV4dCwgZW5kcG9pbnQpIC0+XG4gICAgIyBDYWxsIHRoZSBlbmRwb2ludCBpZiBhdXRoZW50aWNhdGlvbiBkb2Vzbid0IGZhaWxcbiAgICBpZiBAX2F1dGhBY2NlcHRlZCBlbmRwb2ludENvbnRleHQsIGVuZHBvaW50XG4gICAgICBpZiBAX3JvbGVBY2NlcHRlZCBlbmRwb2ludENvbnRleHQsIGVuZHBvaW50XG4gICAgICAgIGVuZHBvaW50LmFjdGlvbi5jYWxsIGVuZHBvaW50Q29udGV4dFxuICAgICAgZWxzZVxuICAgICAgICBzdGF0dXNDb2RlOiA0MDNcbiAgICAgICAgYm9keToge3N0YXR1czogJ2Vycm9yJywgbWVzc2FnZTogJ1lvdSBkbyBub3QgaGF2ZSBwZXJtaXNzaW9uIHRvIGRvIHRoaXMuJ31cbiAgICBlbHNlXG4gICAgICBzdGF0dXNDb2RlOiA0MDFcbiAgICAgIGJvZHk6IHtzdGF0dXM6ICdlcnJvcicsIG1lc3NhZ2U6ICdZb3UgbXVzdCBiZSBsb2dnZWQgaW4gdG8gZG8gdGhpcy4nfVxuXG5cbiAgIyMjXG4gICAgQXV0aGVudGljYXRlIHRoZSBnaXZlbiBlbmRwb2ludCBpZiByZXF1aXJlZFxuXG4gICAgT25jZSBpdCdzIGdsb2JhbGx5IGNvbmZpZ3VyZWQgaW4gdGhlIEFQSSwgYXV0aGVudGljYXRpb24gY2FuIGJlIHJlcXVpcmVkIG9uIGFuIGVudGlyZSByb3V0ZSBvclxuICAgIGluZGl2aWR1YWwgZW5kcG9pbnRzLiBJZiByZXF1aXJlZCBvbiBhbiBlbnRpcmUgZW5kcG9pbnQsIHRoYXQgc2VydmVzIGFzIHRoZSBkZWZhdWx0LiBJZiByZXF1aXJlZFxuICAgIGluIGFueSBpbmRpdmlkdWFsIGVuZHBvaW50cywgdGhhdCB3aWxsIG92ZXJyaWRlIHRoZSBkZWZhdWx0LlxuXG4gICAgQHJldHVybnMgRmFsc2UgaWYgYXV0aGVudGljYXRpb24gZmFpbHMsIGFuZCB0cnVlIG90aGVyd2lzZVxuICAjIyNcbiAgX2F1dGhBY2NlcHRlZDogKGVuZHBvaW50Q29udGV4dCwgZW5kcG9pbnQpIC0+XG4gICAgaWYgZW5kcG9pbnQuYXV0aFJlcXVpcmVkXG4gICAgICBAX2F1dGhlbnRpY2F0ZSBlbmRwb2ludENvbnRleHRcbiAgICBlbHNlIHRydWVcblxuXG4gICMjI1xuICAgIFZlcmlmeSB0aGUgcmVxdWVzdCBpcyBiZWluZyBtYWRlIGJ5IGFuIGFjdGl2ZWx5IGxvZ2dlZCBpbiB1c2VyXG5cbiAgICBJZiB2ZXJpZmllZCwgYXR0YWNoIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIgdG8gdGhlIGNvbnRleHQuXG5cbiAgICBAcmV0dXJucyB7Qm9vbGVhbn0gVHJ1ZSBpZiB0aGUgYXV0aGVudGljYXRpb24gd2FzIHN1Y2Nlc3NmdWxcbiAgIyMjXG4gIF9hdXRoZW50aWNhdGU6IChlbmRwb2ludENvbnRleHQpIC0+XG4gICAgIyBHZXQgYXV0aCBpbmZvXG4gICAgYXV0aCA9IEBhcGkuX2NvbmZpZy5hdXRoLnVzZXIuY2FsbChlbmRwb2ludENvbnRleHQpXG5cbiAgICAjIEdldCB0aGUgdXNlciBmcm9tIHRoZSBkYXRhYmFzZVxuICAgIGlmIGF1dGg/LnVzZXJJZCBhbmQgYXV0aD8udG9rZW4gYW5kIG5vdCBhdXRoPy51c2VyXG4gICAgICB1c2VyU2VsZWN0b3IgPSB7fVxuICAgICAgdXNlclNlbGVjdG9yLl9pZCA9IGF1dGgudXNlcklkXG4gICAgICB1c2VyU2VsZWN0b3JbQGFwaS5fY29uZmlnLmF1dGgudG9rZW5dID0gYXV0aC50b2tlblxuICAgICAgYXV0aC51c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUgdXNlclNlbGVjdG9yXG5cbiAgICAjIEF0dGFjaCB0aGUgdXNlciBhbmQgdGhlaXIgSUQgdG8gdGhlIGNvbnRleHQgaWYgdGhlIGF1dGhlbnRpY2F0aW9uIHdhcyBzdWNjZXNzZnVsXG4gICAgaWYgYXV0aD8udXNlclxuICAgICAgZW5kcG9pbnRDb250ZXh0LnVzZXIgPSBhdXRoLnVzZXJcbiAgICAgIGVuZHBvaW50Q29udGV4dC51c2VySWQgPSBhdXRoLnVzZXIuX2lkXG4gICAgICB0cnVlXG4gICAgZWxzZSBmYWxzZVxuXG5cbiAgIyMjXG4gICAgQXV0aGVudGljYXRlIHRoZSB1c2VyIHJvbGUgaWYgcmVxdWlyZWRcblxuICAgIE11c3QgYmUgY2FsbGVkIGFmdGVyIF9hdXRoQWNjZXB0ZWQoKS5cblxuICAgIEByZXR1cm5zIFRydWUgaWYgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlciBiZWxvbmdzIHRvIDxpPmFueTwvaT4gb2YgdGhlIGFjY2VwdGFibGUgcm9sZXMgb24gdGhlXG4gICAgICAgICAgICAgZW5kcG9pbnRcbiAgIyMjXG4gIF9yb2xlQWNjZXB0ZWQ6IChlbmRwb2ludENvbnRleHQsIGVuZHBvaW50KSAtPlxuICAgIGlmIGVuZHBvaW50LnJvbGVSZXF1aXJlZFxuICAgICAgaWYgXy5pc0VtcHR5IF8uaW50ZXJzZWN0aW9uKGVuZHBvaW50LnJvbGVSZXF1aXJlZCwgZW5kcG9pbnRDb250ZXh0LnVzZXIucm9sZXMpXG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgIHRydWVcblxuXG4gICMjI1xuICAgIFJlc3BvbmQgdG8gYW4gSFRUUCByZXF1ZXN0XG4gICMjI1xuICBfcmVzcG9uZDogKHJlc3BvbnNlLCBib2R5LCBzdGF0dXNDb2RlPTIwMCwgaGVhZGVycz17fSkgLT5cbiAgICAjIE92ZXJyaWRlIGFueSBkZWZhdWx0IGhlYWRlcnMgdGhhdCBoYXZlIGJlZW4gcHJvdmlkZWQgKGtleXMgYXJlIG5vcm1hbGl6ZWQgdG8gYmUgY2FzZSBpbnNlbnNpdGl2ZSlcbiAgICAjIFRPRE86IENvbnNpZGVyIG9ubHkgbG93ZXJjYXNpbmcgdGhlIGhlYWRlciBrZXlzIHdlIG5lZWQgbm9ybWFsaXplZCwgbGlrZSBDb250ZW50LVR5cGVcbiAgICBkZWZhdWx0SGVhZGVycyA9IEBfbG93ZXJDYXNlS2V5cyBAYXBpLl9jb25maWcuZGVmYXVsdEhlYWRlcnNcbiAgICBoZWFkZXJzID0gQF9sb3dlckNhc2VLZXlzIGhlYWRlcnNcbiAgICBoZWFkZXJzID0gXy5leHRlbmQgZGVmYXVsdEhlYWRlcnMsIGhlYWRlcnNcblxuICAgICMgUHJlcGFyZSBKU09OIGJvZHkgZm9yIHJlc3BvbnNlIHdoZW4gQ29udGVudC1UeXBlIGluZGljYXRlcyBKU09OIHR5cGVcbiAgICBpZiBoZWFkZXJzWydjb250ZW50LXR5cGUnXS5tYXRjaCgvanNvbnxqYXZhc2NyaXB0LykgaXNudCBudWxsXG4gICAgICBpZiBAYXBpLl9jb25maWcucHJldHR5SnNvblxuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkgYm9keSwgdW5kZWZpbmVkLCAyXG4gICAgICBlbHNlXG4gICAgICAgIGJvZHkgPSBKU09OLnN0cmluZ2lmeSBib2R5XG5cbiAgICAjIFNlbmQgcmVzcG9uc2VcbiAgICBzZW5kUmVzcG9uc2UgPSAtPlxuICAgICAgcmVzcG9uc2Uud3JpdGVIZWFkIHN0YXR1c0NvZGUsIGhlYWRlcnNcbiAgICAgIHJlc3BvbnNlLndyaXRlIGJvZHlcbiAgICAgIHJlc3BvbnNlLmVuZCgpXG4gICAgaWYgc3RhdHVzQ29kZSBpbiBbNDAxLCA0MDNdXG4gICAgICAjIEhhY2tlcnMgY2FuIG1lYXN1cmUgdGhlIHJlc3BvbnNlIHRpbWUgdG8gZGV0ZXJtaW5lIHRoaW5ncyBsaWtlIHdoZXRoZXIgdGhlIDQwMSByZXNwb25zZSB3YXMgXG4gICAgICAjIGNhdXNlZCBieSBiYWQgdXNlciBpZCB2cyBiYWQgcGFzc3dvcmQuXG4gICAgICAjIEluIGRvaW5nIHNvLCB0aGV5IGNhbiBmaXJzdCBzY2FuIGZvciB2YWxpZCB1c2VyIGlkcyByZWdhcmRsZXNzIG9mIHZhbGlkIHBhc3N3b3Jkcy5cbiAgICAgICMgRGVsYXkgYnkgYSByYW5kb20gYW1vdW50IHRvIHJlZHVjZSB0aGUgYWJpbGl0eSBmb3IgYSBoYWNrZXIgdG8gZGV0ZXJtaW5lIHRoZSByZXNwb25zZSB0aW1lLlxuICAgICAgIyBTZWUgaHR0cHM6Ly93d3cub3dhc3Aub3JnL2luZGV4LnBocC9CbG9ja2luZ19CcnV0ZV9Gb3JjZV9BdHRhY2tzI0ZpbmRpbmdfT3RoZXJfQ291bnRlcm1lYXN1cmVzXG4gICAgICAjIFNlZSBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9UaW1pbmdfYXR0YWNrXG4gICAgICBtaW5pbXVtRGVsYXlJbk1pbGxpc2Vjb25kcyA9IDUwMFxuICAgICAgcmFuZG9tTXVsdGlwbGllckJldHdlZW5PbmVBbmRUd28gPSAxICsgTWF0aC5yYW5kb20oKVxuICAgICAgZGVsYXlJbk1pbGxpc2Vjb25kcyA9IG1pbmltdW1EZWxheUluTWlsbGlzZWNvbmRzICogcmFuZG9tTXVsdGlwbGllckJldHdlZW5PbmVBbmRUd29cbiAgICAgIE1ldGVvci5zZXRUaW1lb3V0IHNlbmRSZXNwb25zZSwgZGVsYXlJbk1pbGxpc2Vjb25kc1xuICAgIGVsc2VcbiAgICAgIHNlbmRSZXNwb25zZSgpXG5cbiAgIyMjXG4gICAgUmV0dXJuIHRoZSBvYmplY3Qgd2l0aCBhbGwgb2YgdGhlIGtleXMgY29udmVydGVkIHRvIGxvd2VyY2FzZVxuICAjIyNcbiAgX2xvd2VyQ2FzZUtleXM6IChvYmplY3QpIC0+XG4gICAgXy5jaGFpbiBvYmplY3RcbiAgICAucGFpcnMoKVxuICAgIC5tYXAgKGF0dHIpIC0+XG4gICAgICBbYXR0clswXS50b0xvd2VyQ2FzZSgpLCBhdHRyWzFdXVxuICAgIC5vYmplY3QoKVxuICAgIC52YWx1ZSgpXG4iLCJjbGFzcyBAUmVzdGl2dXNcblxuICBjb25zdHJ1Y3RvcjogKG9wdGlvbnMpIC0+XG4gICAgQF9yb3V0ZXMgPSBbXVxuICAgIEBfY29uZmlnID1cbiAgICAgIHBhdGhzOiBbXVxuICAgICAgdXNlRGVmYXVsdEF1dGg6IGZhbHNlXG4gICAgICBhcGlQYXRoOiAnYXBpLydcbiAgICAgIHZlcnNpb246IG51bGxcbiAgICAgIHByZXR0eUpzb246IGZhbHNlXG4gICAgICBhdXRoOlxuICAgICAgICB0b2tlbjogJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy5oYXNoZWRUb2tlbidcbiAgICAgICAgdXNlcjogLT5cbiAgICAgICAgICBpZiBAcmVxdWVzdC5oZWFkZXJzWyd4LWF1dGgtdG9rZW4nXVxuICAgICAgICAgICAgdG9rZW4gPSBBY2NvdW50cy5faGFzaExvZ2luVG9rZW4gQHJlcXVlc3QuaGVhZGVyc1sneC1hdXRoLXRva2VuJ11cbiAgICAgICAgICB1c2VySWQ6IEByZXF1ZXN0LmhlYWRlcnNbJ3gtdXNlci1pZCddXG4gICAgICAgICAgdG9rZW46IHRva2VuXG4gICAgICBkZWZhdWx0SGVhZGVyczpcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgICAgZW5hYmxlQ29yczogdHJ1ZVxuXG4gICAgIyBDb25maWd1cmUgQVBJIHdpdGggdGhlIGdpdmVuIG9wdGlvbnNcbiAgICBfLmV4dGVuZCBAX2NvbmZpZywgb3B0aW9uc1xuXG4gICAgaWYgQF9jb25maWcuZW5hYmxlQ29yc1xuICAgICAgY29yc0hlYWRlcnMgPVxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ09yaWdpbiwgWC1SZXF1ZXN0ZWQtV2l0aCwgQ29udGVudC1UeXBlLCBBY2NlcHQnXG5cbiAgICAgIGlmIEBfY29uZmlnLnVzZURlZmF1bHRBdXRoXG4gICAgICAgIGNvcnNIZWFkZXJzWydBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJ10gKz0gJywgWC1Vc2VyLUlkLCBYLUF1dGgtVG9rZW4nXG5cbiAgICAgICMgU2V0IGRlZmF1bHQgaGVhZGVyIHRvIGVuYWJsZSBDT1JTIGlmIGNvbmZpZ3VyZWRcbiAgICAgIF8uZXh0ZW5kIEBfY29uZmlnLmRlZmF1bHRIZWFkZXJzLCBjb3JzSGVhZGVyc1xuXG4gICAgICBpZiBub3QgQF9jb25maWcuZGVmYXVsdE9wdGlvbnNFbmRwb2ludFxuICAgICAgICBAX2NvbmZpZy5kZWZhdWx0T3B0aW9uc0VuZHBvaW50ID0gLT5cbiAgICAgICAgICBAcmVzcG9uc2Uud3JpdGVIZWFkIDIwMCwgY29yc0hlYWRlcnNcbiAgICAgICAgICBAZG9uZSgpXG5cbiAgICAjIE5vcm1hbGl6ZSB0aGUgQVBJIHBhdGhcbiAgICBpZiBAX2NvbmZpZy5hcGlQYXRoWzBdIGlzICcvJ1xuICAgICAgQF9jb25maWcuYXBpUGF0aCA9IEBfY29uZmlnLmFwaVBhdGguc2xpY2UgMVxuICAgIGlmIF8ubGFzdChAX2NvbmZpZy5hcGlQYXRoKSBpc250ICcvJ1xuICAgICAgQF9jb25maWcuYXBpUGF0aCA9IEBfY29uZmlnLmFwaVBhdGggKyAnLydcblxuICAgICMgVVJMIHBhdGggdmVyc2lvbmluZyBpcyB0aGUgb25seSB0eXBlIG9mIEFQSSB2ZXJzaW9uaW5nIGN1cnJlbnRseSBhdmFpbGFibGUsIHNvIGlmIGEgdmVyc2lvbiBpc1xuICAgICMgcHJvdmlkZWQsIGFwcGVuZCBpdCB0byB0aGUgYmFzZSBwYXRoIG9mIHRoZSBBUElcbiAgICBpZiBAX2NvbmZpZy52ZXJzaW9uXG4gICAgICBAX2NvbmZpZy5hcGlQYXRoICs9IEBfY29uZmlnLnZlcnNpb24gKyAnLydcblxuICAgICMgQWRkIGRlZmF1bHQgbG9naW4gYW5kIGxvZ291dCBlbmRwb2ludHMgaWYgYXV0aCBpcyBjb25maWd1cmVkXG4gICAgaWYgQF9jb25maWcudXNlRGVmYXVsdEF1dGhcbiAgICAgIEBfaW5pdEF1dGgoKVxuICAgIGVsc2UgaWYgQF9jb25maWcudXNlQXV0aFxuICAgICAgQF9pbml0QXV0aCgpXG4gICAgICBjb25zb2xlLndhcm4gJ1dhcm5pbmc6IHVzZUF1dGggQVBJIGNvbmZpZyBvcHRpb24gd2lsbCBiZSByZW1vdmVkIGluIFJlc3RpdnVzIHYxLjAgJyArXG4gICAgICAgICAgJ1xcbiAgICBVc2UgdGhlIHVzZURlZmF1bHRBdXRoIG9wdGlvbiBpbnN0ZWFkJ1xuXG4gICAgcmV0dXJuIHRoaXNcblxuXG4gICMjIypcbiAgICBBZGQgZW5kcG9pbnRzIGZvciB0aGUgZ2l2ZW4gSFRUUCBtZXRob2RzIGF0IHRoZSBnaXZlbiBwYXRoXG5cbiAgICBAcGFyYW0gcGF0aCB7U3RyaW5nfSBUaGUgZXh0ZW5kZWQgVVJMIHBhdGggKHdpbGwgYmUgYXBwZW5kZWQgdG8gYmFzZSBwYXRoIG9mIHRoZSBBUEkpXG4gICAgQHBhcmFtIG9wdGlvbnMge09iamVjdH0gUm91dGUgY29uZmlndXJhdGlvbiBvcHRpb25zXG4gICAgQHBhcmFtIG9wdGlvbnMuYXV0aFJlcXVpcmVkIHtCb29sZWFufSBUaGUgZGVmYXVsdCBhdXRoIHJlcXVpcmVtZW50IGZvciBlYWNoIGVuZHBvaW50IG9uIHRoZSByb3V0ZVxuICAgIEBwYXJhbSBvcHRpb25zLnJvbGVSZXF1aXJlZCB7U3RyaW5nIG9yIFN0cmluZ1tdfSBUaGUgZGVmYXVsdCByb2xlIHJlcXVpcmVkIGZvciBlYWNoIGVuZHBvaW50IG9uIHRoZSByb3V0ZVxuICAgIEBwYXJhbSBlbmRwb2ludHMge09iamVjdH0gQSBzZXQgb2YgZW5kcG9pbnRzIGF2YWlsYWJsZSBvbiB0aGUgbmV3IHJvdXRlIChnZXQsIHBvc3QsIHB1dCwgcGF0Y2gsIGRlbGV0ZSwgb3B0aW9ucylcbiAgICBAcGFyYW0gZW5kcG9pbnRzLjxtZXRob2Q+IHtGdW5jdGlvbiBvciBPYmplY3R9IElmIGEgZnVuY3Rpb24gaXMgcHJvdmlkZWQsIGFsbCBkZWZhdWx0IHJvdXRlXG4gICAgICAgIGNvbmZpZ3VyYXRpb24gb3B0aW9ucyB3aWxsIGJlIGFwcGxpZWQgdG8gdGhlIGVuZHBvaW50LiBPdGhlcndpc2UgYW4gb2JqZWN0IHdpdGggYW4gYGFjdGlvbmBcbiAgICAgICAgYW5kIGFsbCBvdGhlciByb3V0ZSBjb25maWcgb3B0aW9ucyBhdmFpbGFibGUuIEFuIGBhY3Rpb25gIG11c3QgYmUgcHJvdmlkZWQgd2l0aCB0aGUgb2JqZWN0LlxuICAjIyNcbiAgYWRkUm91dGU6IChwYXRoLCBvcHRpb25zLCBlbmRwb2ludHMpIC0+XG4gICAgIyBDcmVhdGUgYSBuZXcgcm91dGUgYW5kIGFkZCBpdCB0byBvdXIgbGlzdCBvZiBleGlzdGluZyByb3V0ZXNcbiAgICByb3V0ZSA9IG5ldyBzaGFyZS5Sb3V0ZSh0aGlzLCBwYXRoLCBvcHRpb25zLCBlbmRwb2ludHMpXG4gICAgQF9yb3V0ZXMucHVzaChyb3V0ZSlcblxuICAgIHJvdXRlLmFkZFRvQXBpKClcblxuICAgIHJldHVybiB0aGlzXG5cblxuICAjIyMqXG4gICAgR2VuZXJhdGUgcm91dGVzIGZvciB0aGUgTWV0ZW9yIENvbGxlY3Rpb24gd2l0aCB0aGUgZ2l2ZW4gbmFtZVxuICAjIyNcbiAgYWRkQ29sbGVjdGlvbjogKGNvbGxlY3Rpb24sIG9wdGlvbnM9e30pIC0+XG4gICAgbWV0aG9kcyA9IFsnZ2V0JywgJ3Bvc3QnLCAncHV0JywgJ2RlbGV0ZScsICdnZXRBbGwnXVxuICAgIG1ldGhvZHNPbkNvbGxlY3Rpb24gPSBbJ3Bvc3QnLCAnZ2V0QWxsJ11cblxuICAgICMgR3JhYiB0aGUgc2V0IG9mIGVuZHBvaW50c1xuICAgIGlmIGNvbGxlY3Rpb24gaXMgTWV0ZW9yLnVzZXJzXG4gICAgICBjb2xsZWN0aW9uRW5kcG9pbnRzID0gQF91c2VyQ29sbGVjdGlvbkVuZHBvaW50c1xuICAgIGVsc2VcbiAgICAgIGNvbGxlY3Rpb25FbmRwb2ludHMgPSBAX2NvbGxlY3Rpb25FbmRwb2ludHNcblxuICAgICMgRmxhdHRlbiB0aGUgb3B0aW9ucyBhbmQgc2V0IGRlZmF1bHRzIGlmIG5lY2Vzc2FyeVxuICAgIGVuZHBvaW50c0F3YWl0aW5nQ29uZmlndXJhdGlvbiA9IG9wdGlvbnMuZW5kcG9pbnRzIG9yIHt9XG4gICAgcm91dGVPcHRpb25zID0gb3B0aW9ucy5yb3V0ZU9wdGlvbnMgb3Ige31cbiAgICBleGNsdWRlZEVuZHBvaW50cyA9IG9wdGlvbnMuZXhjbHVkZWRFbmRwb2ludHMgb3IgW11cbiAgICAjIFVzZSBjb2xsZWN0aW9uIG5hbWUgYXMgZGVmYXVsdCBwYXRoXG4gICAgcGF0aCA9IG9wdGlvbnMucGF0aCBvciBjb2xsZWN0aW9uLl9uYW1lXG5cbiAgICAjIFNlcGFyYXRlIHRoZSByZXF1ZXN0ZWQgZW5kcG9pbnRzIGJ5IHRoZSByb3V0ZSB0aGV5IGJlbG9uZyB0byAob25lIGZvciBvcGVyYXRpbmcgb24gdGhlIGVudGlyZVxuICAgICMgY29sbGVjdGlvbiBhbmQgb25lIGZvciBvcGVyYXRpbmcgb24gYSBzaW5nbGUgZW50aXR5IHdpdGhpbiB0aGUgY29sbGVjdGlvbilcbiAgICBjb2xsZWN0aW9uUm91dGVFbmRwb2ludHMgPSB7fVxuICAgIGVudGl0eVJvdXRlRW5kcG9pbnRzID0ge31cbiAgICBpZiBfLmlzRW1wdHkoZW5kcG9pbnRzQXdhaXRpbmdDb25maWd1cmF0aW9uKSBhbmQgXy5pc0VtcHR5KGV4Y2x1ZGVkRW5kcG9pbnRzKVxuICAgICAgIyBHZW5lcmF0ZSBhbGwgZW5kcG9pbnRzIG9uIHRoaXMgY29sbGVjdGlvblxuICAgICAgXy5lYWNoIG1ldGhvZHMsIChtZXRob2QpIC0+XG4gICAgICAgICMgUGFydGl0aW9uIHRoZSBlbmRwb2ludHMgaW50byB0aGVpciByZXNwZWN0aXZlIHJvdXRlc1xuICAgICAgICBpZiBtZXRob2QgaW4gbWV0aG9kc09uQ29sbGVjdGlvblxuICAgICAgICAgIF8uZXh0ZW5kIGNvbGxlY3Rpb25Sb3V0ZUVuZHBvaW50cywgY29sbGVjdGlvbkVuZHBvaW50c1ttZXRob2RdLmNhbGwodGhpcywgY29sbGVjdGlvbilcbiAgICAgICAgZWxzZSBfLmV4dGVuZCBlbnRpdHlSb3V0ZUVuZHBvaW50cywgY29sbGVjdGlvbkVuZHBvaW50c1ttZXRob2RdLmNhbGwodGhpcywgY29sbGVjdGlvbilcbiAgICAgICAgcmV0dXJuXG4gICAgICAsIHRoaXNcbiAgICBlbHNlXG4gICAgICAjIEdlbmVyYXRlIGFueSBlbmRwb2ludHMgdGhhdCBoYXZlbid0IGJlZW4gZXhwbGljaXRseSBleGNsdWRlZFxuICAgICAgXy5lYWNoIG1ldGhvZHMsIChtZXRob2QpIC0+XG4gICAgICAgIGlmIG1ldGhvZCBub3QgaW4gZXhjbHVkZWRFbmRwb2ludHMgYW5kIGVuZHBvaW50c0F3YWl0aW5nQ29uZmlndXJhdGlvblttZXRob2RdIGlzbnQgZmFsc2VcbiAgICAgICAgICAjIENvbmZpZ3VyZSBlbmRwb2ludCBhbmQgbWFwIHRvIGl0J3MgaHR0cCBtZXRob2RcbiAgICAgICAgICAjIFRPRE86IENvbnNpZGVyIHByZWRlZmluaW5nIGEgbWFwIG9mIG1ldGhvZHMgdG8gdGhlaXIgaHR0cCBtZXRob2QgdHlwZSAoZS5nLiwgZ2V0QWxsOiBnZXQpXG4gICAgICAgICAgZW5kcG9pbnRPcHRpb25zID0gZW5kcG9pbnRzQXdhaXRpbmdDb25maWd1cmF0aW9uW21ldGhvZF1cbiAgICAgICAgICBjb25maWd1cmVkRW5kcG9pbnQgPSB7fVxuICAgICAgICAgIF8uZWFjaCBjb2xsZWN0aW9uRW5kcG9pbnRzW21ldGhvZF0uY2FsbCh0aGlzLCBjb2xsZWN0aW9uKSwgKGFjdGlvbiwgbWV0aG9kVHlwZSkgLT5cbiAgICAgICAgICAgIGNvbmZpZ3VyZWRFbmRwb2ludFttZXRob2RUeXBlXSA9XG4gICAgICAgICAgICAgIF8uY2hhaW4gYWN0aW9uXG4gICAgICAgICAgICAgIC5jbG9uZSgpXG4gICAgICAgICAgICAgIC5leHRlbmQgZW5kcG9pbnRPcHRpb25zXG4gICAgICAgICAgICAgIC52YWx1ZSgpXG4gICAgICAgICAgIyBQYXJ0aXRpb24gdGhlIGVuZHBvaW50cyBpbnRvIHRoZWlyIHJlc3BlY3RpdmUgcm91dGVzXG4gICAgICAgICAgaWYgbWV0aG9kIGluIG1ldGhvZHNPbkNvbGxlY3Rpb25cbiAgICAgICAgICAgIF8uZXh0ZW5kIGNvbGxlY3Rpb25Sb3V0ZUVuZHBvaW50cywgY29uZmlndXJlZEVuZHBvaW50XG4gICAgICAgICAgZWxzZSBfLmV4dGVuZCBlbnRpdHlSb3V0ZUVuZHBvaW50cywgY29uZmlndXJlZEVuZHBvaW50XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAsIHRoaXNcblxuICAgICMgQWRkIHRoZSByb3V0ZXMgdG8gdGhlIEFQSVxuICAgIEBhZGRSb3V0ZSBwYXRoLCByb3V0ZU9wdGlvbnMsIGNvbGxlY3Rpb25Sb3V0ZUVuZHBvaW50c1xuICAgIEBhZGRSb3V0ZSBcIiN7cGF0aH0vOmlkXCIsIHJvdXRlT3B0aW9ucywgZW50aXR5Um91dGVFbmRwb2ludHNcblxuICAgIHJldHVybiB0aGlzXG5cblxuICAjIyMqXG4gICAgQSBzZXQgb2YgZW5kcG9pbnRzIHRoYXQgY2FuIGJlIGFwcGxpZWQgdG8gYSBDb2xsZWN0aW9uIFJvdXRlXG4gICMjI1xuICBfY29sbGVjdGlvbkVuZHBvaW50czpcbiAgICBnZXQ6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgZ2V0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgZW50aXR5ID0gY29sbGVjdGlvbi5maW5kT25lIEB1cmxQYXJhbXMuaWRcbiAgICAgICAgICBpZiBlbnRpdHlcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXR5fVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnSXRlbSBub3QgZm91bmQnfVxuICAgIHB1dDogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBwdXQ6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBlbnRpdHlJc1VwZGF0ZWQgPSBjb2xsZWN0aW9uLnVwZGF0ZSBAdXJsUGFyYW1zLmlkLCBAYm9keVBhcmFtc1xuICAgICAgICAgIGlmIGVudGl0eUlzVXBkYXRlZFxuICAgICAgICAgICAgZW50aXR5ID0gY29sbGVjdGlvbi5maW5kT25lIEB1cmxQYXJhbXMuaWRcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXR5fVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnSXRlbSBub3QgZm91bmQnfVxuICAgIGRlbGV0ZTogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBkZWxldGU6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBpZiBjb2xsZWN0aW9uLnJlbW92ZSBAdXJsUGFyYW1zLmlkXG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IG1lc3NhZ2U6ICdJdGVtIHJlbW92ZWQnfVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnSXRlbSBub3QgZm91bmQnfVxuICAgIHBvc3Q6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgcG9zdDpcbiAgICAgICAgYWN0aW9uOiAtPlxuICAgICAgICAgIGVudGl0eUlkID0gY29sbGVjdGlvbi5pbnNlcnQgQGJvZHlQYXJhbXNcbiAgICAgICAgICBlbnRpdHkgPSBjb2xsZWN0aW9uLmZpbmRPbmUgZW50aXR5SWRcbiAgICAgICAgICBpZiBlbnRpdHlcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMVxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBlbnRpdHl9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwXG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdObyBpdGVtIGFkZGVkJ31cbiAgICBnZXRBbGw6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgZ2V0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgZW50aXRpZXMgPSBjb2xsZWN0aW9uLmZpbmQoKS5mZXRjaCgpXG4gICAgICAgICAgaWYgZW50aXRpZXNcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXRpZXN9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDA0XG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdVbmFibGUgdG8gcmV0cmlldmUgaXRlbXMgZnJvbSBjb2xsZWN0aW9uJ31cblxuXG4gICMjIypcbiAgICBBIHNldCBvZiBlbmRwb2ludHMgdGhhdCBjYW4gYmUgYXBwbGllZCB0byBhIE1ldGVvci51c2VycyBDb2xsZWN0aW9uIFJvdXRlXG4gICMjI1xuICBfdXNlckNvbGxlY3Rpb25FbmRwb2ludHM6XG4gICAgZ2V0OiAoY29sbGVjdGlvbikgLT5cbiAgICAgIGdldDpcbiAgICAgICAgYWN0aW9uOiAtPlxuICAgICAgICAgIGVudGl0eSA9IGNvbGxlY3Rpb24uZmluZE9uZSBAdXJsUGFyYW1zLmlkLCBmaWVsZHM6IHByb2ZpbGU6IDFcbiAgICAgICAgICBpZiBlbnRpdHlcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXR5fVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnVXNlciBub3QgZm91bmQnfVxuICAgIHB1dDogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBwdXQ6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBlbnRpdHlJc1VwZGF0ZWQgPSBjb2xsZWN0aW9uLnVwZGF0ZSBAdXJsUGFyYW1zLmlkLCAkc2V0OiBwcm9maWxlOiBAYm9keVBhcmFtc1xuICAgICAgICAgIGlmIGVudGl0eUlzVXBkYXRlZFxuICAgICAgICAgICAgZW50aXR5ID0gY29sbGVjdGlvbi5maW5kT25lIEB1cmxQYXJhbXMuaWQsIGZpZWxkczogcHJvZmlsZTogMVxuICAgICAgICAgICAge3N0YXR1czogXCJzdWNjZXNzXCIsIGRhdGE6IGVudGl0eX1cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ1VzZXIgbm90IGZvdW5kJ31cbiAgICBkZWxldGU6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgZGVsZXRlOlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgaWYgY29sbGVjdGlvbi5yZW1vdmUgQHVybFBhcmFtcy5pZFxuICAgICAgICAgICAge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBtZXNzYWdlOiAnVXNlciByZW1vdmVkJ31cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ1VzZXIgbm90IGZvdW5kJ31cbiAgICBwb3N0OiAoY29sbGVjdGlvbikgLT5cbiAgICAgIHBvc3Q6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICAjIENyZWF0ZSBhIG5ldyB1c2VyIGFjY291bnRcbiAgICAgICAgICBlbnRpdHlJZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIgQGJvZHlQYXJhbXNcbiAgICAgICAgICBlbnRpdHkgPSBjb2xsZWN0aW9uLmZpbmRPbmUgZW50aXR5SWQsIGZpZWxkczogcHJvZmlsZTogMVxuICAgICAgICAgIGlmIGVudGl0eVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAxXG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0eX1cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDBcbiAgICAgICAgICAgIHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ05vIHVzZXIgYWRkZWQnfVxuICAgIGdldEFsbDogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBnZXQ6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBlbnRpdGllcyA9IGNvbGxlY3Rpb24uZmluZCh7fSwgZmllbGRzOiBwcm9maWxlOiAxKS5mZXRjaCgpXG4gICAgICAgICAgaWYgZW50aXRpZXNcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXRpZXN9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDA0XG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdVbmFibGUgdG8gcmV0cmlldmUgdXNlcnMnfVxuXG5cbiAgIyMjXG4gICAgQWRkIC9sb2dpbiBhbmQgL2xvZ291dCBlbmRwb2ludHMgdG8gdGhlIEFQSVxuICAjIyNcbiAgX2luaXRBdXRoOiAtPlxuICAgIHNlbGYgPSB0aGlzXG4gICAgIyMjXG4gICAgICBBZGQgYSBsb2dpbiBlbmRwb2ludCB0byB0aGUgQVBJXG5cbiAgICAgIEFmdGVyIHRoZSB1c2VyIGlzIGxvZ2dlZCBpbiwgdGhlIG9uTG9nZ2VkSW4gaG9vayBpcyBjYWxsZWQgKHNlZSBSZXN0ZnVsbHkuY29uZmlndXJlKCkgZm9yXG4gICAgICBhZGRpbmcgaG9vaykuXG4gICAgIyMjXG4gICAgQGFkZFJvdXRlICdsb2dpbicsIHthdXRoUmVxdWlyZWQ6IGZhbHNlfSxcbiAgICAgIHBvc3Q6IC0+XG4gICAgICAgICMgR3JhYiB0aGUgdXNlcm5hbWUgb3IgZW1haWwgdGhhdCB0aGUgdXNlciBpcyBsb2dnaW5nIGluIHdpdGhcbiAgICAgICAgdXNlciA9IHt9XG4gICAgICAgIGlmIEBib2R5UGFyYW1zLnVzZXJcbiAgICAgICAgICBpZiBAYm9keVBhcmFtcy51c2VyLmluZGV4T2YoJ0AnKSBpcyAtMVxuICAgICAgICAgICAgdXNlci51c2VybmFtZSA9IEBib2R5UGFyYW1zLnVzZXJcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICB1c2VyLmVtYWlsID0gQGJvZHlQYXJhbXMudXNlclxuICAgICAgICBlbHNlIGlmIEBib2R5UGFyYW1zLnVzZXJuYW1lXG4gICAgICAgICAgdXNlci51c2VybmFtZSA9IEBib2R5UGFyYW1zLnVzZXJuYW1lXG4gICAgICAgIGVsc2UgaWYgQGJvZHlQYXJhbXMuZW1haWxcbiAgICAgICAgICB1c2VyLmVtYWlsID0gQGJvZHlQYXJhbXMuZW1haWxcblxuICAgICAgICAjIFRyeSB0byBsb2cgdGhlIHVzZXIgaW50byB0aGUgdXNlcidzIGFjY291bnQgKGlmIHN1Y2Nlc3NmdWwgd2UnbGwgZ2V0IGFuIGF1dGggdG9rZW4gYmFjaylcbiAgICAgICAgdHJ5XG4gICAgICAgICAgYXV0aCA9IEF1dGgubG9naW5XaXRoUGFzc3dvcmQgdXNlciwgQGJvZHlQYXJhbXMucGFzc3dvcmRcbiAgICAgICAgY2F0Y2ggZVxuICAgICAgICAgIHJldHVybiB7fSA9XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBlLmVycm9yXG4gICAgICAgICAgICBib2R5OiBzdGF0dXM6ICdlcnJvcicsIG1lc3NhZ2U6IGUucmVhc29uXG5cbiAgICAgICAgIyBHZXQgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlclxuICAgICAgICAjIFRPRE86IENvbnNpZGVyIHJldHVybmluZyB0aGUgdXNlciBpbiBBdXRoLmxvZ2luV2l0aFBhc3N3b3JkKCksIGluc3RlYWQgb2YgZmV0Y2hpbmcgaXQgYWdhaW4gaGVyZVxuICAgICAgICBpZiBhdXRoLnVzZXJJZCBhbmQgYXV0aC5hdXRoVG9rZW5cbiAgICAgICAgICBzZWFyY2hRdWVyeSA9IHt9XG4gICAgICAgICAgc2VhcmNoUXVlcnlbc2VsZi5fY29uZmlnLmF1dGgudG9rZW5dID0gQWNjb3VudHMuX2hhc2hMb2dpblRva2VuIGF1dGguYXV0aFRva2VuXG4gICAgICAgICAgQHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZVxuICAgICAgICAgICAgJ19pZCc6IGF1dGgudXNlcklkXG4gICAgICAgICAgICBzZWFyY2hRdWVyeVxuICAgICAgICAgIEB1c2VySWQgPSBAdXNlcj8uX2lkXG5cbiAgICAgICAgcmVzcG9uc2UgPSB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGF1dGh9XG5cbiAgICAgICAgIyBDYWxsIHRoZSBsb2dpbiBob29rIHdpdGggdGhlIGF1dGhlbnRpY2F0ZWQgdXNlciBhdHRhY2hlZFxuICAgICAgICBleHRyYURhdGEgPSBzZWxmLl9jb25maWcub25Mb2dnZWRJbj8uY2FsbCh0aGlzKVxuICAgICAgICBpZiBleHRyYURhdGE/XG4gICAgICAgICAgXy5leHRlbmQocmVzcG9uc2UuZGF0YSwge2V4dHJhOiBleHRyYURhdGF9KVxuXG4gICAgICAgIHJlc3BvbnNlXG5cbiAgICBsb2dvdXQgPSAtPlxuICAgICAgIyBSZW1vdmUgdGhlIGdpdmVuIGF1dGggdG9rZW4gZnJvbSB0aGUgdXNlcidzIGFjY291bnRcbiAgICAgIGF1dGhUb2tlbiA9IEByZXF1ZXN0LmhlYWRlcnNbJ3gtYXV0aC10b2tlbiddXG4gICAgICBoYXNoZWRUb2tlbiA9IEFjY291bnRzLl9oYXNoTG9naW5Ub2tlbiBhdXRoVG9rZW5cbiAgICAgIHRva2VuTG9jYXRpb24gPSBzZWxmLl9jb25maWcuYXV0aC50b2tlblxuICAgICAgaW5kZXggPSB0b2tlbkxvY2F0aW9uLmxhc3RJbmRleE9mICcuJ1xuICAgICAgdG9rZW5QYXRoID0gdG9rZW5Mb2NhdGlvbi5zdWJzdHJpbmcgMCwgaW5kZXhcbiAgICAgIHRva2VuRmllbGROYW1lID0gdG9rZW5Mb2NhdGlvbi5zdWJzdHJpbmcgaW5kZXggKyAxXG4gICAgICB0b2tlblRvUmVtb3ZlID0ge31cbiAgICAgIHRva2VuVG9SZW1vdmVbdG9rZW5GaWVsZE5hbWVdID0gaGFzaGVkVG9rZW5cbiAgICAgIHRva2VuUmVtb3ZhbFF1ZXJ5ID0ge31cbiAgICAgIHRva2VuUmVtb3ZhbFF1ZXJ5W3Rva2VuUGF0aF0gPSB0b2tlblRvUmVtb3ZlXG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlIEB1c2VyLl9pZCwgeyRwdWxsOiB0b2tlblJlbW92YWxRdWVyeX1cblxuICAgICAgcmVzcG9uc2UgPSB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IHttZXNzYWdlOiAnWW91XFwndmUgYmVlbiBsb2dnZWQgb3V0ISd9fVxuXG4gICAgICAjIENhbGwgdGhlIGxvZ291dCBob29rIHdpdGggdGhlIGF1dGhlbnRpY2F0ZWQgdXNlciBhdHRhY2hlZFxuICAgICAgZXh0cmFEYXRhID0gc2VsZi5fY29uZmlnLm9uTG9nZ2VkT3V0Py5jYWxsKHRoaXMpXG4gICAgICBpZiBleHRyYURhdGE/XG4gICAgICAgIF8uZXh0ZW5kKHJlc3BvbnNlLmRhdGEsIHtleHRyYTogZXh0cmFEYXRhfSlcblxuICAgICAgcmVzcG9uc2VcblxuICAgICMjI1xuICAgICAgQWRkIGEgbG9nb3V0IGVuZHBvaW50IHRvIHRoZSBBUElcblxuICAgICAgQWZ0ZXIgdGhlIHVzZXIgaXMgbG9nZ2VkIG91dCwgdGhlIG9uTG9nZ2VkT3V0IGhvb2sgaXMgY2FsbGVkIChzZWUgUmVzdGZ1bGx5LmNvbmZpZ3VyZSgpIGZvclxuICAgICAgYWRkaW5nIGhvb2spLlxuICAgICMjI1xuICAgIEBhZGRSb3V0ZSAnbG9nb3V0Jywge2F1dGhSZXF1aXJlZDogdHJ1ZX0sXG4gICAgICBnZXQ6IC0+XG4gICAgICAgIGNvbnNvbGUud2FybiBcIldhcm5pbmc6IERlZmF1bHQgbG9nb3V0IHZpYSBHRVQgd2lsbCBiZSByZW1vdmVkIGluIFJlc3RpdnVzIHYxLjAuIFVzZSBQT1NUIGluc3RlYWQuXCJcbiAgICAgICAgY29uc29sZS53YXJuIFwiICAgIFNlZSBodHRwczovL2dpdGh1Yi5jb20va2FobWFsaS9tZXRlb3ItcmVzdGl2dXMvaXNzdWVzLzEwMFwiXG4gICAgICAgIHJldHVybiBsb2dvdXQuY2FsbCh0aGlzKVxuICAgICAgcG9zdDogbG9nb3V0XG5cblJlc3RpdnVzID0gQFJlc3RpdnVzXG4iXX0=
