var require = meteorInstall({"imports":{"api":{"Deleted":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/Deleted/server/publications.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Deleted;

module.link("../deleted", {
  _Deleted(v) {
    _Deleted = v;
  }

}, 1);
Meteor.publish(null, () => _Deleted.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"deleted.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/Deleted/deleted.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Deleted: () => _Deleted
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);

const _Deleted = new Mongo.Collection('deleted');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/Deleted/methods.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 1);

let _Deleted;

module.link("./deleted", {
  _Deleted(v) {
    _Deleted = v;
  }

}, 2);
Meteor.methods({
  //  for resources
  insertDeleted: (id, col, file = null) => {
    check(id, String);
    check(col, Match.OneOf(String, null, undefined));
    check(file, Match.OneOf(Object, null, undefined));

    _Deleted.insert({
      delId: id,
      file,
      col,
      sync: {} // this should change too

    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"accounts":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/accounts/server/publications.js                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.publish('all.users', function allUsers() {
  if (!this.userId && !Roles.userIsInRole(this.userId, ['admin'])) {
    return this.ready();
  }

  return Meteor.users.find({});
});
Meteor.publish(null, () => Meteor.roles.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"account.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/accounts/account.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
Meteor.users.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
const UserProfile = new SimpleSchema({
  name: String,
  gender: String,
  status: Number,
  stats: Number
});
const User = new SimpleSchema({
  emails: Array,
  'emails.$': Object,
  'emails.$.address': {
    type: String,
    regEx: SimpleSchema.RegEx.Email
  },
  'emails.$.verified': Boolean,
  profile: UserProfile,
  createdAt: Date,
  services: {
    type: Object,
    optional: true,
    blackbox: true
  },
  roles: {
    type: Array,
    optional: true,
    blackbox: true
  },
  'roles.$': String
});
Meteor.users.attachSchema(User);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/accounts/methods.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
Meteor.methods({
  'user.insert': user => {
    check(user, {
      email: String,
      password: String,
      profile: Object
    });
    Accounts.createUser(user);
  },
  'account.check': email => {
    check(email, String);
    const initialUser = Meteor.users.findOne();
    const userId = initialUser._id;
    const user = Accounts.findUserByEmail(email);

    if (Meteor.users.find().count() === 1) {
      Roles.addUsersToRoles(userId, 'admin');
      Meteor.users.update({
        _id: userId
      }, {
        $set: {
          'profile.status': 1
        }
      });
    } else if (!user) {
      return 'Sorry email not identified';
    } // removed the account approval for now
    // else if ((!user.profile.status || user.profile.status === 2)) {
    //   return 'Sorry account not activated. Inform Adminstrator';
    // }


    return false;
  },
  // eslint-disable-next-line
  'user.approve': function (id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Meteor.users.update({
        _id: id
      }, {
        $set: {
          'profile.status': 1
        }
      });
    } else {
      throw new Meteor.Error('Sorry', "You don't have permissions to remove a user");
    }
  },
  // eslint-disable-next-line
  'user.suspend': function (id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Meteor.users.update({
        _id: id
      }, {
        $set: {
          'profile.status': 2
        }
      });
    } else {
      throw new Meteor.Error('Sorry', "You don't have permissions to remove a user");
    }
  },

  promoteUser(id, role) {
    check(id, String);
    check(role, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      // Make sure the admin doesn't block himself out of the platform
      // Roles.addUsersToRoles(id, role);
      if (id === this.userId) {
        throw new Meteor.Error('Oops', 'You can not change your own Role as an Admin');
      }

      Roles.setUserRoles(id, role);
    } else {
      throw new Meteor.Error('Sorry', "You don't have permissions to promote a user");
    }
  },

  removeUser(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Meteor.users.remove(id);
    } else {
      throw new Meteor.Error('Sorry', "You don't have permissions to remove a user");
    }
  },

  // eslint-disable-next-line
  'user.update': function (id, namef) {
    check(id, String);
    check(namef, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Meteor.users.update({
        _id: id
      }, {
        $set: {
          'profile.name': namef
        }
      });
    } else {
      throw new Meteor.Error('Sorry', "You don't have permissions to remove a user");
    }
  },

  accountExist(email) {
    check(email, String);
    const user = Accounts.findUserByEmail(email);

    if (user) {
      return 'Sorry email already registered.';
    }

    return false;
  },

  // return the number of users
  // eslint-disable-next-line
  'num.users': function () {
    const users = Meteor.users.find().count();
    return users;
  },

  changeUserPassword(userId, password) {
    check(userId, String);
    check(password, String);
    const isAdmin = Roles.userIsInRole(this.userId, ['admin']);

    if (isAdmin) {
      Accounts.setPassword(userId, password);
    } else {
      throw new Meteor.Error('Sorry', 'An Error Ocurred');
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"bookmarks":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/bookmarks/server/publications.js                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Bookmark;

module.link("../bookmarks", {
  _Bookmark(v) {
    _Bookmark = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
Meteor.publish('bookmarks', function getBookmarks() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return _Bookmark.find({});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"bookmarks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/bookmarks/bookmarks.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Bookmark: () => _Bookmark
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Bookmark = new Mongo.Collection('bookmarks', {
  idGeneration: 'STRING'
});

_Bookmark.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const bookMarkSchema = new SimpleSchema({
  user: String,
  title: String,
  description: String,
  url: String,
  color: String,
  path: String,
  createdAt: Date
});

_Bookmark.attachSchema(bookMarkSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/bookmarks/methods.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);

let _Bookmark;

module.link("./bookmarks", {
  _Bookmark(v) {
    _Bookmark = v;
  }

}, 2);
// there should be added a better way of inserting a bookmark not updating the non-existing one
Meteor.methods({
  updateBookmark(bookmark, title, description, url, color, path) {
    // TODO: construct the whole input as an object to have it checked once
    check(bookmark, Match.OneOf(undefined, null, String));
    check(title, String);
    check(description, String);
    check(url, String);
    check(color, String);
    check(path, String);

    _Bookmark.update({
      _id: bookmark
    }, {
      $set: {
        user: this.userId,
        title,
        description,
        url,
        color,
        path,
        createdAt: new Date()
      }
    }, {
      upsert: true
    });
  },

  removeBookmark(id) {
    check(id, String);

    _Bookmark.remove({
      _id: id,
      user: this.userId
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"courses":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/courses/server/publications.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Courses;

module.link("../courses", {
  _Courses(v) {
    _Courses = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
// publishes all courses;
Meteor.publish('courses', function allCourses() {
  if (!isAuthRequired()) {
    return this.ready();
  }

  return _Courses.find({});
}); // publish when school is available

Meteor.publish('school.courses', function programCourses(id) {
  check(id, String);

  if (!isAuthRequired()) {
    return this.ready();
  }

  return _Courses.find({
    'details.programId': id
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"courses.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/courses/courses.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Courses: () => _Courses
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Courses = new Mongo.Collection('course');

_Courses.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const Schema = {};
Schema.details = new SimpleSchema({
  schoolId: {
    type: String,
    optional: true
  },
  programId: {
    type: String,
    optional: true
  },
  language: String
});
Schema.Course = new SimpleSchema({
  name: String,
  code: String,
  details: Schema.details,
  createdAt: Date,
  createdBy: String
});

_Courses.attachSchema(Schema.Course);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/courses/methods.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);

let _Courses;

module.link("./courses", {
  _Courses(v) {
    _Courses = v;
  }

}, 3);

let _Units;

module.link("../units/units", {
  _Units(v) {
    _Units = v;
  }

}, 4);
Meteor.methods({
  'course.add': function courseAdd(id, course, courseCode, details) {
    check(id, String);
    check(course, String);
    check(courseCode, String);
    check(details, Object);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Courses.insert({
        _id: id,
        name: course,
        code: courseCode,
        details,
        createdAt: new Date(),
        createdBy: this.userId
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to make changes');
    }
  },

  // eslint-disable-next-line
  'course.edit'(id, course, courseCode, language, ownerId) {
    check(id, String);
    check(course, String);
    check(courseCode, String);
    check(language, String);
    check(ownerId, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Courses.update({
        _id: id
      }, {
        $set: {
          name: course,
          code: courseCode,
          'details.language': language
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'course.remove': function (id) {
    check(id, String);

    const units = _Units.find({
      'details.courseId': id
    }).fetch();

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      if (units.length >= 1) {
        throw new Meteor.Error('sorry', 'The selected course has units that depend on it');
      } else if (units.length === 0) {
        _Courses.remove(id);
      } else {
        throw new Meteor.Error('no-rights', 'You are not allowed to remove the selected course');
      }
    }
  },
  // eslint-disable-next-line
  'courses.count': function () {
    _Courses.find().count();
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"externallink":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/externallink/server/publications.js                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _ExternalLink;

module.link("../externallink", {
  _ExternalLink(v) {
    _ExternalLink = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
Meteor.publish('externallinks', function getExternalLinks() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return _ExternalLink.find({});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"externallink.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/externallink/externallink.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _ExternalLink: () => _ExternalLink
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _ExternalLink = new Mongo.Collection('externallinks', {
  idGeneration: 'STRING'
});

_ExternalLink.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const externalLinkSchema = new SimpleSchema({
  name: String,
  url: String,
  createdAt: Date
});

_ExternalLink.attachSchema(externalLinkSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/externallink/methods.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);

let _ExternalLink;

module.link("./externallink", {
  _ExternalLink(v) {
    _ExternalLink = v;
  }

}, 3);
Meteor.methods({
  'externallink.add': function addExternalLink(id, externallink, url) {
    check(id, String);
    check(externallink, String);
    check(url, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _ExternalLink.insert({
        _id: id,
        name: externallink,
        url,
        createdAt: new Date(),
        createdBy: this.userId
      }); // You can also trigger if something wrong happens

    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'externallink.edit'(id, externallink, url) {
    check(id, String);
    check(externallink, String);
    check(url, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _ExternalLink.update({
        _id: id
      }, {
        $set: {
          name: externallink,
          url
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'externallink.remove'(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _ExternalLink.remove(id);
    } else {
      throw new Meteor.Error('no-rights', 'You are not allowed to remove the selected external Link');
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"feedback":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/feedback/server/publications.js                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Feedback;

module.link("../feedback", {
  _Feedback(v) {
    _Feedback = v;
  }

}, 1);
Meteor.publish('feedbacks', () => _Feedback.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"feedback.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/feedback/feedback.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Feedback: () => _Feedback
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Feedback = new Mongo.Collection('feedback', {
  idGeneration: 'STRING'
});

// attach the schema and define the rules
const Schema = {};
Schema.feedSchema = new SimpleSchema({
  title: String,
  feedback: String,
  link: String,
  createdAt: Date,
  createdBy: String
});

_Feedback.attachSchema(Schema.feedSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/feedback/methods.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Feedback;

module.link("./feedback", {
  _Feedback(v) {
    _Feedback = v;
  }

}, 1);
Meteor.methods({
  'feedback.insert': (title, feedback, link, name) => {
    check(title, String);
    check(feedback, String);
    check(link, String);
    check(name, String);

    _Feedback.insert({
      title,
      feedback,
      link,
      createdAt: new Date(),
      createdBy: name
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"notifications":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/notifications/server/publications.js                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Notifications;

module.link("../notifications", {
  _Notifications(v) {
    _Notifications = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
Meteor.publish('notifications', function publishNote() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return _Notifications.find({
    userId: this.userId
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/notifications/methods.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);

let _Notifications;

module.link("./notifications", {
  _Notifications(v) {
    _Notifications = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
// eslint-disable-line
Meteor.methods({
  insertNotification(title, category, unitId = '', topicId = '', fileId = '') {
    check(unitId, String);
    check(topicId, String);
    check(fileId, String);
    check(title, String);
    check(category, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      const testUsers = Meteor.users.find(); // eslint-disable-next-line

      testUsers.map(usr => {
        const _id = new Meteor.Collection.ObjectID().valueOf();

        const userId = usr._id; // insert in Notifications

        _Notifications.insert({
          _id,
          userId,
          unitId,
          topicId,
          fileId,
          title,
          category,
          createdAt: new Date(),
          read: false
        });
      });
    } else {
      throw new Meteor.Error('oops', 'There was a problem updating Notifications');
    }
  },

  markRead(id, bool) {
    check(id, String);
    check(bool, Boolean);

    _Notifications.update({
      _id: id,
      userId: this.userId
    }, {
      $set: {
        read: bool
      }
    });
  },

  // remove notifications that belong to the user and have been read
  dropUserNotifications() {
    return _Notifications.remove({
      read: true,
      userId: this.userId
    });
  },

  // remove notifications that belong to the user
  dropAllUserNotifications() {
    return _Notifications.remove({
      userId: this.userId
    });
  },

  // remove notifications older than 30days for all users
  dropNotifications() {
    const date = new Date();
    const daysToDeletion = 30; // 'Delete after 30days'

    const deletionDate = new Date(date.setDate(date.getDate() - daysToDeletion));
    return _Notifications.remove({
      createdAt: {
        $lte: deletionDate
      }
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/notifications/notifications.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Notifications: () => _Notifications
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Notifications = new Mongo.Collection('notification');

_Notifications.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const notefSchema = new SimpleSchema({
  userId: String,
  unitId: {
    type: String,
    optional: true
  },
  topicId: {
    type: String,
    optional: true
  },
  fileId: {
    type: String,
    optional: true
  },
  title: String,
  category: String,
  createdAt: Date,
  read: Boolean
});

_Notifications.attachSchema(notefSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"resources":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/resources/server/publications.js                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Resources, References;
module.link("../resources", {
  Resources(v) {
    Resources = v;
  },

  References(v) {
    References = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
Meteor.publish('resourcess', function allResource() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return Resources.find().cursor;
});
Meteor.publish('references', function allResource() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return References.find().cursor;
}); // Meteor.publish('resourcess', () => Resources.find().cursor);
// Meteor.publish('references', () => References.find().cursor);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/resources/methods.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
let Resources, References;
module.link("./resources", {
  Resources(v) {
    Resources = v;
  },

  References(v) {
    References = v;
  }

}, 3);
Meteor.methods({
  updateResource(id, resource) {
    check(id, String);
    check(resource, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      Resources.update({
        _id: id
      }, {
        $set: {
          name: resource
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  updateReference(id, reference) {
    check(id, String);
    check(reference, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      References.update({
        _id: id
      }, {
        $set: {
          name: reference
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  removeResource(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      Resources.remove(id);
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to remove the resource');
    }
  },

  removeReference(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      References.remove(id);
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to remove the resource');
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resources.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/resources/resources.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Egranary: () => _Egranary,
  Resources: () => Resources,
  References: () => References
});
let Mongo, MongoInternals;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  },

  MongoInternals(v) {
    MongoInternals = v;
  }

}, 0);
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 1);
let Grid;
module.link("gridfs-stream", {
  default(v) {
    Grid = v;
  }

}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 3);
// eslint-disable-line
let gfs;

if (Meteor.isServer) {
  gfs = Grid(MongoInternals.defaultRemoteCollectionDriver().mongo.db, MongoInternals.NpmModule);
}

const _Egranary = new Mongo.Collection('egranary', {
  idGeneration: 'STRING'
});

// void kept for the sync
const validTypes = ['png', 'jpg', 'jpeg', 'mp4', 'pdf', 'mp3', 'pptx', 'ppt', 'webm', 'ogg', 'txt'];
const Resources = new FilesCollection({
  collectionName: 'Resources',
  allowClientCode: true,

  // Disallow remove files from Client
  onBeforeUpload(file) {
    // Allow upload files under 5Gb, and only in png/jpg/jpeg formats
    if (file.size >= 5368709120) {
      return 'Please upload files, with size equal or less than 5GB';
    } else if (!validTypes.includes(file.ext)) {
      return `Please upload either one of the following formats ${validTypes.join()}`;
    }

    return true;
  },

  onAfterUpload(file) {
    // Move file to GridFS
    Object.keys(file.versions).forEach(versionName => {
      const metadata = {
        versionName,
        fileId: file._id,
        storedAt: new Date()
      }; // Optional

      const writeStream = gfs.createWriteStream({
        filename: file.name,
        metadata
      });
      fs.createReadStream(file.versions[versionName].path).pipe(writeStream);
      writeStream.on('close', Meteor.bindEnvironment(uploadedFile => {
        const property = `versions.${versionName}.meta.gridFsFileId`; // If we store the ObjectID itself, Meteor (EJSON?) seems to convert it to a
        // LocalCollection.ObjectID, which GFS doesn't understand.

        this.collection.update(file._id.toString(), {
          $set: {
            [property]: uploadedFile._id.toString()
          }
        });
        this.unlink(this.collection.findOne(file._id.toString()), versionName); // Unlink file by version from FS
      }));
    });
  },

  interceptDownload(http, file, versionName) {
    const _id = (file.versions[versionName].meta || {}).gridFsFileId;

    if (_id) {
      const readStream = gfs.createReadStream({
        _id
      });
      readStream.on('error', err => {
        throw err;
      });
      readStream.pipe(http.response);
    }

    return Boolean(_id);
  },

  onAfterRemove(images) {
    images.forEach(image => {
      Object.keys(image.versions).forEach(versionName => {
        const _id = (image.versions[versionName].meta || {}).gridFsFileId;

        if (_id) {
          gfs.remove({
            _id
          }, err => {
            if (err) throw err;
          });
        }
      });
    });
  }

});

if (Meteor.isServer) {
  Resources.allowClient();
}

const References = new FilesCollection({
  collectionName: 'References',
  allowClientCode: false,

  onBeforeUpload(file) {
    // Allow upload files under 5Gb, and only in listed formats
    if (file.size >= 5368709120) {
      return 'Please upload files, with size equal or less than 5GB';
    } else if (!validTypes.includes(file.ext)) {
      return `Please upload either one of the following formats ${validTypes.join()}`;
    }

    return true;
  },

  onAfterUpload(file) {
    // Move file to GridFS
    Object.keys(file.versions).forEach(versionName => {
      const metadata = {
        versionName,
        fileId: file._id,
        storedAt: new Date()
      }; // Optional

      const writeStream = gfs.createWriteStream({
        filename: file.name,
        metadata
      });
      fs.createReadStream(file.versions[versionName].path).pipe(writeStream);
      writeStream.on('close', Meteor.bindEnvironment(uploadedFile => {
        const property = `versions.${versionName}.meta.gridFsFileId`;
        this.collection.update(file._id.toString(), {
          $set: {
            [property]: uploadedFile._id.toString()
          }
        });
        this.unlink(this.collection.findOne(file._id.toString()), versionName); // Unlink file by version from FS
      }));
    });
  },

  interceptDownload(http, file, versionName) {
    const _id = (file.versions[versionName].meta || {}).gridFsFileId;

    if (_id) {
      const readStream = gfs.createReadStream({
        _id
      });
      readStream.on('error', err => {
        throw err;
      });
      readStream.pipe(http.response);
    }

    return Boolean(_id);
  },

  onAfterRemove(files) {
    files.forEach(file => {
      Object.keys(file.versions).forEach(versionName => {
        const _id = (file.versions[versionName].meta || {}).gridFsFileId;

        if (_id) {
          // eslint-disable-line
          gfs.remove({
            _id
          }, err => {
            if (err) throw err;
          });
        }
      });
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"search":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/search/server/publications.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _SearchData;

module.link("../search", {
  _SearchData(v) {
    _SearchData = v;
  }

}, 1);
Meteor.publish(null, () => _SearchData.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/search/methods.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);

let _SearchData;

module.link("./search", {
  _SearchData(v) {
    _SearchData = v;
  }

}, 3);
Meteor.methods({
  // eslint-disable-next-line
  removeSearchData(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _SearchData.remove(id);
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  updateSearch: function (id, name) {
    check(id, String);
    check(name, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _SearchData.update({
        _id: id
      }, {
        $set: {
          name,
          _ids: {}
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },
  // eslint-disable-next-line
  'insert.search': function (id, ids, name, category) {
    check(id, String);
    check(ids, Object);
    check(name, String);
    check(category, String);

    _SearchData.insert({
      _id: id,
      ids,
      name,
      category,
      createdAt: new Date()
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/search/search.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _SearchData: () => _SearchData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _SearchData = new Mongo.Collection('search', {
  idGeneration: 'STRING'
});

_SearchData.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const Schema = {};
Schema.ids = new SimpleSchema({
  unitId: {
    type: String,
    optional: true
  },
  resourceId: {
    type: String,
    optional: true
  },
  topicId: {
    type: String,
    optional: true
  },
  courseId: {
    type: String,
    optional: true
  }
});
Schema.searchSchema = new SimpleSchema({
  ids: Schema.ids,
  name: String,
  category: String,
  createdAt: Date
});

_SearchData.attachSchema(Schema.searchSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"settings":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/server/publications.js                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Institution;
module.link("../institution", {
  Institution(v) {
    Institution = v;
  }

}, 1);
let Slides;
module.link("../slides", {
  Slides(v) {
    Slides = v;
  }

}, 2);

let _Settings;

module.link("../settings", {
  _Settings(v) {
    _Settings = v;
  }

}, 3);
let Titles;
module.link("../titles", {
  Titles(v) {
    Titles = v;
  }

}, 4);
Meteor.publish(null, () => _Settings.find({}));
Meteor.publish('titles', () => Titles.find({}));
Meteor.publish('slides', () => Slides.find().cursor);
Meteor.publish('logo', () => Institution.find().cursor);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"institution.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/institution.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Institution: () => Institution
});
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 0);
const Institution = new FilesCollection({
  collectionName: 'Institution',
  storagePath: `${process.env.PWD}/public/uploads/logos/`,
  allowClientCode: false,

  // Disallow remove files from Client
  onBeforeUpload(file) {
    // Allow upload files under 5Gb, and only in png/jpg/jpeg formats
    if (file.size <= 1009120 && /png|jpg|jpeg/i.test(file.extension)) {
      return true;
    }

    return 'Please upload image, with size equal or less than 1MB';
  },

  onAfterUpload(file) {
    if (Meteor.isServer) {
      // check real mimetype
      const {
        Magic,
        MAGIC_MIME_TYPE
      } = require('mmmagic'); // eslint-disable-line


      const magic = new Magic(MAGIC_MIME_TYPE);
      magic.detectFile(file.path, Meteor.bindEnvironment((err, mimeType) => {
        // eslint-disable-next-line
        if (err || !~mimeType.indexOf('image')) {
          // is not a real image --> delete
          this.remove(file._id);
        }
      }));
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/methods.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);

let _Settings;

module.link("./settings", {
  _Settings(v) {
    _Settings = v;
  }

}, 2);

let _Slides, Slides;

module.link("./slides", {
  _Slides(v) {
    _Slides = v;
  },

  Slides(v) {
    Slides = v;
  }

}, 3);
let Institution;
module.link("./institution", {
  Institution(v) {
    Institution = v;
  }

}, 4);
let Titles;
module.link("./titles", {
  Titles(v) {
    Titles = v;
  }

}, 5);
Meteor.methods({
  addSliding(id, sku, file) {
    check(id, String);
    check(sku, String);
    check(file, Object);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      _Slides.insert({
        name: sku,
        file,
        createdAt: new Date(),
        CreatedBy: this.userId
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  editSlides(slideId, slideName) {
    check(slideId, String);
    check(slideName, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Slides.update({
        _id: slideId
      }, {
        $set: {
          name: slideName
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  removeSlides(id) {
    check(id, String);

    if (Roles.userIsInRole(this.userId, ['admin'])) {
      Slides.remove(id);
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  updateLogo(instId, name, tagline, logo, file) {
    check(instId, String);
    check(name, String);
    check(tagline, String);
    check(logo, String);
    check(file, Object);
    Institution.update({
      _id: instId
    }, {
      $set: {
        name,
        tagline,
        logo,
        file
      }
    });
  },

  // eslint-disable-next-line
  'insert.title'(title, sub_title) {
    check(title, String);
    check(sub_title, String);
    const today = new Date();
    Titles.insert({
      title,
      sub_title,
      editedAt: today
    });
  },

  // eslint-disable-next-line
  'update.title'(id, title, sub) {
    check(id, String);
    check(title, String);
    check(sub, String);
    Titles.update({
      _id: id
    }, {
      $set: {
        title,
        sub_title: sub,
        editedAt: new Date()
      }
    });
  },

  updateColors(id, main, button, sidebar) {
    check(id, String);
    check(main, String);
    check(button, Match.OneOf(Object, null, undefined));
    check(sidebar, Match.OneOf(String, null, undefined));

    _Settings.update({
      _id: id
    }, {
      $set: {
        main,
        button,
        sidebar
      }
    }, {
      upsert: true
    });
  },

  // eslint-disable-next-line
  updateSettings(id, name, tag, server, isConfigured) {
    check(id, String);
    check(name, String);
    check(tag, String);
    check(server, String);
    check(isConfigured, Boolean);

    _Settings.update({
      _id: id
    }, {
      $set: {
        name,
        tag,
        server,
        isConfigured
      }
    });
  },

  // prevent Updating when user is not logged in
  setDarkMode(isSet) {
    check(isSet, Boolean);

    if (this.userId) {
      return _Settings.update({}, {
        $set: {
          isDark: isSet
        }
      } // { upsert: true },
      );
    }

    throw new Meteor.Error('Auth', 'You are not authenticated');
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"settings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/settings.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Settings: () => _Settings
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);

const _Settings = new Mongo.Collection('settings');

_Settings.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"slides.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/slides.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Slides: () => Slides
});
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 0);
const Slides = new FilesCollection({
  collectionName: 'Slides',
  storagePath: `${process.env.PWD}/public/uploads/slides/`,
  allowClientCode: false,

  // Disallow remove files from Client
  onBeforeUpload(file) {
    // Allow upload files under 5Gb, and only in png/jpg/jpeg formats
    if (file.size <= 1009120 && /png|jpg|jpeg/i.test(file.extension)) {
      return true;
    }

    return 'Please upload image, with size equal or less than 1MB';
  },

  onAfterUpload(file) {
    if (Meteor.isServer) {
      // check real mimetype
      const {
        Magic,
        MAGIC_MIME_TYPE
      } = require('mmmagic'); // eslint-disable-line


      const magic = new Magic(MAGIC_MIME_TYPE);
      magic.detectFile(file.path, Meteor.bindEnvironment((err, mimeType) => {
        // eslint-disable-next-line
        if (err || !~mimeType.indexOf('image')) {
          // is not a real image --> delete
          this.remove(file._id);
        }
      }));
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"titles.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/settings/titles.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Titles: () => Titles
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Titles = new Mongo.Collection('title');
Titles.deny({
  insert: () => false,
  update: () => false,
  remove: () => false
});
const titleSchema = new SimpleSchema({
  title: String,
  sub_title: {
    type: String,
    optional: true
  },
  editedAt: Date
});
Titles.attachSchema(titleSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"statistics":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/statistics/server/publications.js                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Statistics;

module.link("../statistics", {
  _Statistics(v) {
    _Statistics = v;
  }

}, 1);
Meteor.publish(null, () => _Statistics.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"csvMethods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/statistics/csvMethods.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Statistics;

module.link("../../api/statistics/statistics", {
  _Statistics(v) {
    _Statistics = v;
  }

}, 1);
const db = {
  statistics: _Statistics
};
Meteor.methods({
  DataToCSV(collection) {
    check(collection, Array); //  var collection = collection.find(query).fetch();

    const heading = true; // Optional, defaults to true

    const delimiter = ','; // Optional, defaults to ",";

    return exportcsv.exportToCSV(collection, heading, delimiter);
  }

});
Meteor.methods({
  getCSVData(collection, query, mUser) {
    check(collection, String);
    check(query, Object);
    check(mUser, Object);
    const data = db[collection].find(query).fetch();

    if (data.length === 0) {
      return false;
    }

    data.forEach(v => {
      v.name = `${mUser.profile.name}`;
      v.email = mUser.emails[0].address;
      v.gender = mUser.profile.gender;
    });
    const heading = true; // Optional, defaults to true

    const delimiter = ';'; // Optional, defaults to ",";

    return exportcsv.exportToCSV(data, heading, delimiter);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"statistics.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/statistics/statistics.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Statistics: () => _Statistics
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);

const _Statistics = new Mongo.Collection('statistic');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"sync":{"server":{"sync.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/sync/server/sync.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let syncData;
module.link("../syncData", {
  syncData(v) {
    syncData = v;
  }

}, 1);
Meteor.publish('syncdata', () => syncData.find({}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"endpoint.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/sync/endpoint.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Restivus;
module.link("meteor/mrest:restivus", {
  Restivus(v) {
    Restivus = v;
  }

}, 1);
let Resources, References;
module.link("../resources/resources", {
  Resources(v) {
    Resources = v;
  },

  References(v) {
    References = v;
  }

}, 2);

let _Courses;

module.link("../courses/courses", {
  _Courses(v) {
    _Courses = v;
  }

}, 3);

let _SearchData;

module.link("../search/search", {
  _SearchData(v) {
    _SearchData = v;
  }

}, 4);

let _Statistics;

module.link("../statistics/statistics", {
  _Statistics(v) {
    _Statistics = v;
  }

}, 5);
let Titles;
module.link("../settings/titles", {
  Titles(v) {
    Titles = v;
  }

}, 6);

let _Topics;

module.link("../topics/topics", {
  _Topics(v) {
    _Topics = v;
  }

}, 7);

let _Units;

module.link("../units/units", {
  _Units(v) {
    _Units = v;
  }

}, 8);
// disable user auth for GET
const Api = new Restivus({
  useDefaultAuth: true,
  prettyJson: true
}); // GET endpoint for the references

Api.addCollection(References, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: true
  },
  endpoints: {
    get: {
      authRequired: true
    }
  }
}); // GET endpoint for search

Api.addCollection(_SearchData, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: true
  },
  endpoints: {
    get: {
      authRequired: true
    }
  }
}); // GET endpoint for statistics

Api.addCollection(_Statistics, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: true
  },
  endpoints: {
    get: {
      authRequired: true
    }
  }
}); // GET endpoint for titles

Api.addCollection(Titles, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: true
  },
  endpoints: {
    get: {
      authRequired: true
    }
  }
}); // GET endpoint for Topics

Api.addCollection(_Topics, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: false
  },
  endpoints: {
    get: {
      authRequired: false
    }
  }
}); // GET endpoint for Topics

Api.addCollection(_Units, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: false
  },
  endpoints: {
    get: {
      authRequired: false
    }
  }
}); // GET endpoint for COurses

Api.addCollection(_Courses, {
  excludedEndpoints: ['put', 'post', 'delete'],
  routeOptions: {
    authRequired: false
  },
  endpoints: {
    get: {
      authRequired: false
    }
  }
});
Api.addCollection(Meteor.users, {
  excludedEndpoints: ['put', 'post'],
  routeOptions: {
    authRequired: true
  },
  endpoints: {
    get: {
      authRequired: true
    }
  }
});
Api.addRoute('resources', {
  authRequired: false
}, // temp
{
  get: {
    action() {
      const resources = Resources.find({}).fetch();

      if (resources) {
        return {
          status: 'success',
          data: resources
        };
      }

      return {
        statusCode: 400,
        body: {
          status: 'fail',
          message: 'get me thsi'
        }
      };
    }

  }
});
Api.addRoute('references', {
  authRequired: true
}, {
  get: {
    action() {
      // var article = Articles.findOne(this.urlParams.id);
      const references = References.find({}).fetch();

      if (references) {
        return {
          status: 'success',
          data: references
        };
      }

      return {
        statusCode: 400,
        body: {
          status: 'fail',
          message: "Error happened, I couldn't fetch the data"
        }
      };
    }

  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/sync/methods.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
let execFile;
module.link("child_process", {
  execFile(v) {
    execFile = v;
  }

}, 3);
let syncData;
module.link("./syncData", {
  syncData(v) {
    syncData = v;
  }

}, 4);
let config;
module.link("../../../config.json", {
  "*"(v) {
    config = v;
  }

}, 5);
// check internet connection
const {
  server
} = config;
const collections = ['course', 'unit', 'topic', 'resources', 'references', 'search', 'search'];
Meteor.methods({
  authenticate: (email, password) => {
    check(email, String);
    check(password, String);
    return HTTP.post(`${server}/api/login/`, {
      data: {
        email,
        password
      },
      content: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  },
  getAllCollections: (token, userId) => {
    check(token, String);
    check(userId, String);
    collections.map(coll => HTTP.get(`${server}/api/${coll}/`, {
      headers: {
        'X-Auth-Token': token,
        'X-User-Id': userId
      }
    }, (error, response) => {
      if (error) {
        console.log(error.reason); // eslint-disable-line
      }

      if (response && response.data) {
        const {
          data: {
            data
          }
        } = response;
        syncData.update({
          type: coll
        }, {
          $set: {
            data,
            count: data.length
          }
        }, {
          upsert: true
        }, (err, res) => {
          if (err) {
            console.log(err.reason); // eslint-disable-line
          }

          console.log(res); // eslint-disable-line
        });
      }
    }));
  },
  // restore the dumped files from the server
  restoreDbChunks: () => {
    execFile(`${process.env.PWD}/scripts/importdbs.sh`, [server], (error, stdout) => {
      if (error) {
        console.log(error); // eslint-disable-line
      }

      console.log(stdout); // eslint-disable-line
    }); // return response;
    // return execFileSync(`${process.env.PWD}/scripts/importdbs.sh`, [server]);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"syncData.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/sync/syncData.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  syncData: () => syncData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const syncData = new Mongo.Collection('syncData', {
  idGeneration: 'STRING'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"syncFile.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/sync/syncFile.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let EJSON;
module.link("meteor/ejson", {
  EJSON(v) {
    EJSON = v;
  }

}, 2);

let _Units;

module.link("../units/units", {
  _Units(v) {
    _Units = v;
  }

}, 3);

let _Topics, _Resources;

module.link("../topics/topics", {
  _Topics(v) {
    _Topics = v;
  },

  _Resources(v) {
    _Resources = v;
  }

}, 4);

let _Statistics;

module.link("../statistics/statistics", {
  _Statistics(v) {
    _Statistics = v;
  }

}, 5);

let _Deleted;

module.link("../Deleted/deleted", {
  _Deleted(v) {
    _Deleted = v;
  }

}, 6);

let _Settings;

module.link("../settings/settings", {
  _Settings(v) {
    _Settings = v;
  }

}, 7);
// _Units,_Topics,_Resources,_SearchData, _Statistics ,_Deleted,_Egranary,_Settings
// eslint-disable-next-line
Meteor.startup(function () {
  fs = Npm.require('fs'); //file system(fs)

  http = require('http');
  util = require('util');
  request = require('request');
  Fiber = require('fibers');
  exec = require('child_process').exec; // sys = require('sys');
  // sudoCommand = require('sudo-prompt');

  var bodyParser = Npm.require('body-parser');

  Picker.middleware(bodyParser.urlencoded({
    extended: false
  }));
  Picker.middleware(bodyParser.json());
  var postRoutes = Picker.filter(function (req, res) {
    // you can write any logic you want.
    // but this callback does not run inside a fiber
    // at the end, you must return either true or false
    return req.method == 'POST';
  });
});
var resourceSize = 0;
var resourceIndex = 0;
var resources = [];
var failedResources = [];
var downloadedResources = [];
var resourceName = '';
var chunkSize = 0;
var chunkSizeDiff = 0;
var isSyncRuning = false;
var skippedResource = false;
var resourcePath = null;
var school = null;
const files = {
  unit: 'syncUnit.js',
  topic: 'syncTopic.js',
  resource: 'syncResource.js'
}; // removed egranary collection temporary

const mCollections = {
  unit: _Units,
  topic: _Topics,
  resource: _Resources,
  delete: _Deleted
};
var hostUrl = null; //'http://192.168.8.150:3000/';

var downloadPath = null; //'http://192.168.8.150:3000/';
// const hostUrl = 'http://52.42.16.134/';
//const hostUrl = 'localhost:3000/';

const syncPath = process.env.PWD + '/public/syncFile/';
const uploadPath = process.env.PWD + '/public/uploads/';
const updatePath = process.env.PWD + '/public/updates/';
const publicPath = process.env.PWD + '/public/'; //const school = null;//config
//Cloud
//const uploadPath = 'www/manoap/bundle/programs/web.browser/app/private/';
//write to section

Meteor.methods({
  deleteFile: function (file) {
    check(file, String);
    var path = uploadPath + file;
    var fileStatus = Meteor.call('resourceExists', path);

    if (fileStatus) {
      fs.unlinkSync(path);
    }
  }
}); //get sync Address

Meteor.methods({
  getServerUrl: function () {
    var setting = _Settings.findOne({
      label: 'syncAddress'
    });

    return hostUrl = setting.val;
  }
}); //get one  setting value

Meteor.methods({
  getSetting: function (label) {
    var setting = _Settings.findOne({
      label: label
    });

    return hostUrl = setting.val;
  }
}); //get all settings

Meteor.methods({
  getSettings: function () {
    var settings = _Settings.findOne({});

    return hostUrl = settings;
  }
}); //get schoolName

Meteor.methods({
  getSchoolName: function () {
    let setting = _Settings.findOne({
      label: 'schoolName'
    });

    console.log(setting);
    return school = setting.val;
  }
}); //check for updates

Meteor.methods({
  getServerVersion: function () {
    var setting = _Settings.findOne({
      label: 'version'
    });

    return hostUrl = setting.val;
  }
}); //send Statistics

Meteor.methods({
  sendStatistics: function (statistics) {
    console.log('URL =' + hostUrl);
    var url = hostUrl + 'stats'; //"http://localhost:3000/stats";
    //var data = EJSON.stringify(statistics);

    HTTP.call('POST', url, {
      params: {
        statistics: statistics,
        isSchool: school
      }
    }, function (error, result) {
      console.log(url, result);

      if (!error) {
        return true;
      } else {
        return false;
      }
    });
  }
}); //send user accounts-base
//send Statistics

Meteor.methods({
  sendUsers: function () {
    var url = hostUrl + 'users'; //"http://localhost:3000/stats";
    //console.log(users);

    var usersData = Meteor.users.find({
      'emails.address': {
        $ne: 'admin@admin.com'
      }
    });
    var users = [];
    usersData.forEach(function (v) {
      users.push(v);
    });
    var size = users.length;
    users = JSON.stringify(users);
    HTTP.call('POST', url, {
      params: {
        users: users,
        isSchool: school
      }
    }, function (error, result) {
      if (!error) {
        return true;
        console.log(url, result);
      } else {
        return false;
      }
    });
    return size;
  }
}); //save Statistics

Meteor.methods({
  insertUsage: function (data) {
    check(data, Object);
    var id = data.id;
    var material = data.material;
    var url = data.url;
    var page = data.page;
    var user = this.userId ? data.user : 'anonymous';
    var date = data.date;

    var _id = id + user;

    if (!data.statsg) {
      //check if user has statistics.
      Meteor.users.update({
        _id: user
      }, {
        $set: {
          'profile.stats': 1
        }
      }, (error, success) => {
        console.log(success); //ToDO
      });
    }

    if (data.freq == undefined) {
      freq = 1;
    } else {
      freq = data.freq;
    }

    if (data.isSchool == undefined) {
      isSchool = school;
    }

    _Statistics.update({
      _id: _id
    }, {
      $set: {
        isSchool: 'isSchool',
        material,
        url,
        page,
        date,
        user,
        id
      },
      $inc: {
        freq
      }
    }, {
      upsert: true
    });
  }
}); //save user accounts sent from remote school

Meteor.methods({
  insertUser: function (data, isSchool) {
    var id = data._id;
    var emails = data.emails;
    var profile = data.profile;
    profile['isSchool'] = isSchool;
    profile.createdAt = new Date();
    Meteor.users.update({
      _id: id
    }, {
      $set: {
        emails: emails,
        profile: profile
      }
    }, {
      upsert: true
    });
  }
}); //getJSONFileContent

Meteor.methods({
  getSyncContent: function (fileType, isSchool, reset) {
    var val = false;
    var status = true;
    var results = null;

    if (mCollections[fileType] == undefined) {
      return null;
    } else if (reset) {
      val = true;
      status = false;
    }

    var data = [];
    var query = {};
    query['sync.' + isSchool] = val;

    if (fileType == 'egranary') {
      results = mCollections[fileType].find({});
    } else if (fileType == 'admin') {
      results = mCollections[fileType].find({});
    } else {
      results = mCollections[fileType].find({
        query
      });
    }

    results.forEach(function (v) {
      let id = v._id;
      let sync = v.sync;

      if (sync == undefined) {
        sync = {};
      }

      sync[isSchool] = status;
      /*update db
      mCollections[fileType].update({_id:id},{$set:{sync:{kijabe:false,kisumu:false}}});
      **/
      //update the db. tell the sys that which school has synced

      mCollections[fileType].update({
        _id: id
      }, {
        $set: {
          sync
        }
      });
      data.push(v);
    }); //console.log("DATA",data);

    try {
      //console.log(JSON.parse(data));
      return data;
    } catch (e) {
      return null;
    }
  }
}); // getResource ensures resource is available on server

Meteor.methods({
  getResource: function (resourcesData) {
    Meteor.call('resetResource');
    console.log('INDEX = ' + resourceIndex, 'RESOURCES =>' + resources.length);

    if (Array.isArray(resourcesData) && resourcesData.length > 0) {
      resourceIndex = 0;
      resources = resourcesData;
      console.log('new  resources loaded ==>' + resources.length);
    } else if (resources.length == 0) {
      //no resources found resources.length < 1 && Array.isArray(resourcesData)
      console.log('no resources found ');
      isSyncRuning = false;
      return; //remove in production "|| resourceIndex > 1"
    } else if (resourceIndex >= resources.length) {
      //All resources downloaded               //remove in production
      console.log('All resources downloaded => ' + resources.length);
      isSyncRuning = false;
      return;
    }

    if (!isSyncRuning) {
      return;
    }

    console.log('INDEX: ' + resourceIndex + ' TOTAL: ' + resources.length);
    var resource = resources[resourceIndex]; //assign each resouce meta-data(object) to resource variable

    resourceName = resource.name;
    resourceSize = resource.size;
    resourcePath = uploadPath + resourceName;
    downloadPath = hostUrl + 'uploads/' + resourceName;
    var fileStatus = true; //if set to false. file won't be downloaded
    //checking if file already exist on server

    fs.stat(resourcePath, function (err, stats) {
      //check if file already exists and is of the same size
      if (stats && stats.size == resourceSize) {
        //file already exist and is ok skip file
        console.log(resourceName + ' =>' + stats.size + ' <=> ' + resourceSize);
        skippedResource = true;
        console.log('skipped resource ' + resourcePath);
        resourceIndex++;
        fileStatus = false;
        isSyncRuning = false;
        skippedResource = true;
      } else if (stats && stats.size !== resourceSize && !err) {
        console.log('BROKEN FILE ' + resourceName + ' =>' + stats.size + ' <=> ' + resourceSize); // file already exist and is broken or needs to be replaced

        fs.unlinkSync(path); //delete file #############################
        // download missing file

        fileStatus = true;
      } else if (err && err.errno === 34) {
        //  console.log("FILE MISSING,STATS",stats,"ERROR",err);
        //file does not exit (err && err.errno === 34)
        //download missing file
        fileStatus = true;
      }

      if (isSyncRuning) {
        Fiber(function () {
          //download next file
          Meteor.call('downloadResource');
        }).run();
      } else {
        return;
      }
    });
  }
}); //get Resource progeress

Meteor.methods({
  getResourceProgress: function (resourcesData) {
    if (!isSyncRuning) {} //return false;
    // let resources =resources.length;
    //console.log(resources.length);


    return {
      resourceName: resourceName,
      resourceSize: resourceSize,
      chunkSizeDiff: chunkSizeDiff,
      resourceIndex: resourceIndex,
      chunkSize: chunkSize,
      resources: resources.length,
      resourceIndex: resourceIndex
    };
  }
}); //resets meta data to defaults

Meteor.methods({
  resetResource: function () {
    skippedResource = false;
    resourceName = '';
    resourceSize = 0;
    chunkSize = 0;
    chunkSizeDiff = 0;
    isSyncRuning = true;
  }
}); //get Resource progeress

Meteor.methods({
  setResource: function (resource) {
    if (resource.path == 'update') {
      resourcePath = updatePath + resource.name;
    } else if (resource.path == 'upload') {
      resourcePath = uploadPath + resource.name;
    } else {
      isSyncRuning = false;
      return;
    }

    downloadPath = resource.downloadPath;
    skippedResource = false;
    resourceName = resource.name;
    resourceSize = resource.size;
    chunkSize = 0;
    chunkSizeDiff = 0;
    isSyncRuning = true;
  }
}); //get Resource progeress

Meteor.methods({
  downloadResource: function () {
    if (!isSyncRuning) {
      console.log('isSyncRuning is not Runing');
      return;
    }

    console.log('URL =>' + downloadPath);
    console.log(isSyncRuning, 'downloading...' + resourceName);
    var url = downloadPath; //create file to download

    var file = fs.createWriteStream(resourcePath); //var isNext =false;

    var req = http.request(url, function (response) {
      console.log('requedst sent' + resourceName);
      response.on('data', function (chunk) {
        //check progress.
        let size = chunk.length; //    console.log('chunk found for => '+resourceName+' SIZE =>'+resourceSize);
        //  console.log('chunk size => '+size);

        chunkSize += size; //   console.log('chunk progress => '+chunkSize);
        //start  downloading a new file if current file is almost done

        chunkSizeDiff = Math.floor(resourceSize - chunkSize);
        file.write(chunk);
      });
      response.on('error', function (err) {
        failedResources.push(resourceName);
        console.log('ERROR ON response: ' + err);
      });
      response.on('end', function () {
        downloadedResources.push(resourceName);
        resourceIndex++;
        isSyncRuning = false;
        console.log('DONE: ');
      });
    });
    req.on('error', e => {
      console.log('file not found => ' + resourceName + ' ' + e.message);
      failedResources.push(resourceName);
      resourceIndex++;
    });
    req.end('all resourced downloaded');
  }
}); //check if file exist on the system

Meteor.methods({
  resourceExists: function (path) {
    check(path, String);
    var status = false;

    try {
      var stats = fs.accessSync(path);
      status = true;
    } catch (e) {
      //console.log(e);
      status = false;
    } finally {
      return status;
    }
  }
}); //syncApp

WebApp.connectHandlers.use('/syncApp', function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200);
  var file = req.query.file;
  var isSchool = req.query.isSchool;
  var reset = req.query.reset;

  if (file == undefined || isSchool == undefined) {
    res.end('request undefined');
  } else if (reset == undefined) {
    reset = false;
  }

  console.log('linked', file);
  var content = Meteor.call('getSyncContent', file, isSchool, reset);
  var data = [];
  var dataJSON = '';

  if (file == 'resource') {
    //check to make sure that the file actually exists
    var cleanData = [];
    content.forEach(function (v) {
      let path = uploadPath + v.file['name'];
      var status = Meteor.call('resourceExists', path); //  console.log(status);

      if (status) {
        cleanData.push(v);
      }
    });
    var data = JSON.stringify(cleanData);
    var dataJSON = EJSON.stringify(data);
  } else {
    var data = JSON.stringify(content);
    var dataJSON = EJSON.stringify(data);
  }

  res.end(dataJSON);
}); //receive Statistics

Picker.route('/stats/', function (params, req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200);
  var statistics = req.body.statistics;
  var isSchool = req.body.isSchool; //console.log('mmmmmmmmmmmmm');

  if (statistics == undefined) {
    console.log('STATAS FAILED');
    res.end('request undefined');
    return;
  }

  var stats = EJSON.parse(statistics);

  _Statistics.remove({
    isSchool: isSchool
  }); //clear old statistics


  stats.forEach(function (v, k, arr) {
    Meteor.call('insertUsage', v, true, isSchool);
  });
  console.log('inserted statistics=> ' + stats.length);
  res.end('statistics saved to cloud');
}); //receive users accounts

Picker.route('/userss', function (params, req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200);
  var users = req.body.users;
  var isSchool = req.body.isSchool; //console.log('mmmmmmmmmmmmm');
  // var users = EJSON.parse(users);

  var users = JSON.stringify(users); //console.log(users);

  if (users == undefined) {
    res.end('request undefined');
    return;
  }

  users.forEach(function (v, k, arr) {
    Meteor.call('insertUser', v, isSchool);
  });
  console.log('users inserted=> ' + users.length);
  res.end('accounts saved to cloud');
});
Meteor.methods({
  readFile: function (file) {
    var path = uploadPath + file;
    fs.open(path, 'r', (err, fd) => {
      // console.log(path);
      if (err) {
        if (err.code === 'ENOENT') {
          console.error('myfile does not exist');
          return;
        } else {
          throw err;
        }
      } // console.log('file',fd);
      // readMyData(fd);

    }); // fs.readFile(pdfFilePath, (err, pdfBuffer) => {
    //    if (!err) {
    //      pdfParser.parseBuffer(pdfBuffer);
    //    }
    //  })
  }
}); //syncApp

WebApp.connectHandlers.use('/version', function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200);
  var version = Meteor.call('getServerVersion');
  res.end(version);
}); //get filesize

Picker.route('/filesize/', function (params, req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200); // /fileSize?file={name}

  let resource = params.query.file;
  let path = params.query.path;
  var filePath = null; //specific path of file on the server

  console.log(resource);

  if (resource == undefined || path == undefined) {
    res.end('request undefined');
    return;
  } else if (path == 'update') {
    filePath = updatePath + resource;
  } else if (path == 'upload') {
    filePath = uploadPath + resource;
  } else {
    filePath = publicPath + resource;
  }

  fs.stat(filePath, function (err, stats) {
    if (stats) {
      res.end('' + stats.size);
      return;
    } else {
      res.end('' + -1);
      return;
    }
  });
});
Meteor.methods({
  runUpgrade: function (sudoPass, version) {
    //sh manoap.lite.sh
    const child = exec(' bash ~/manoap.lite.sh', {
      name: 'Upgrade'
    }, (error, stdout, stderr) => {
      if (error) {
        console.log('Error', error);
        throw error;
      } else if (stdout) {
        console.log('update sys. version');
        Fiber(function () {
          //
          var mVersion = parseFloat(version);
          var newVersion = (mVersion + 0.1).toFixed(1);
          var status = Meteor.call('updateSysVersion', newVersion);
          console.log('new version detected', newVersion, status);
        }).run();
      }
    });
  }
});
Meteor.methods({
  updateSysVersion: function (version) {
    currentVer = _Settings.findOne({
      label: 'version'
    });
    console.log('Cuurent version', currentVer, version);

    if (version > currentVer.val) {
      _Settings.update({
        label: 'version'
      }, {
        $set: {
          val: version
        }
      });

      return true;
    } else {
      ``;
      return false;
    }
  }
}); //reset settings

Meteor.methods({
  resetSystemSettings: function (version) {
    _Settings.remove({});
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"topics":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/topics/server/publications.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Topics;

module.link("../topics", {
  _Topics(v) {
    _Topics = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
Meteor.publish('topics', () => {
  if (!isAuthRequired()) {
    this.ready();
  }

  return _Topics.find({});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/topics/methods.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);

let _Topics;

module.link("../topics/topics", {
  _Topics(v) {
    _Topics = v;
  }

}, 2);
let Resources;
module.link("../resources/resources", {
  Resources(v) {
    Resources = v;
  }

}, 3);
Meteor.methods({
  // eslint-disable-next-line
  'topic.insert'(id, unitId, name, unit) {
    check(id, String);
    check(unitId, String);
    check(unit, String);
    check(name, String); // check, Object);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Topics.insert({
        _id: id,
        unitId,
        name,
        unit,
        resources: [],
        sync: {},
        createdAt: new Date(),
        createdBy: this.userId
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'topic.update'(id, topic) {
    check(id, String);
    check(topic, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Topics.update({
        _id: id
      }, {
        $set: {
          name: topic
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'topic.remove'(id) {
    check(id, String);
    const resources = Resources.find({
      'meta.topicId': id
    }).fetch();

    if (Roles.userIsInRole(this.userId, ['admin']) && !resources.length) {
      _Topics.remove(id);
    } else if (resources.length) {
      throw new Meteor.Error('sorry', 'The selected topic has resources that depend on it');
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  // eslint-disable-next-line
  'singletopic.insert': function (_id, unitId, name, unit) {
    check(_id, String);
    check(unitId, String);
    check(name, String);
    check(unit, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Topics.insert({
        _id,
        unitId,
        name,
        unit,
        resources: [],
        sync: {},
        createdAt: new Date(),
        createdBy: this.userId
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"topics.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/topics/topics.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Topics: () => _Topics
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Topics = new Mongo.Collection('topic');

_Topics.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const topicSchema = new SimpleSchema({
  unitId: String,
  name: String,
  unit: String,
  resources: Array,
  'resources.$': Object,
  sync: Object,
  createdAt: Date,
  createdBy: String
});

_Topics.attachSchema(topicSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"units":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/units/server/publications.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Units;

module.link("../units", {
  _Units(v) {
    _Units = v;
  }

}, 1);
let isAuthRequired;
module.link("../../config/config", {
  isAuthRequired(v) {
    isAuthRequired = v;
  }

}, 2);
// don't use arrow functions here because of the context
Meteor.publish('searchUnits', function getUnits(cId) {
  check(cId, Match.OneOf(String, null));

  if (!isAuthRequired()) {
    this.ready();
  }

  return _Units.find({
    'details.courseId': cId,
    createdBy: this.userId
  });
});
Meteor.publish('units', function getAllUnits() {
  if (!isAuthRequired()) {
    this.ready();
  }

  return _Units.find({}, {
    fiels: {
      name: 1,
      topics: 1,
      details: 1
    }
  });
}); // publish unit name

Meteor.publish('isHighSchool.units', function getSecUnit(id) {
  check(id, String);

  if (isAuthRequired()) {
    this.ready();
  }

  return _Units.find({
    _id: id
  }, {
    fields: {
      name: 1
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/units/methods.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);

let _Units;

module.link("./units", {
  _Units(v) {
    _Units = v;
  }

}, 2);

let _Topics;

module.link("../topics/topics", {
  _Topics(v) {
    _Topics = v;
  }

}, 3);
Meteor.methods({
  'unit.insert'(id, name, topics, unitDesc, details) {
    check(id, String);
    check(name, String);
    check(topics, Match.OneOf(Number, null, undefined));
    check(unitDesc, String);
    check(details, Object);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Units.insert({
        _id: id,
        name,
        topics,
        unitDesc,
        details,
        sync: {},
        createdAt: new Date(),
        createdBy: this.userId
      }); //  You can also trigger if something wrong happens

    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  'unit.update'(id, name, desc) {
    check(id, String);
    check(name, String);
    check(desc, String);

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager'])) {
      _Units.update({
        _id: id
      }, {
        $set: {
          name,
          unitDesc: desc
        }
      });
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  },

  'unit.remove'(id) {
    check(id, String);

    const topics = _Topics.find({
      unitId: id
    }).fetch();

    if (Roles.userIsInRole(this.userId, ['admin', 'content-manager']) && !topics.length) {
      _Units.remove(id);
    } else if (topics.length >= 1) {
      throw new Meteor.Error('sorry', 'The selected course unit has topics that depend on it');
    } else {
      throw new Meteor.Error('oops', 'You are not allowed to not make changes');
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"units.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/units/units.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  _Units: () => _Units
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);

const _Units = new Mongo.Collection('unit', {
  idGeneration: 'STRING'
});

_Units.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});

const Schema = {};
Schema.Details = new SimpleSchema({
  courseId: String,
  programId: {
    type: String,
    optional: true
  },
  language: String
});
Schema.unitSchema = new SimpleSchema({
  name: String,
  topics: {
    type: Number,
    optional: true
  },
  unitDesc: String,
  details: Schema.Details,
  createdAt: Date,
  createdBy: String,
  sync: Object // Sync will have to be defined when it gets property names

});

_Units.attachSchema(Schema.unitSchema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Log":{"logger.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/Log/logger.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 2);
Meteor.methods({
  logger: (text, type) => {
    check(text, String);
    check(type, String);
    const path = `${process.env.PWD}/${type}.log`;
    fs.appendFile(path, text, err => {
      if (err) throw err; // eslint-disable-next-line

      console.error('the log was successfully written');
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config":{"config.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/config/config.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Conf: () => Conf,
  isAuthRequired: () => isAuthRequired
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Config;
module.link("../../../config.json", {
  "*"(v) {
    Config = v;
  }

}, 2);
const Conf = new Mongo.Collection('config', {
  idGeneration: 'STRING'
});
const {
  isUserAuth
} = Config;

function isAuthRequired() {
  return isUserAuth ? !!Meteor.user() : true;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"languages":{"language.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/languages/language.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Language: () => Language
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Language = new Mongo.Collection('language');
const Schema = {};
Schema.language = new SimpleSchema({
  language: String
});
Language.attachSchema(Schema.language); // export const updateLanguage = new ValidatedMethod({
//   name: 'language.update',
//   validate: null,
//   run({ id, language }) {
//     return Language.update({ _id: '345345730' }, { $set: { language } }, { upsert: true });
//   },
// });
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/languages/methods.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let ValidatedMethod;
module.link("meteor/mdg:validated-method", {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let i18n;
module.link("meteor/universe:i18n", {
  default(v) {
    i18n = v;
  }

}, 1);
let Language;
module.link("./language", {
  Language(v) {
    Language = v;
  }

}, 2);
// universe:i18n only bundles the default language on the client side.
// To get a list of all avialble languages with at least one translation,
// i18n.getLanguages() must be called server side.
const getLanguages = new ValidatedMethod({
  name: 'languages.getAll',
  validate: null,

  run() {
    return i18n.getLanguages();
  }

}); // export const updateLanguage = new ValidatedMethod({
//   name: 'language.update',
//   validate: null,
//   run({ id, language }) {
//     return Language.update({ _id: '345345730' }, { $set: { language } }, { upsert: true });
//   },
// });

Meteor.methods({
  updateLanguage(language) {
    check(language, String);
    return Language.update({
      _id: '345345730'
    }, {
      $set: {
        language
      }
    }, {
      upsert: true
    });
  }

});
module.exportDefault(getLanguages);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"crons.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/crons.js                                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/* eslint no-undef: 0 */
SyncedCron.add({
  name: 'Delete Notifications that are older than 30days',
  schedule: parser => parser.text('every 24 hours'),
  job: () => {
    Meteor.call('dropNotifications');
  }
}); // start the cronjob

SyncedCron.start();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"server":{"init.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/init.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _Settings;

module.link("../../api/settings/settings", {
  _Settings(v) {
    _Settings = v;
  }

}, 1);

/*
  The file contains the initial database of the Institution and the users
*/
// eslint-disable-next-line func-names
Meteor.startup(() => {
  // initialize the main color
  if (!_Settings.find().count()) {
    _Settings.insert({
      main: '#006b76',
      mainDark: '#0c0c0c'
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/register-api.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.link("../../api/accounts/server/publications.js");
module.link("../../api/accounts/account");
module.link("../../api/accounts/methods");
module.link("../../api/courses/server/publications");
module.link("../../api/courses/methods");
module.link("../../api/units/server/publications");
module.link("../../api/units/methods");
module.link("../../api/topics/server/publications");
module.link("../../api/topics/methods");
module.link("../../api/resources/server/publications");
module.link("../../api/resources/methods");
module.link("../../api/settings/server/publications");
module.link("../../api/settings/methods");
module.link("./init");
module.link("../../api/bookmarks/methods");
module.link("../../api/bookmarks/server/publications");
module.link("../../api/notifications/server/publications");
module.link("../../api/notifications/methods");
module.link("../../api/notifications/notifications");
module.link("../../api/feedback/server/publications");
module.link("../../api/feedback/methods");
module.link("../../api/search/server/publications");
module.link("../../api/search/methods");
module.link("../../api/statistics/server/publications");
module.link("../../api/statistics/csvMethods");
module.link("../../api/sync/methods");
module.link("../../api/sync/syncFile");
module.link("../../api/Deleted/methods");
module.link("../../api/Deleted/server/publications");
module.link("../../api/externallink/methods");
module.link("../../api/externallink/server/publications");
module.link("../../api/sync/endpoint");
module.link("../../api/sync/server/sync");
module.link("../../api/crons");
module.link("../../api/languages/methods");
module.link("../../api/Log/logger");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"config.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/config.js                                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 1);
let config;
module.link("../config.json", {
  "*"(v) {
    config = v;
  }

}, 2);
const path = `${process.env.PWD}/config.json`;
Meteor.methods({
  addConfig: (name, tag, auth, isHighSchool, server) => {
    check(name, String);
    check(tag, String);
    check(auth, Boolean);
    check(server, String);
    check(isHighSchool, Match.OneOf(Boolean, null)); // check(set, Boolean);

    const isSet = config.isConfigured;
    let newConfig;

    if (isSet) {
      newConfig = {
        name,
        tag,
        isUserAuth: auth,
        isHighSchool: config.isHighSchool,
        isConfigured: true,
        server
      };
    } else {
      newConfig = {
        name,
        tag,
        isUserAuth: auth,
        isHighSchool,
        isConfigured: true,
        server
      };
    }

    let title;
    let subTitle;
    check(newConfig, Object);
    fs.writeFile(path, JSON.stringify(newConfig, null, 2), Meteor.bindEnvironment(err => {
      if (err) {
        throw new Meteor.Error('something wrong happened', "Couldn't write to the file");
      } // Create a config from here


      if (isHighSchool) {
        title = 'Subjects';
        subTitle = 'Units';
      } else {
        title = 'Courses';
        subTitle = 'Units';
      }

      Meteor.call('insert.title', title, subTitle, error => {
        error ? console.err(error.reason) : console.log('Saved titles');
      });
    }));
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/init.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 1);
Meteor.startup(() => {
  const currentPath = `${process.env.PWD}/public/sparked.png`;
  const newPath = `${process.env.PWD}/public/uploads/sparked.png`;

  try {
    if (fs.statSync(currentPath)) {
      fs.copy(currentPath, newPath).then(() => console.log('')).catch(err => console.error(err));
    } else {
      console.log('no such file exists!');
    }
  } catch (err) {
    console.error(err);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.link("../imports/startup/server/register-api");
module.link("./init");
module.link("./config.js");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.json":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// config.json                                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exports = {
  "name": "Ministry of Health",
  "tag": "External Relations Office",
  "isUserAuth": false,
  "isHighSchool": false,
  "isConfigured": true,
  "server": "http://172.16.0.5"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".i18n.json"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRGVsZXRlZC9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9EZWxldGVkL2RlbGV0ZWQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0RlbGV0ZWQvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvYWNjb3VudC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYm9va21hcmtzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jvb2ttYXJrcy9ib29rbWFya3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jvb2ttYXJrcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jb3Vyc2VzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NvdXJzZXMvY291cnNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY291cnNlcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9leHRlcm5hbGxpbmsvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZXh0ZXJuYWxsaW5rL2V4dGVybmFsbGluay5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZXh0ZXJuYWxsaW5rL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZlZWRiYWNrL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZlZWRiYWNrL2ZlZWRiYWNrLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9mZWVkYmFjay9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ub3RpZmljYXRpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL25vdGlmaWNhdGlvbnMvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yZXNvdXJjZXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVzb3VyY2VzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Jlc291cmNlcy9yZXNvdXJjZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3NlYXJjaC9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zZWFyY2gvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2VhcmNoL3NlYXJjaC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2V0dGluZ3Mvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2V0dGluZ3MvaW5zdGl0dXRpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3NldHRpbmdzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3NldHRpbmdzL3NldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zZXR0aW5ncy9zbGlkZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3NldHRpbmdzL3RpdGxlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3RhdGlzdGljcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0aXN0aWNzL2Nzdk1ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3N0YXRpc3RpY3Mvc3RhdGlzdGljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3luYy9zZXJ2ZXIvc3luYy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3luYy9lbmRwb2ludC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3luYy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zeW5jL3N5bmNEYXRhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zeW5jL3N5bmNGaWxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90b3BpY3Mvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdG9waWNzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RvcGljcy90b3BpY3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VuaXRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VuaXRzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VuaXRzL3VuaXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Mb2cvbG9nZ2VyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jb25maWcvY29uZmlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9sYW5ndWFnZXMvbGFuZ3VhZ2UuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2xhbmd1YWdlcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jcm9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbml0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3JlZ2lzdGVyLWFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2luaXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiX0RlbGV0ZWQiLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImNoZWNrIiwiTWF0Y2giLCJtZXRob2RzIiwiaW5zZXJ0RGVsZXRlZCIsImlkIiwiY29sIiwiZmlsZSIsIlN0cmluZyIsIk9uZU9mIiwidW5kZWZpbmVkIiwiT2JqZWN0IiwiaW5zZXJ0IiwiZGVsSWQiLCJzeW5jIiwiYWxsVXNlcnMiLCJ1c2VySWQiLCJSb2xlcyIsInVzZXJJc0luUm9sZSIsInJlYWR5IiwidXNlcnMiLCJyb2xlcyIsIlNpbXBsZVNjaGVtYSIsImRlZmF1bHQiLCJkZW55IiwidXBkYXRlIiwicmVtb3ZlIiwiVXNlclByb2ZpbGUiLCJuYW1lIiwiZ2VuZGVyIiwic3RhdHVzIiwiTnVtYmVyIiwic3RhdHMiLCJVc2VyIiwiZW1haWxzIiwiQXJyYXkiLCJ0eXBlIiwicmVnRXgiLCJSZWdFeCIsIkVtYWlsIiwiQm9vbGVhbiIsInByb2ZpbGUiLCJjcmVhdGVkQXQiLCJEYXRlIiwic2VydmljZXMiLCJvcHRpb25hbCIsImJsYWNrYm94IiwiYXR0YWNoU2NoZW1hIiwiQWNjb3VudHMiLCJ1c2VyIiwiZW1haWwiLCJwYXNzd29yZCIsImNyZWF0ZVVzZXIiLCJpbml0aWFsVXNlciIsImZpbmRPbmUiLCJfaWQiLCJmaW5kVXNlckJ5RW1haWwiLCJjb3VudCIsImFkZFVzZXJzVG9Sb2xlcyIsIiRzZXQiLCJFcnJvciIsInByb21vdGVVc2VyIiwicm9sZSIsInNldFVzZXJSb2xlcyIsInJlbW92ZVVzZXIiLCJuYW1lZiIsImFjY291bnRFeGlzdCIsImNoYW5nZVVzZXJQYXNzd29yZCIsImlzQWRtaW4iLCJzZXRQYXNzd29yZCIsIl9Cb29rbWFyayIsImlzQXV0aFJlcXVpcmVkIiwiZ2V0Qm9va21hcmtzIiwiaWRHZW5lcmF0aW9uIiwiYm9va01hcmtTY2hlbWEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwidXJsIiwiY29sb3IiLCJwYXRoIiwidXBkYXRlQm9va21hcmsiLCJib29rbWFyayIsInVwc2VydCIsInJlbW92ZUJvb2ttYXJrIiwiX0NvdXJzZXMiLCJhbGxDb3Vyc2VzIiwicHJvZ3JhbUNvdXJzZXMiLCJTY2hlbWEiLCJkZXRhaWxzIiwic2Nob29sSWQiLCJwcm9ncmFtSWQiLCJsYW5ndWFnZSIsIkNvdXJzZSIsImNvZGUiLCJjcmVhdGVkQnkiLCJfVW5pdHMiLCJjb3Vyc2VBZGQiLCJjb3Vyc2UiLCJjb3Vyc2VDb2RlIiwib3duZXJJZCIsInVuaXRzIiwiZmV0Y2giLCJsZW5ndGgiLCJfRXh0ZXJuYWxMaW5rIiwiZ2V0RXh0ZXJuYWxMaW5rcyIsImV4dGVybmFsTGlua1NjaGVtYSIsImFkZEV4dGVybmFsTGluayIsImV4dGVybmFsbGluayIsIl9GZWVkYmFjayIsImZlZWRTY2hlbWEiLCJmZWVkYmFjayIsIl9Ob3RpZmljYXRpb25zIiwicHVibGlzaE5vdGUiLCJpbnNlcnROb3RpZmljYXRpb24iLCJjYXRlZ29yeSIsInVuaXRJZCIsInRvcGljSWQiLCJmaWxlSWQiLCJ0ZXN0VXNlcnMiLCJtYXAiLCJ1c3IiLCJPYmplY3RJRCIsInZhbHVlT2YiLCJyZWFkIiwibWFya1JlYWQiLCJib29sIiwiZHJvcFVzZXJOb3RpZmljYXRpb25zIiwiZHJvcEFsbFVzZXJOb3RpZmljYXRpb25zIiwiZHJvcE5vdGlmaWNhdGlvbnMiLCJkYXRlIiwiZGF5c1RvRGVsZXRpb24iLCJkZWxldGlvbkRhdGUiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsIiRsdGUiLCJub3RlZlNjaGVtYSIsIlJlc291cmNlcyIsIlJlZmVyZW5jZXMiLCJhbGxSZXNvdXJjZSIsImN1cnNvciIsInVwZGF0ZVJlc291cmNlIiwicmVzb3VyY2UiLCJ1cGRhdGVSZWZlcmVuY2UiLCJyZWZlcmVuY2UiLCJyZW1vdmVSZXNvdXJjZSIsInJlbW92ZVJlZmVyZW5jZSIsIl9FZ3JhbmFyeSIsIk1vbmdvSW50ZXJuYWxzIiwiRmlsZXNDb2xsZWN0aW9uIiwiR3JpZCIsImZzIiwiZ2ZzIiwiaXNTZXJ2ZXIiLCJkZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlciIsIm1vbmdvIiwiZGIiLCJOcG1Nb2R1bGUiLCJ2YWxpZFR5cGVzIiwiY29sbGVjdGlvbk5hbWUiLCJhbGxvd0NsaWVudENvZGUiLCJvbkJlZm9yZVVwbG9hZCIsInNpemUiLCJpbmNsdWRlcyIsImV4dCIsImpvaW4iLCJvbkFmdGVyVXBsb2FkIiwia2V5cyIsInZlcnNpb25zIiwiZm9yRWFjaCIsInZlcnNpb25OYW1lIiwibWV0YWRhdGEiLCJzdG9yZWRBdCIsIndyaXRlU3RyZWFtIiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJmaWxlbmFtZSIsImNyZWF0ZVJlYWRTdHJlYW0iLCJwaXBlIiwib24iLCJiaW5kRW52aXJvbm1lbnQiLCJ1cGxvYWRlZEZpbGUiLCJwcm9wZXJ0eSIsImNvbGxlY3Rpb24iLCJ0b1N0cmluZyIsInVubGluayIsImludGVyY2VwdERvd25sb2FkIiwiaHR0cCIsIm1ldGEiLCJncmlkRnNGaWxlSWQiLCJyZWFkU3RyZWFtIiwiZXJyIiwicmVzcG9uc2UiLCJvbkFmdGVyUmVtb3ZlIiwiaW1hZ2VzIiwiaW1hZ2UiLCJhbGxvd0NsaWVudCIsImZpbGVzIiwiX1NlYXJjaERhdGEiLCJyZW1vdmVTZWFyY2hEYXRhIiwidXBkYXRlU2VhcmNoIiwiX2lkcyIsImlkcyIsInJlc291cmNlSWQiLCJjb3Vyc2VJZCIsInNlYXJjaFNjaGVtYSIsIkluc3RpdHV0aW9uIiwiU2xpZGVzIiwiX1NldHRpbmdzIiwiVGl0bGVzIiwic3RvcmFnZVBhdGgiLCJwcm9jZXNzIiwiZW52IiwiUFdEIiwidGVzdCIsImV4dGVuc2lvbiIsIk1hZ2ljIiwiTUFHSUNfTUlNRV9UWVBFIiwicmVxdWlyZSIsIm1hZ2ljIiwiZGV0ZWN0RmlsZSIsIm1pbWVUeXBlIiwiaW5kZXhPZiIsIl9TbGlkZXMiLCJhZGRTbGlkaW5nIiwic2t1IiwiQ3JlYXRlZEJ5IiwiZWRpdFNsaWRlcyIsInNsaWRlSWQiLCJzbGlkZU5hbWUiLCJyZW1vdmVTbGlkZXMiLCJ1cGRhdGVMb2dvIiwiaW5zdElkIiwidGFnbGluZSIsImxvZ28iLCJzdWJfdGl0bGUiLCJ0b2RheSIsImVkaXRlZEF0Iiwic3ViIiwidXBkYXRlQ29sb3JzIiwibWFpbiIsImJ1dHRvbiIsInNpZGViYXIiLCJ1cGRhdGVTZXR0aW5ncyIsInRhZyIsInNlcnZlciIsImlzQ29uZmlndXJlZCIsInNldERhcmtNb2RlIiwiaXNTZXQiLCJpc0RhcmsiLCJ0aXRsZVNjaGVtYSIsIl9TdGF0aXN0aWNzIiwic3RhdGlzdGljcyIsIkRhdGFUb0NTViIsImhlYWRpbmciLCJkZWxpbWl0ZXIiLCJleHBvcnRjc3YiLCJleHBvcnRUb0NTViIsImdldENTVkRhdGEiLCJxdWVyeSIsIm1Vc2VyIiwiZGF0YSIsImFkZHJlc3MiLCJzeW5jRGF0YSIsIlJlc3RpdnVzIiwiX1RvcGljcyIsIkFwaSIsInVzZURlZmF1bHRBdXRoIiwicHJldHR5SnNvbiIsImFkZENvbGxlY3Rpb24iLCJleGNsdWRlZEVuZHBvaW50cyIsInJvdXRlT3B0aW9ucyIsImF1dGhSZXF1aXJlZCIsImVuZHBvaW50cyIsImdldCIsImFkZFJvdXRlIiwiYWN0aW9uIiwicmVzb3VyY2VzIiwic3RhdHVzQ29kZSIsImJvZHkiLCJtZXNzYWdlIiwicmVmZXJlbmNlcyIsIkhUVFAiLCJleGVjRmlsZSIsImNvbmZpZyIsImNvbGxlY3Rpb25zIiwiYXV0aGVudGljYXRlIiwicG9zdCIsImNvbnRlbnQiLCJnZXRBbGxDb2xsZWN0aW9ucyIsInRva2VuIiwiY29sbCIsImhlYWRlcnMiLCJlcnJvciIsImNvbnNvbGUiLCJsb2ciLCJyZWFzb24iLCJyZXMiLCJyZXN0b3JlRGJDaHVua3MiLCJzdGRvdXQiLCJFSlNPTiIsIl9SZXNvdXJjZXMiLCJzdGFydHVwIiwiTnBtIiwidXRpbCIsInJlcXVlc3QiLCJGaWJlciIsImV4ZWMiLCJib2R5UGFyc2VyIiwiUGlja2VyIiwibWlkZGxld2FyZSIsInVybGVuY29kZWQiLCJleHRlbmRlZCIsImpzb24iLCJwb3N0Um91dGVzIiwiZmlsdGVyIiwicmVxIiwibWV0aG9kIiwicmVzb3VyY2VTaXplIiwicmVzb3VyY2VJbmRleCIsImZhaWxlZFJlc291cmNlcyIsImRvd25sb2FkZWRSZXNvdXJjZXMiLCJyZXNvdXJjZU5hbWUiLCJjaHVua1NpemUiLCJjaHVua1NpemVEaWZmIiwiaXNTeW5jUnVuaW5nIiwic2tpcHBlZFJlc291cmNlIiwicmVzb3VyY2VQYXRoIiwic2Nob29sIiwidW5pdCIsInRvcGljIiwibUNvbGxlY3Rpb25zIiwiZGVsZXRlIiwiaG9zdFVybCIsImRvd25sb2FkUGF0aCIsInN5bmNQYXRoIiwidXBsb2FkUGF0aCIsInVwZGF0ZVBhdGgiLCJwdWJsaWNQYXRoIiwiZGVsZXRlRmlsZSIsImZpbGVTdGF0dXMiLCJjYWxsIiwidW5saW5rU3luYyIsImdldFNlcnZlclVybCIsInNldHRpbmciLCJsYWJlbCIsInZhbCIsImdldFNldHRpbmciLCJnZXRTZXR0aW5ncyIsInNldHRpbmdzIiwiZ2V0U2Nob29sTmFtZSIsImdldFNlcnZlclZlcnNpb24iLCJzZW5kU3RhdGlzdGljcyIsInBhcmFtcyIsImlzU2Nob29sIiwicmVzdWx0Iiwic2VuZFVzZXJzIiwidXNlcnNEYXRhIiwiJG5lIiwicHVzaCIsIkpTT04iLCJzdHJpbmdpZnkiLCJpbnNlcnRVc2FnZSIsIm1hdGVyaWFsIiwicGFnZSIsInN0YXRzZyIsInN1Y2Nlc3MiLCJmcmVxIiwiJGluYyIsImluc2VydFVzZXIiLCJnZXRTeW5jQ29udGVudCIsImZpbGVUeXBlIiwicmVzZXQiLCJyZXN1bHRzIiwiZSIsImdldFJlc291cmNlIiwicmVzb3VyY2VzRGF0YSIsImlzQXJyYXkiLCJzdGF0IiwiZXJybm8iLCJydW4iLCJnZXRSZXNvdXJjZVByb2dyZXNzIiwicmVzZXRSZXNvdXJjZSIsInNldFJlc291cmNlIiwiZG93bmxvYWRSZXNvdXJjZSIsImNodW5rIiwiTWF0aCIsImZsb29yIiwid3JpdGUiLCJlbmQiLCJyZXNvdXJjZUV4aXN0cyIsImFjY2Vzc1N5bmMiLCJXZWJBcHAiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJuZXh0Iiwic2V0SGVhZGVyIiwid3JpdGVIZWFkIiwiZGF0YUpTT04iLCJjbGVhbkRhdGEiLCJyb3V0ZSIsInBhcnNlIiwiayIsImFyciIsInJlYWRGaWxlIiwib3BlbiIsImZkIiwidmVyc2lvbiIsImZpbGVQYXRoIiwicnVuVXBncmFkZSIsInN1ZG9QYXNzIiwiY2hpbGQiLCJzdGRlcnIiLCJtVmVyc2lvbiIsInBhcnNlRmxvYXQiLCJuZXdWZXJzaW9uIiwidG9GaXhlZCIsInVwZGF0ZVN5c1ZlcnNpb24iLCJjdXJyZW50VmVyIiwicmVzZXRTeXN0ZW1TZXR0aW5ncyIsInRvcGljU2NoZW1hIiwiZ2V0VW5pdHMiLCJjSWQiLCJnZXRBbGxVbml0cyIsImZpZWxzIiwidG9waWNzIiwiZ2V0U2VjVW5pdCIsImZpZWxkcyIsInVuaXREZXNjIiwiZGVzYyIsIkRldGFpbHMiLCJ1bml0U2NoZW1hIiwibG9nZ2VyIiwidGV4dCIsImFwcGVuZEZpbGUiLCJDb25mIiwiQ29uZmlnIiwiaXNVc2VyQXV0aCIsIkxhbmd1YWdlIiwiVmFsaWRhdGVkTWV0aG9kIiwiaTE4biIsImdldExhbmd1YWdlcyIsInZhbGlkYXRlIiwidXBkYXRlTGFuZ3VhZ2UiLCJleHBvcnREZWZhdWx0IiwiU3luY2VkQ3JvbiIsImFkZCIsInNjaGVkdWxlIiwicGFyc2VyIiwiam9iIiwic3RhcnQiLCJtYWluRGFyayIsImFkZENvbmZpZyIsImF1dGgiLCJpc0hpZ2hTY2hvb2wiLCJuZXdDb25maWciLCJzdWJUaXRsZSIsIndyaXRlRmlsZSIsImN1cnJlbnRQYXRoIiwibmV3UGF0aCIsInN0YXRTeW5jIiwiY29weSIsInRoZW4iLCJjYXRjaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJQyxRQUFKOztBQUFhSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNFLFVBQVEsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQVEsR0FBQ0QsQ0FBVDtBQUFXOztBQUF4QixDQUF6QixFQUFtRCxDQUFuRDtBQUc3RUgsTUFBTSxDQUFDSyxPQUFQLENBQWUsSUFBZixFQUFxQixNQUFNRCxRQUFRLENBQUNFLElBQVQsQ0FBYyxFQUFkLENBQTNCLEU7Ozs7Ozs7Ozs7O0FDSEFMLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNILFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSUksS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQzs7QUFFMUMsTUFBTUMsUUFBUSxHQUFHLElBQUlJLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixTQUFyQixDQUFqQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUlULE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSU8sS0FBSixFQUFVQyxLQUFWO0FBQWdCVixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQlEsT0FBSyxDQUFDUixDQUFELEVBQUc7QUFBQ1EsU0FBSyxHQUFDUixDQUFOO0FBQVE7O0FBQXBDLENBQTNCLEVBQWlFLENBQWpFOztBQUFvRSxJQUFJQyxRQUFKOztBQUFhSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNFLFVBQVEsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQVEsR0FBQ0QsQ0FBVDtBQUFXOztBQUF4QixDQUF4QixFQUFrRCxDQUFsRDtBQUlqS0gsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjtBQUNBQyxlQUFhLEVBQUUsQ0FBQ0MsRUFBRCxFQUFLQyxHQUFMLEVBQVVDLElBQUksR0FBRyxJQUFqQixLQUEwQjtBQUN2Q04sU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUNLLEdBQUQsRUFBTUosS0FBSyxDQUFDTyxLQUFOLENBQVlELE1BQVosRUFBb0IsSUFBcEIsRUFBMEJFLFNBQTFCLENBQU4sQ0FBTDtBQUNBVCxTQUFLLENBQUNNLElBQUQsRUFBT0wsS0FBSyxDQUFDTyxLQUFOLENBQVlFLE1BQVosRUFBb0IsSUFBcEIsRUFBMEJELFNBQTFCLENBQVAsQ0FBTDs7QUFFQWYsWUFBUSxDQUFDaUIsTUFBVCxDQUFnQjtBQUNkQyxXQUFLLEVBQUVSLEVBRE87QUFFZEUsVUFGYztBQUdkRCxTQUhjO0FBSWRRLFVBQUksRUFBRSxFQUpRLENBSUo7O0FBSkksS0FBaEI7QUFNRDtBQWJZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJdkIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUVYSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFNBQVNtQixRQUFULEdBQW9CO0FBQzlDLE1BQUksQ0FBQyxLQUFLQyxNQUFOLElBQWdCLENBQUNDLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBckIsRUFBaUU7QUFDL0QsV0FBTyxLQUFLRyxLQUFMLEVBQVA7QUFDRDs7QUFDRCxTQUFPNUIsTUFBTSxDQUFDNkIsS0FBUCxDQUFhdkIsSUFBYixDQUFrQixFQUFsQixDQUFQO0FBQ0QsQ0FMRDtBQU9BTixNQUFNLENBQUNLLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLE1BQU1MLE1BQU0sQ0FBQzhCLEtBQVAsQ0FBYXhCLElBQWIsQ0FBa0IsRUFBbEIsQ0FBM0IsRTs7Ozs7Ozs7Ozs7QUNUQSxJQUFJTixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk0QixZQUFKO0FBQWlCOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0QixnQkFBWSxHQUFDNUIsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUdqRkgsTUFBTSxDQUFDNkIsS0FBUCxDQUFhSSxJQUFiLENBQWtCO0FBQ2hCWixRQUFNLEVBQUUsTUFBTSxJQURFO0FBRWhCYSxRQUFNLEVBQUUsTUFBTSxJQUZFO0FBR2hCQyxRQUFNLEVBQUUsTUFBTTtBQUhFLENBQWxCO0FBTUEsTUFBTUMsV0FBVyxHQUFHLElBQUlMLFlBQUosQ0FBaUI7QUFDbkNNLE1BQUksRUFBRXBCLE1BRDZCO0FBRW5DcUIsUUFBTSxFQUFFckIsTUFGMkI7QUFHbkNzQixRQUFNLEVBQUVDLE1BSDJCO0FBSW5DQyxPQUFLLEVBQUVEO0FBSjRCLENBQWpCLENBQXBCO0FBT0EsTUFBTUUsSUFBSSxHQUFHLElBQUlYLFlBQUosQ0FBaUI7QUFDNUJZLFFBQU0sRUFBRUMsS0FEb0I7QUFFNUIsY0FBWXhCLE1BRmdCO0FBRzVCLHNCQUFvQjtBQUNsQnlCLFFBQUksRUFBRTVCLE1BRFk7QUFFbEI2QixTQUFLLEVBQUVmLFlBQVksQ0FBQ2dCLEtBQWIsQ0FBbUJDO0FBRlIsR0FIUTtBQU81Qix1QkFBcUJDLE9BUE87QUFRNUJDLFNBQU8sRUFBRWQsV0FSbUI7QUFTNUJlLFdBQVMsRUFBRUMsSUFUaUI7QUFVNUJDLFVBQVEsRUFBRTtBQUNSUixRQUFJLEVBQUV6QixNQURFO0FBRVJrQyxZQUFRLEVBQUUsSUFGRjtBQUdSQyxZQUFRLEVBQUU7QUFIRixHQVZrQjtBQWU1QnpCLE9BQUssRUFBRTtBQUNMZSxRQUFJLEVBQUVELEtBREQ7QUFFTFUsWUFBUSxFQUFFLElBRkw7QUFHTEMsWUFBUSxFQUFFO0FBSEwsR0FmcUI7QUFvQjVCLGFBQVd0QztBQXBCaUIsQ0FBakIsQ0FBYjtBQXVCQWpCLE1BQU0sQ0FBQzZCLEtBQVAsQ0FBYTJCLFlBQWIsQ0FBMEJkLElBQTFCLEU7Ozs7Ozs7Ozs7O0FDdkNBLElBQUkxQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlzRCxRQUFKO0FBQWF4RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDdUQsVUFBUSxDQUFDdEQsQ0FBRCxFQUFHO0FBQUNzRCxZQUFRLEdBQUN0RCxDQUFUO0FBQVc7O0FBQXhCLENBQW5DLEVBQTZELENBQTdEO0FBQWdFLElBQUlPLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXVCLEtBQUo7QUFBVXpCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUN3QixPQUFLLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLFNBQUssR0FBQ3ZCLENBQU47QUFBUTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFLbk5ILE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2IsaUJBQWU4QyxJQUFJLElBQUk7QUFDckJoRCxTQUFLLENBQUNnRCxJQUFELEVBQU87QUFDVkMsV0FBSyxFQUFFMUMsTUFERztBQUVWMkMsY0FBUSxFQUFFM0MsTUFGQTtBQUdWaUMsYUFBTyxFQUFFOUI7QUFIQyxLQUFQLENBQUw7QUFLQXFDLFlBQVEsQ0FBQ0ksVUFBVCxDQUFvQkgsSUFBcEI7QUFDRCxHQVJZO0FBU2IsbUJBQWlCQyxLQUFLLElBQUk7QUFDeEJqRCxTQUFLLENBQUNpRCxLQUFELEVBQVExQyxNQUFSLENBQUw7QUFDQSxVQUFNNkMsV0FBVyxHQUFHOUQsTUFBTSxDQUFDNkIsS0FBUCxDQUFha0MsT0FBYixFQUFwQjtBQUNBLFVBQU10QyxNQUFNLEdBQUdxQyxXQUFXLENBQUNFLEdBQTNCO0FBQ0EsVUFBTU4sSUFBSSxHQUFHRCxRQUFRLENBQUNRLGVBQVQsQ0FBeUJOLEtBQXpCLENBQWI7O0FBQ0EsUUFBSTNELE1BQU0sQ0FBQzZCLEtBQVAsQ0FBYXZCLElBQWIsR0FBb0I0RCxLQUFwQixPQUFnQyxDQUFwQyxFQUF1QztBQUNyQ3hDLFdBQUssQ0FBQ3lDLGVBQU4sQ0FBc0IxQyxNQUF0QixFQUE4QixPQUE5QjtBQUNBekIsWUFBTSxDQUFDNkIsS0FBUCxDQUFhSyxNQUFiLENBQW9CO0FBQUU4QixXQUFHLEVBQUV2QztBQUFQLE9BQXBCLEVBQXFDO0FBQUUyQyxZQUFJLEVBQUU7QUFBRSw0QkFBa0I7QUFBcEI7QUFBUixPQUFyQztBQUNELEtBSEQsTUFHTyxJQUFJLENBQUNWLElBQUwsRUFBVztBQUNoQixhQUFPLDRCQUFQO0FBQ0QsS0FWdUIsQ0FXeEI7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFdBQU8sS0FBUDtBQUNELEdBekJZO0FBMEJiO0FBQ0Esa0JBQWdCLFVBQVM1QyxFQUFULEVBQWE7QUFDM0JKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDekIsWUFBTSxDQUFDNkIsS0FBUCxDQUFhSyxNQUFiLENBQ0U7QUFDRThCLFdBQUcsRUFBRWxEO0FBRFAsT0FERixFQUlFO0FBQ0VzRCxZQUFJLEVBQUU7QUFDSiw0QkFBa0I7QUFEZDtBQURSLE9BSkY7QUFVRCxLQVhELE1BV087QUFDTCxZQUFNLElBQUlwRSxNQUFNLENBQUNxRSxLQUFYLENBQ0osT0FESSxFQUVKLDZDQUZJLENBQU47QUFJRDtBQUNGLEdBOUNZO0FBK0NiO0FBQ0Esa0JBQWdCLFVBQVN2RCxFQUFULEVBQWE7QUFDM0JKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDekIsWUFBTSxDQUFDNkIsS0FBUCxDQUFhSyxNQUFiLENBQ0U7QUFDRThCLFdBQUcsRUFBRWxEO0FBRFAsT0FERixFQUlFO0FBQ0VzRCxZQUFJLEVBQUU7QUFDSiw0QkFBa0I7QUFEZDtBQURSLE9BSkY7QUFVRCxLQVhELE1BV087QUFDTCxZQUFNLElBQUlwRSxNQUFNLENBQUNxRSxLQUFYLENBQ0osT0FESSxFQUVKLDZDQUZJLENBQU47QUFJRDtBQUNGLEdBbkVZOztBQW9FYkMsYUFBVyxDQUFDeEQsRUFBRCxFQUFLeUQsSUFBTCxFQUFXO0FBQ3BCN0QsU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUM2RCxJQUFELEVBQU90RCxNQUFQLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDO0FBQ0E7QUFDQSxVQUFJWCxFQUFFLEtBQUssS0FBS1csTUFBaEIsRUFBd0I7QUFDdEIsY0FBTSxJQUFJekIsTUFBTSxDQUFDcUUsS0FBWCxDQUNKLE1BREksRUFFSiw4Q0FGSSxDQUFOO0FBSUQ7O0FBQ0QzQyxXQUFLLENBQUM4QyxZQUFOLENBQW1CMUQsRUFBbkIsRUFBdUJ5RCxJQUF2QjtBQUNELEtBVkQsTUFVTztBQUNMLFlBQU0sSUFBSXZFLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FDSixPQURJLEVBRUosOENBRkksQ0FBTjtBQUlEO0FBQ0YsR0F2Rlk7O0FBd0ZiSSxZQUFVLENBQUMzRCxFQUFELEVBQUs7QUFDYkosU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDs7QUFDQSxRQUFJUyxLQUFLLENBQUNDLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELENBQWhDLENBQUosRUFBZ0Q7QUFDOUN6QixZQUFNLENBQUM2QixLQUFQLENBQWFNLE1BQWIsQ0FBb0JyQixFQUFwQjtBQUNELEtBRkQsTUFFTztBQUNMLFlBQU0sSUFBSWQsTUFBTSxDQUFDcUUsS0FBWCxDQUNKLE9BREksRUFFSiw2Q0FGSSxDQUFOO0FBSUQ7QUFDRixHQWxHWTs7QUFtR2I7QUFDQSxpQkFBZSxVQUFTdkQsRUFBVCxFQUFhNEQsS0FBYixFQUFvQjtBQUNqQ2hFLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDZ0UsS0FBRCxFQUFRekQsTUFBUixDQUFMOztBQUNBLFFBQUlTLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBSixFQUFnRDtBQUM5Q3pCLFlBQU0sQ0FBQzZCLEtBQVAsQ0FBYUssTUFBYixDQUFvQjtBQUFFOEIsV0FBRyxFQUFFbEQ7QUFBUCxPQUFwQixFQUFpQztBQUFFc0QsWUFBSSxFQUFFO0FBQUUsMEJBQWdCTTtBQUFsQjtBQUFSLE9BQWpDO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTSxJQUFJMUUsTUFBTSxDQUFDcUUsS0FBWCxDQUNKLE9BREksRUFFSiw2Q0FGSSxDQUFOO0FBSUQ7QUFDRixHQS9HWTs7QUFnSGJNLGNBQVksQ0FBQ2hCLEtBQUQsRUFBUTtBQUNsQmpELFNBQUssQ0FBQ2lELEtBQUQsRUFBUTFDLE1BQVIsQ0FBTDtBQUNBLFVBQU15QyxJQUFJLEdBQUdELFFBQVEsQ0FBQ1EsZUFBVCxDQUF5Qk4sS0FBekIsQ0FBYjs7QUFDQSxRQUFJRCxJQUFKLEVBQVU7QUFDUixhQUFPLGlDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFQO0FBQ0QsR0F2SFk7O0FBd0hiO0FBQ0E7QUFDQSxlQUFhLFlBQVc7QUFDdEIsVUFBTTdCLEtBQUssR0FBRzdCLE1BQU0sQ0FBQzZCLEtBQVAsQ0FBYXZCLElBQWIsR0FBb0I0RCxLQUFwQixFQUFkO0FBQ0EsV0FBT3JDLEtBQVA7QUFDRCxHQTdIWTs7QUE4SGIrQyxvQkFBa0IsQ0FBQ25ELE1BQUQsRUFBU21DLFFBQVQsRUFBbUI7QUFDbkNsRCxTQUFLLENBQUNlLE1BQUQsRUFBU1IsTUFBVCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ2tELFFBQUQsRUFBVzNDLE1BQVgsQ0FBTDtBQUNBLFVBQU00RCxPQUFPLEdBQUduRCxLQUFLLENBQUNDLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELENBQWhDLENBQWhCOztBQUNBLFFBQUlvRCxPQUFKLEVBQWE7QUFDWHBCLGNBQVEsQ0FBQ3FCLFdBQVQsQ0FBcUJyRCxNQUFyQixFQUE2Qm1DLFFBQTdCO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTSxJQUFJNUQsTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixPQUFqQixFQUEwQixrQkFBMUIsQ0FBTjtBQUNEO0FBQ0Y7O0FBdklZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJckUsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSTRFLFNBQUo7O0FBQWM5RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUM2RSxXQUFTLENBQUM1RSxDQUFELEVBQUc7QUFBQzRFLGFBQVMsR0FBQzVFLENBQVY7QUFBWTs7QUFBMUIsQ0FBM0IsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSTZFLGNBQUo7QUFBbUIvRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDOEUsZ0JBQWMsQ0FBQzdFLENBQUQsRUFBRztBQUFDNkUsa0JBQWMsR0FBQzdFLENBQWY7QUFBaUI7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBSTNKSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFNBQVM0RSxZQUFULEdBQXdCO0FBQ2xELE1BQUksQ0FBQ0QsY0FBYyxFQUFuQixFQUF1QjtBQUNyQixTQUFLcEQsS0FBTDtBQUNEOztBQUNELFNBQU9tRCxTQUFTLENBQUN6RSxJQUFWLENBQWUsRUFBZixDQUFQO0FBQ0QsQ0FMRCxFOzs7Ozs7Ozs7OztBQ0pBTCxNQUFNLENBQUNNLE1BQVAsQ0FBYztBQUFDd0UsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJdkUsS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNEIsWUFBSjtBQUFpQjlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzhCLFNBQU8sQ0FBQzdCLENBQUQsRUFBRztBQUFDNEIsZ0JBQVksR0FBQzVCLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7O0FBRy9HLE1BQU00RSxTQUFTLEdBQUcsSUFBSXZFLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixFQUFrQztBQUFFeUUsY0FBWSxFQUFFO0FBQWhCLENBQWxDLENBQWxCOztBQUVQSCxTQUFTLENBQUM5QyxJQUFWLENBQWU7QUFDYlosUUFBTSxFQUFFLE1BQU0sSUFERDtBQUViYSxRQUFNLEVBQUUsTUFBTSxJQUZEO0FBR2JDLFFBQU0sRUFBRSxNQUFNO0FBSEQsQ0FBZjs7QUFNQSxNQUFNZ0QsY0FBYyxHQUFHLElBQUlwRCxZQUFKLENBQWlCO0FBQ3RDMkIsTUFBSSxFQUFFekMsTUFEZ0M7QUFFdENtRSxPQUFLLEVBQUVuRSxNQUYrQjtBQUd0Q29FLGFBQVcsRUFBRXBFLE1BSHlCO0FBSXRDcUUsS0FBRyxFQUFFckUsTUFKaUM7QUFLdENzRSxPQUFLLEVBQUV0RSxNQUwrQjtBQU10Q3VFLE1BQUksRUFBRXZFLE1BTmdDO0FBT3RDa0MsV0FBUyxFQUFFQztBQVAyQixDQUFqQixDQUF2Qjs7QUFVQTJCLFNBQVMsQ0FBQ3ZCLFlBQVYsQ0FBdUIyQixjQUF2QixFOzs7Ozs7Ozs7OztBQ3JCQSxJQUFJbkYsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUFrRCxJQUFJNEUsU0FBSjs7QUFBYzlFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQzZFLFdBQVMsQ0FBQzVFLENBQUQsRUFBRztBQUFDNEUsYUFBUyxHQUFDNUUsQ0FBVjtBQUFZOztBQUExQixDQUExQixFQUFzRCxDQUF0RDtBQUcxSTtBQUVBSCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiNkUsZ0JBQWMsQ0FBQ0MsUUFBRCxFQUFXTixLQUFYLEVBQWtCQyxXQUFsQixFQUErQkMsR0FBL0IsRUFBb0NDLEtBQXBDLEVBQTJDQyxJQUEzQyxFQUFpRDtBQUM3RDtBQUNBOUUsU0FBSyxDQUFDZ0YsUUFBRCxFQUFXL0UsS0FBSyxDQUFDTyxLQUFOLENBQVlDLFNBQVosRUFBdUIsSUFBdkIsRUFBNkJGLE1BQTdCLENBQVgsQ0FBTDtBQUNBUCxTQUFLLENBQUMwRSxLQUFELEVBQVFuRSxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDMkUsV0FBRCxFQUFjcEUsTUFBZCxDQUFMO0FBQ0FQLFNBQUssQ0FBQzRFLEdBQUQsRUFBTXJFLE1BQU4sQ0FBTDtBQUNBUCxTQUFLLENBQUM2RSxLQUFELEVBQVF0RSxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDOEUsSUFBRCxFQUFPdkUsTUFBUCxDQUFMOztBQUVBOEQsYUFBUyxDQUFDN0MsTUFBVixDQUNFO0FBQUU4QixTQUFHLEVBQUUwQjtBQUFQLEtBREYsRUFFRTtBQUNFdEIsVUFBSSxFQUFFO0FBQ0pWLFlBQUksRUFBRSxLQUFLakMsTUFEUDtBQUVKMkQsYUFGSTtBQUdKQyxtQkFISTtBQUlKQyxXQUpJO0FBS0pDLGFBTEk7QUFNSkMsWUFOSTtBQU9KckMsaUJBQVMsRUFBRSxJQUFJQyxJQUFKO0FBUFA7QUFEUixLQUZGLEVBYUU7QUFBRXVDLFlBQU0sRUFBRTtBQUFWLEtBYkY7QUFlRCxHQXpCWTs7QUEwQmJDLGdCQUFjLENBQUM5RSxFQUFELEVBQUs7QUFDakJKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0E4RCxhQUFTLENBQUM1QyxNQUFWLENBQWlCO0FBQUU2QixTQUFHLEVBQUVsRCxFQUFQO0FBQVc0QyxVQUFJLEVBQUUsS0FBS2pDO0FBQXRCLEtBQWpCO0FBQ0Q7O0FBN0JZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJekIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSTBGLFFBQUo7O0FBQWE1RixNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUMyRixVQUFRLENBQUMxRixDQUFELEVBQUc7QUFBQzBGLFlBQVEsR0FBQzFGLENBQVQ7QUFBVzs7QUFBeEIsQ0FBekIsRUFBbUQsQ0FBbkQ7QUFBc0QsSUFBSTZFLGNBQUo7QUFBbUIvRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDOEUsZ0JBQWMsQ0FBQzdFLENBQUQsRUFBRztBQUFDNkUsa0JBQWMsR0FBQzdFLENBQWY7QUFBaUI7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBSXRKO0FBQ0FILE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLFNBQWYsRUFBMEIsU0FBU3lGLFVBQVQsR0FBc0I7QUFDOUMsTUFBSSxDQUFDZCxjQUFjLEVBQW5CLEVBQXVCO0FBQ3JCLFdBQU8sS0FBS3BELEtBQUwsRUFBUDtBQUNEOztBQUNELFNBQU9pRSxRQUFRLENBQUN2RixJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0QsQ0FMRCxFLENBT0E7O0FBRUFOLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFNBQVMwRixjQUFULENBQXdCakYsRUFBeEIsRUFBNEI7QUFDM0RKLE9BQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsTUFBSSxDQUFDK0QsY0FBYyxFQUFuQixFQUF1QjtBQUNyQixXQUFPLEtBQUtwRCxLQUFMLEVBQVA7QUFDRDs7QUFDRCxTQUFPaUUsUUFBUSxDQUFDdkYsSUFBVCxDQUFjO0FBQUUseUJBQXFCUTtBQUF2QixHQUFkLENBQVA7QUFDRCxDQU5ELEU7Ozs7Ozs7Ozs7O0FDZEFiLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNzRixVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlyRixLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0QixZQUFKO0FBQWlCOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0QixnQkFBWSxHQUFDNUIsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDs7QUFHN0csTUFBTTBGLFFBQVEsR0FBRyxJQUFJckYsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWpCOztBQUVQb0YsUUFBUSxDQUFDNUQsSUFBVCxDQUFjO0FBQ1paLFFBQU0sRUFBRSxNQUFNLElBREY7QUFFWmEsUUFBTSxFQUFFLE1BQU0sSUFGRjtBQUdaQyxRQUFNLEVBQUUsTUFBTTtBQUhGLENBQWQ7O0FBTUEsTUFBTTZELE1BQU0sR0FBRyxFQUFmO0FBRUFBLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQixJQUFJbEUsWUFBSixDQUFpQjtBQUNoQ21FLFVBQVEsRUFBRTtBQUNSckQsUUFBSSxFQUFFNUIsTUFERTtBQUVScUMsWUFBUSxFQUFFO0FBRkYsR0FEc0I7QUFLaEM2QyxXQUFTLEVBQUU7QUFDVHRELFFBQUksRUFBRTVCLE1BREc7QUFFVHFDLFlBQVEsRUFBRTtBQUZELEdBTHFCO0FBU2hDOEMsVUFBUSxFQUFFbkY7QUFUc0IsQ0FBakIsQ0FBakI7QUFZQStFLE1BQU0sQ0FBQ0ssTUFBUCxHQUFnQixJQUFJdEUsWUFBSixDQUFpQjtBQUMvQk0sTUFBSSxFQUFFcEIsTUFEeUI7QUFFL0JxRixNQUFJLEVBQUVyRixNQUZ5QjtBQUcvQmdGLFNBQU8sRUFBRUQsTUFBTSxDQUFDQyxPQUhlO0FBSS9COUMsV0FBUyxFQUFFQyxJQUpvQjtBQUsvQm1ELFdBQVMsRUFBRXRGO0FBTG9CLENBQWpCLENBQWhCOztBQVFBNEUsUUFBUSxDQUFDckMsWUFBVCxDQUFzQndDLE1BQU0sQ0FBQ0ssTUFBN0IsRTs7Ozs7Ozs7Ozs7QUNqQ0EsSUFBSXJHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSU8sS0FBSjtBQUFVVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJdUIsS0FBSjtBQUFVekIsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3dCLE9BQUssQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsU0FBSyxHQUFDdkIsQ0FBTjtBQUFROztBQUFsQixDQUFwQyxFQUF3RCxDQUF4RDs7QUFBMkQsSUFBSTBGLFFBQUo7O0FBQWE1RixNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUMyRixVQUFRLENBQUMxRixDQUFELEVBQUc7QUFBQzBGLFlBQVEsR0FBQzFGLENBQVQ7QUFBVzs7QUFBeEIsQ0FBeEIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlxRyxNQUFKOztBQUFXdkcsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ3NHLFFBQU0sQ0FBQ3JHLENBQUQsRUFBRztBQUFDcUcsVUFBTSxHQUFDckcsQ0FBUDtBQUFTOztBQUFwQixDQUE3QixFQUFtRCxDQUFuRDtBQU05UUgsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYixnQkFBYyxTQUFTNkYsU0FBVCxDQUFtQjNGLEVBQW5CLEVBQXVCNEYsTUFBdkIsRUFBK0JDLFVBQS9CLEVBQTJDVixPQUEzQyxFQUFvRDtBQUNoRXZGLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDZ0csTUFBRCxFQUFTekYsTUFBVCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ2lHLFVBQUQsRUFBYTFGLE1BQWIsQ0FBTDtBQUNBUCxTQUFLLENBQUN1RixPQUFELEVBQVU3RSxNQUFWLENBQUw7O0FBQ0EsUUFBSU0sS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakVvRSxjQUFRLENBQUN4RSxNQUFULENBQWdCO0FBQ2QyQyxXQUFHLEVBQUVsRCxFQURTO0FBRWR1QixZQUFJLEVBQUVxRSxNQUZRO0FBR2RKLFlBQUksRUFBRUssVUFIUTtBQUlkVixlQUpjO0FBS2Q5QyxpQkFBUyxFQUFFLElBQUlDLElBQUosRUFMRztBQU1kbUQsaUJBQVMsRUFBRSxLQUFLOUU7QUFORixPQUFoQjtBQVFELEtBVEQsTUFTTztBQUNMLFlBQU0sSUFBSXpCLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIscUNBQXpCLENBQU47QUFDRDtBQUNGLEdBbEJZOztBQW1CYjtBQUNBLGdCQUFjdkQsRUFBZCxFQUFrQjRGLE1BQWxCLEVBQTBCQyxVQUExQixFQUFzQ1AsUUFBdEMsRUFBZ0RRLE9BQWhELEVBQXlEO0FBQ3ZEbEcsU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUNnRyxNQUFELEVBQVN6RixNQUFULENBQUw7QUFDQVAsU0FBSyxDQUFDaUcsVUFBRCxFQUFhMUYsTUFBYixDQUFMO0FBQ0FQLFNBQUssQ0FBQzBGLFFBQUQsRUFBV25GLE1BQVgsQ0FBTDtBQUNBUCxTQUFLLENBQUNrRyxPQUFELEVBQVUzRixNQUFWLENBQUw7O0FBRUEsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakVvRSxjQUFRLENBQUMzRCxNQUFULENBQ0U7QUFDRThCLFdBQUcsRUFBRWxEO0FBRFAsT0FERixFQUlFO0FBQ0VzRCxZQUFJLEVBQUU7QUFDSi9CLGNBQUksRUFBRXFFLE1BREY7QUFFSkosY0FBSSxFQUFFSyxVQUZGO0FBR0osOEJBQW9CUDtBQUhoQjtBQURSLE9BSkY7QUFZRCxLQWJELE1BYU87QUFDTCxZQUFNLElBQUlwRyxNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLHlDQUF6QixDQUFOO0FBQ0Q7QUFDRixHQTNDWTs7QUE0Q2I7QUFDQSxtQkFBaUIsVUFBU3ZELEVBQVQsRUFBYTtBQUM1QkosU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDs7QUFFQSxVQUFNNEYsS0FBSyxHQUFHTCxNQUFNLENBQ2pCbEcsSUFEVyxDQUNOO0FBQ0osMEJBQW9CUTtBQURoQixLQURNLEVBSVhnRyxLQUpXLEVBQWQ7O0FBS0EsUUFBSXBGLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFLFVBQUlvRixLQUFLLENBQUNFLE1BQU4sSUFBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsY0FBTSxJQUFJL0csTUFBTSxDQUFDcUUsS0FBWCxDQUNKLE9BREksRUFFSixpREFGSSxDQUFOO0FBSUQsT0FMRCxNQUtPLElBQUl3QyxLQUFLLENBQUNFLE1BQU4sS0FBaUIsQ0FBckIsRUFBd0I7QUFDN0JsQixnQkFBUSxDQUFDMUQsTUFBVCxDQUFnQnJCLEVBQWhCO0FBQ0QsT0FGTSxNQUVBO0FBQ0wsY0FBTSxJQUFJZCxNQUFNLENBQUNxRSxLQUFYLENBQ0osV0FESSxFQUVKLG1EQUZJLENBQU47QUFJRDtBQUNGO0FBQ0YsR0FwRVk7QUFxRWI7QUFDQSxtQkFBaUIsWUFBVztBQUMxQndCLFlBQVEsQ0FBQ3ZGLElBQVQsR0FBZ0I0RCxLQUFoQjtBQUNEO0FBeEVZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJbEUsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSTZHLGFBQUo7O0FBQWtCL0csTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQzhHLGVBQWEsQ0FBQzdHLENBQUQsRUFBRztBQUFDNkcsaUJBQWEsR0FBQzdHLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTlCLEVBQWtFLENBQWxFO0FBQXFFLElBQUk2RSxjQUFKO0FBQW1CL0UsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQzhFLGdCQUFjLENBQUM3RSxDQUFELEVBQUc7QUFBQzZFLGtCQUFjLEdBQUM3RSxDQUFmO0FBQWlCOztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUkxS0gsTUFBTSxDQUFDSyxPQUFQLENBQWUsZUFBZixFQUFnQyxTQUFTNEcsZ0JBQVQsR0FBNEI7QUFDMUQsTUFBSSxDQUFDakMsY0FBYyxFQUFuQixFQUF1QjtBQUNyQixTQUFLcEQsS0FBTDtBQUNEOztBQUNELFNBQU9vRixhQUFhLENBQUMxRyxJQUFkLENBQW1CLEVBQW5CLENBQVA7QUFDRCxDQUxELEU7Ozs7Ozs7Ozs7O0FDSkFMLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUN5RyxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJeEcsS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNEIsWUFBSjtBQUFpQjlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzhCLFNBQU8sQ0FBQzdCLENBQUQsRUFBRztBQUFDNEIsZ0JBQVksR0FBQzVCLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7O0FBR3ZILE1BQU02RyxhQUFhLEdBQUcsSUFBSXhHLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixlQUFyQixFQUFzQztBQUFFeUUsY0FBWSxFQUFFO0FBQWhCLENBQXRDLENBQXRCOztBQUVQOEIsYUFBYSxDQUFDL0UsSUFBZCxDQUFtQjtBQUNqQlosUUFBTSxFQUFFLE1BQU0sSUFERztBQUVqQmEsUUFBTSxFQUFFLE1BQU0sSUFGRztBQUdqQkMsUUFBTSxFQUFFLE1BQU07QUFIRyxDQUFuQjs7QUFNQSxNQUFNK0Usa0JBQWtCLEdBQUcsSUFBSW5GLFlBQUosQ0FBaUI7QUFDMUNNLE1BQUksRUFBRXBCLE1BRG9DO0FBRTFDcUUsS0FBRyxFQUFFckUsTUFGcUM7QUFHMUNrQyxXQUFTLEVBQUVDO0FBSCtCLENBQWpCLENBQTNCOztBQU1BNEQsYUFBYSxDQUFDeEQsWUFBZCxDQUEyQjBELGtCQUEzQixFOzs7Ozs7Ozs7OztBQ2pCQSxJQUFJbEgsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl1QixLQUFKO0FBQVV6QixNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDd0IsT0FBSyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixTQUFLLEdBQUN2QixDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEOztBQUEyRCxJQUFJNkcsYUFBSjs7QUFBa0IvRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDOEcsZUFBYSxDQUFDN0csQ0FBRCxFQUFHO0FBQUM2RyxpQkFBYSxHQUFDN0csQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBN0IsRUFBaUUsQ0FBakU7QUFLbk5ILE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2Isc0JBQW9CLFNBQVN1RyxlQUFULENBQXlCckcsRUFBekIsRUFBNkJzRyxZQUE3QixFQUEyQzlCLEdBQTNDLEVBQWdEO0FBQ2xFNUUsU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUMwRyxZQUFELEVBQWVuRyxNQUFmLENBQUw7QUFDQVAsU0FBSyxDQUFDNEUsR0FBRCxFQUFNckUsTUFBTixDQUFMOztBQUNBLFFBQUlTLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFdUYsbUJBQWEsQ0FBQzNGLE1BQWQsQ0FBcUI7QUFDbkIyQyxXQUFHLEVBQUVsRCxFQURjO0FBRW5CdUIsWUFBSSxFQUFFK0UsWUFGYTtBQUduQjlCLFdBSG1CO0FBSW5CbkMsaUJBQVMsRUFBRSxJQUFJQyxJQUFKLEVBSlE7QUFLbkJtRCxpQkFBUyxFQUFFLEtBQUs5RTtBQUxHLE9BQXJCLEVBRGlFLENBUWpFOztBQUNELEtBVEQsTUFTTztBQUNMLFlBQU0sSUFBSXpCLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGLEdBakJZOztBQWtCYjtBQUNBLHNCQUFvQnZELEVBQXBCLEVBQXdCc0csWUFBeEIsRUFBc0M5QixHQUF0QyxFQUEyQztBQUN6QzVFLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDMEcsWUFBRCxFQUFlbkcsTUFBZixDQUFMO0FBQ0FQLFNBQUssQ0FBQzRFLEdBQUQsRUFBTXJFLE1BQU4sQ0FBTDs7QUFFQSxRQUFJUyxLQUFLLENBQUNDLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELEVBQVUsaUJBQVYsQ0FBaEMsQ0FBSixFQUFtRTtBQUNqRXVGLG1CQUFhLENBQUM5RSxNQUFkLENBQ0U7QUFBRThCLFdBQUcsRUFBRWxEO0FBQVAsT0FERixFQUVFO0FBQ0VzRCxZQUFJLEVBQUU7QUFDSi9CLGNBQUksRUFBRStFLFlBREY7QUFFSjlCO0FBRkk7QUFEUixPQUZGO0FBU0QsS0FWRCxNQVVPO0FBQ0wsWUFBTSxJQUFJdEYsTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixNQUFqQixFQUF5Qix5Q0FBekIsQ0FBTjtBQUNEO0FBQ0YsR0FyQ1k7O0FBc0NiO0FBQ0Esd0JBQXNCdkQsRUFBdEIsRUFBMEI7QUFDeEJKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBRUEsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakV1RixtQkFBYSxDQUFDN0UsTUFBZCxDQUFxQnJCLEVBQXJCO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTSxJQUFJZCxNQUFNLENBQUNxRSxLQUFYLENBQ0osV0FESSxFQUVKLDBEQUZJLENBQU47QUFJRDtBQUNGOztBQWxEWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSXJFLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlrSCxTQUFKOztBQUFjcEgsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDbUgsV0FBUyxDQUFDbEgsQ0FBRCxFQUFHO0FBQUNrSCxhQUFTLEdBQUNsSCxDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBRzlFSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLE1BQU1nSCxTQUFTLENBQUMvRyxJQUFWLENBQWUsRUFBZixDQUFsQyxFOzs7Ozs7Ozs7OztBQ0hBTCxNQUFNLENBQUNNLE1BQVAsQ0FBYztBQUFDOEcsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJN0csS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNEIsWUFBSjtBQUFpQjlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzhCLFNBQU8sQ0FBQzdCLENBQUQsRUFBRztBQUFDNEIsZ0JBQVksR0FBQzVCLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7O0FBRy9HLE1BQU1rSCxTQUFTLEdBQUcsSUFBSTdHLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixFQUFpQztBQUFFeUUsY0FBWSxFQUFFO0FBQWhCLENBQWpDLENBQWxCOztBQUVQO0FBQ0EsTUFBTWMsTUFBTSxHQUFHLEVBQWY7QUFFQUEsTUFBTSxDQUFDc0IsVUFBUCxHQUFvQixJQUFJdkYsWUFBSixDQUFpQjtBQUNuQ3FELE9BQUssRUFBRW5FLE1BRDRCO0FBRW5Dc0csVUFBUSxFQUFFdEcsTUFGeUI7QUFHbkNmLE1BQUksRUFBRWUsTUFINkI7QUFJbkNrQyxXQUFTLEVBQUVDLElBSndCO0FBS25DbUQsV0FBUyxFQUFFdEY7QUFMd0IsQ0FBakIsQ0FBcEI7O0FBUUFvRyxTQUFTLENBQUM3RCxZQUFWLENBQXVCd0MsTUFBTSxDQUFDc0IsVUFBOUIsRTs7Ozs7Ozs7Ozs7QUNoQkEsSUFBSXRILE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlrSCxTQUFKOztBQUFjcEgsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDbUgsV0FBUyxDQUFDbEgsQ0FBRCxFQUFHO0FBQUNrSCxhQUFTLEdBQUNsSCxDQUFWO0FBQVk7O0FBQTFCLENBQXpCLEVBQXFELENBQXJEO0FBRzlFSCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiLHFCQUFtQixDQUFDd0UsS0FBRCxFQUFRbUMsUUFBUixFQUFrQnJILElBQWxCLEVBQXdCbUMsSUFBeEIsS0FBaUM7QUFDbEQzQixTQUFLLENBQUMwRSxLQUFELEVBQVFuRSxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDNkcsUUFBRCxFQUFXdEcsTUFBWCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ1IsSUFBRCxFQUFPZSxNQUFQLENBQUw7QUFDQVAsU0FBSyxDQUFDMkIsSUFBRCxFQUFPcEIsTUFBUCxDQUFMOztBQUVBb0csYUFBUyxDQUFDaEcsTUFBVixDQUFpQjtBQUNmK0QsV0FEZTtBQUVmbUMsY0FGZTtBQUdmckgsVUFIZTtBQUlmaUQsZUFBUyxFQUFFLElBQUlDLElBQUosRUFKSTtBQUtmbUQsZUFBUyxFQUFFbEU7QUFMSSxLQUFqQjtBQU9EO0FBZFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0hBLElBQUlyQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJcUgsY0FBSjs7QUFBbUJ2SCxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDc0gsZ0JBQWMsQ0FBQ3JILENBQUQsRUFBRztBQUFDcUgsa0JBQWMsR0FBQ3JILENBQWY7QUFBaUI7O0FBQXBDLENBQS9CLEVBQXFFLENBQXJFO0FBQXdFLElBQUk2RSxjQUFKO0FBQW1CL0UsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQzhFLGdCQUFjLENBQUM3RSxDQUFELEVBQUc7QUFBQzZFLGtCQUFjLEdBQUM3RSxDQUFmO0FBQWlCOztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUk5S0gsTUFBTSxDQUFDSyxPQUFQLENBQWUsZUFBZixFQUFnQyxTQUFTb0gsV0FBVCxHQUF1QjtBQUNyRCxNQUFJLENBQUN6QyxjQUFjLEVBQW5CLEVBQXVCO0FBQ3JCLFNBQUtwRCxLQUFMO0FBQ0Q7O0FBQ0QsU0FBTzRGLGNBQWMsQ0FBQ2xILElBQWYsQ0FBb0I7QUFBRW1CLFVBQU0sRUFBRSxLQUFLQTtBQUFmLEdBQXBCLENBQVA7QUFDRCxDQUxELEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSXpCLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSU8sS0FBSjtBQUFVVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQzs7QUFBa0QsSUFBSXFILGNBQUo7O0FBQW1CdkgsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQ3NILGdCQUFjLENBQUNySCxDQUFELEVBQUc7QUFBQ3FILGtCQUFjLEdBQUNySCxDQUFmO0FBQWlCOztBQUFwQyxDQUE5QixFQUFvRSxDQUFwRTtBQUF1RSxJQUFJdUIsS0FBSjtBQUFVekIsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3dCLE9BQUssQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsU0FBSyxHQUFDdkIsQ0FBTjtBQUFROztBQUFsQixDQUFwQyxFQUF3RCxDQUF4RDtBQUdqTDtBQUUvQ0gsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjhHLG9CQUFrQixDQUFDdEMsS0FBRCxFQUFRdUMsUUFBUixFQUFrQkMsTUFBTSxHQUFHLEVBQTNCLEVBQStCQyxPQUFPLEdBQUcsRUFBekMsRUFBNkNDLE1BQU0sR0FBRyxFQUF0RCxFQUEwRDtBQUMxRXBILFNBQUssQ0FBQ2tILE1BQUQsRUFBUzNHLE1BQVQsQ0FBTDtBQUNBUCxTQUFLLENBQUNtSCxPQUFELEVBQVU1RyxNQUFWLENBQUw7QUFDQVAsU0FBSyxDQUFDb0gsTUFBRCxFQUFTN0csTUFBVCxDQUFMO0FBQ0FQLFNBQUssQ0FBQzBFLEtBQUQsRUFBUW5FLE1BQVIsQ0FBTDtBQUNBUCxTQUFLLENBQUNpSCxRQUFELEVBQVcxRyxNQUFYLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakUsWUFBTXNHLFNBQVMsR0FBRy9ILE1BQU0sQ0FBQzZCLEtBQVAsQ0FBYXZCLElBQWIsRUFBbEIsQ0FEaUUsQ0FFakU7O0FBQ0F5SCxlQUFTLENBQUNDLEdBQVYsQ0FBY0MsR0FBRyxJQUFJO0FBQ25CLGNBQU1qRSxHQUFHLEdBQUcsSUFBSWhFLE1BQU0sQ0FBQ1MsVUFBUCxDQUFrQnlILFFBQXRCLEdBQWlDQyxPQUFqQyxFQUFaOztBQUNBLGNBQU0xRyxNQUFNLEdBQUd3RyxHQUFHLENBQUNqRSxHQUFuQixDQUZtQixDQUduQjs7QUFDQXdELHNCQUFjLENBQUNuRyxNQUFmLENBQXNCO0FBQ3BCMkMsYUFEb0I7QUFFcEJ2QyxnQkFGb0I7QUFHcEJtRyxnQkFIb0I7QUFJcEJDLGlCQUpvQjtBQUtwQkMsZ0JBTG9CO0FBTXBCMUMsZUFOb0I7QUFPcEJ1QyxrQkFQb0I7QUFRcEJ4RSxtQkFBUyxFQUFFLElBQUlDLElBQUosRUFSUztBQVNwQmdGLGNBQUksRUFBRTtBQVRjLFNBQXRCO0FBV0QsT0FmRDtBQWdCRCxLQW5CRCxNQW1CTztBQUNMLFlBQU0sSUFBSXBJLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIsNENBQXpCLENBQU47QUFDRDtBQUNGLEdBN0JZOztBQThCYmdFLFVBQVEsQ0FBQ3ZILEVBQUQsRUFBS3dILElBQUwsRUFBVztBQUNqQjVILFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDNEgsSUFBRCxFQUFPckYsT0FBUCxDQUFMOztBQUNBdUUsa0JBQWMsQ0FBQ3RGLE1BQWYsQ0FDRTtBQUNFOEIsU0FBRyxFQUFFbEQsRUFEUDtBQUVFVyxZQUFNLEVBQUUsS0FBS0E7QUFGZixLQURGLEVBS0U7QUFDRTJDLFVBQUksRUFBRTtBQUNKZ0UsWUFBSSxFQUFFRTtBQURGO0FBRFIsS0FMRjtBQVdELEdBNUNZOztBQTZDYjtBQUNBQyx1QkFBcUIsR0FBRztBQUN0QixXQUFPZixjQUFjLENBQUNyRixNQUFmLENBQXNCO0FBQUVpRyxVQUFJLEVBQUUsSUFBUjtBQUFjM0csWUFBTSxFQUFFLEtBQUtBO0FBQTNCLEtBQXRCLENBQVA7QUFDRCxHQWhEWTs7QUFrRGI7QUFDQStHLDBCQUF3QixHQUFHO0FBQ3pCLFdBQU9oQixjQUFjLENBQUNyRixNQUFmLENBQXNCO0FBQUVWLFlBQU0sRUFBRSxLQUFLQTtBQUFmLEtBQXRCLENBQVA7QUFDRCxHQXJEWTs7QUF1RGI7QUFDQWdILG1CQUFpQixHQUFHO0FBQ2xCLFVBQU1DLElBQUksR0FBRyxJQUFJdEYsSUFBSixFQUFiO0FBQ0EsVUFBTXVGLGNBQWMsR0FBRyxFQUF2QixDQUZrQixDQUVTOztBQUMzQixVQUFNQyxZQUFZLEdBQUcsSUFBSXhGLElBQUosQ0FBU3NGLElBQUksQ0FBQ0csT0FBTCxDQUFhSCxJQUFJLENBQUNJLE9BQUwsS0FBaUJILGNBQTlCLENBQVQsQ0FBckI7QUFDQSxXQUFPbkIsY0FBYyxDQUFDckYsTUFBZixDQUFzQjtBQUFFZ0IsZUFBUyxFQUFFO0FBQUU0RixZQUFJLEVBQUVIO0FBQVI7QUFBYixLQUF0QixDQUFQO0FBQ0Q7O0FBN0RZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQTNJLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNpSCxnQkFBYyxFQUFDLE1BQUlBO0FBQXBCLENBQWQ7QUFBbUQsSUFBSWhILEtBQUo7QUFBVVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxPQUFLLENBQUNMLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTRCLFlBQUo7QUFBaUI5QixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRCLGdCQUFZLEdBQUM1QixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEOztBQUd6SCxNQUFNcUgsY0FBYyxHQUFHLElBQUloSCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBdkI7O0FBRVArRyxjQUFjLENBQUN2RixJQUFmLENBQW9CO0FBQ2xCWixRQUFNLEVBQUUsTUFBTSxJQURJO0FBRWxCYSxRQUFNLEVBQUUsTUFBTSxJQUZJO0FBR2xCQyxRQUFNLEVBQUUsTUFBTTtBQUhJLENBQXBCOztBQU1BLE1BQU02RyxXQUFXLEdBQUcsSUFBSWpILFlBQUosQ0FBaUI7QUFDbkNOLFFBQU0sRUFBRVIsTUFEMkI7QUFFbkMyRyxRQUFNLEVBQUU7QUFDTi9FLFFBQUksRUFBRTVCLE1BREE7QUFFTnFDLFlBQVEsRUFBRTtBQUZKLEdBRjJCO0FBTW5DdUUsU0FBTyxFQUFFO0FBQ1BoRixRQUFJLEVBQUU1QixNQURDO0FBRVBxQyxZQUFRLEVBQUU7QUFGSCxHQU4wQjtBQVVuQ3dFLFFBQU0sRUFBRTtBQUNOakYsUUFBSSxFQUFFNUIsTUFEQTtBQUVOcUMsWUFBUSxFQUFFO0FBRkosR0FWMkI7QUFjbkM4QixPQUFLLEVBQUVuRSxNQWQ0QjtBQWVuQzBHLFVBQVEsRUFBRTFHLE1BZnlCO0FBZ0JuQ2tDLFdBQVMsRUFBRUMsSUFoQndCO0FBaUJuQ2dGLE1BQUksRUFBRW5GO0FBakI2QixDQUFqQixDQUFwQjs7QUFvQkF1RSxjQUFjLENBQUNoRSxZQUFmLENBQTRCd0YsV0FBNUIsRTs7Ozs7Ozs7Ozs7QUMvQkEsSUFBSWhKLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThJLFNBQUosRUFBY0MsVUFBZDtBQUF5QmpKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQytJLFdBQVMsQ0FBQzlJLENBQUQsRUFBRztBQUFDOEksYUFBUyxHQUFDOUksQ0FBVjtBQUFZLEdBQTFCOztBQUEyQitJLFlBQVUsQ0FBQy9JLENBQUQsRUFBRztBQUFDK0ksY0FBVSxHQUFDL0ksQ0FBWDtBQUFhOztBQUF0RCxDQUEzQixFQUFtRixDQUFuRjtBQUFzRixJQUFJNkUsY0FBSjtBQUFtQi9FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUM4RSxnQkFBYyxDQUFDN0UsQ0FBRCxFQUFHO0FBQUM2RSxrQkFBYyxHQUFDN0UsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFJbE1ILE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLFlBQWYsRUFBNkIsU0FBUzhJLFdBQVQsR0FBdUI7QUFDbEQsTUFBSSxDQUFDbkUsY0FBYyxFQUFuQixFQUF1QjtBQUNyQixTQUFLcEQsS0FBTDtBQUNEOztBQUNELFNBQU9xSCxTQUFTLENBQUMzSSxJQUFWLEdBQWlCOEksTUFBeEI7QUFDRCxDQUxEO0FBT0FwSixNQUFNLENBQUNLLE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFNBQVM4SSxXQUFULEdBQXVCO0FBQ2xELE1BQUksQ0FBQ25FLGNBQWMsRUFBbkIsRUFBdUI7QUFDckIsU0FBS3BELEtBQUw7QUFDRDs7QUFDRCxTQUFPc0gsVUFBVSxDQUFDNUksSUFBWCxHQUFrQjhJLE1BQXpCO0FBQ0QsQ0FMRCxFLENBT0E7QUFDQSxnRTs7Ozs7Ozs7Ozs7QUNuQkEsSUFBSXBKLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXVCLEtBQUo7QUFBVXpCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUN3QixPQUFLLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLFNBQUssR0FBQ3ZCLENBQU47QUFBUTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSU8sS0FBSjtBQUFVVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJOEksU0FBSixFQUFjQyxVQUFkO0FBQXlCakosTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDK0ksV0FBUyxDQUFDOUksQ0FBRCxFQUFHO0FBQUM4SSxhQUFTLEdBQUM5SSxDQUFWO0FBQVksR0FBMUI7O0FBQTJCK0ksWUFBVSxDQUFDL0ksQ0FBRCxFQUFHO0FBQUMrSSxjQUFVLEdBQUMvSSxDQUFYO0FBQWE7O0FBQXRELENBQTFCLEVBQWtGLENBQWxGO0FBSzFOSCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNieUksZ0JBQWMsQ0FBQ3ZJLEVBQUQsRUFBS3dJLFFBQUwsRUFBZTtBQUMzQjVJLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDNEksUUFBRCxFQUFXckksTUFBWCxDQUFMOztBQUNBLFFBQUlTLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFd0gsZUFBUyxDQUFDL0csTUFBVixDQUNFO0FBQ0U4QixXQUFHLEVBQUVsRDtBQURQLE9BREYsRUFJRTtBQUNFc0QsWUFBSSxFQUFFO0FBQ0ovQixjQUFJLEVBQUVpSDtBQURGO0FBRFIsT0FKRjtBQVVELEtBWEQsTUFXTztBQUNMLFlBQU0sSUFBSXRKLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGLEdBbEJZOztBQW1CYmtGLGlCQUFlLENBQUN6SSxFQUFELEVBQUswSSxTQUFMLEVBQWdCO0FBQzdCOUksU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUM4SSxTQUFELEVBQVl2SSxNQUFaLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakV5SCxnQkFBVSxDQUFDaEgsTUFBWCxDQUNFO0FBQ0U4QixXQUFHLEVBQUVsRDtBQURQLE9BREYsRUFJRTtBQUNFc0QsWUFBSSxFQUFFO0FBQ0ovQixjQUFJLEVBQUVtSDtBQURGO0FBRFIsT0FKRjtBQVVELEtBWEQsTUFXTztBQUNMLFlBQU0sSUFBSXhKLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGLEdBcENZOztBQXFDYm9GLGdCQUFjLENBQUMzSSxFQUFELEVBQUs7QUFDakJKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakV3SCxlQUFTLENBQUM5RyxNQUFWLENBQWlCckIsRUFBakI7QUFDRCxLQUZELE1BRU87QUFDTCxZQUFNLElBQUlkLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIsNENBQXpCLENBQU47QUFDRDtBQUNGLEdBNUNZOztBQTZDYnFGLGlCQUFlLENBQUM1SSxFQUFELEVBQUs7QUFDbEJKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakV5SCxnQkFBVSxDQUFDL0csTUFBWCxDQUFrQnJCLEVBQWxCO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTSxJQUFJZCxNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLDRDQUF6QixDQUFOO0FBQ0Q7QUFDRjs7QUFwRFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBcEUsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ29KLFdBQVMsRUFBQyxNQUFJQSxTQUFmO0FBQXlCVixXQUFTLEVBQUMsTUFBSUEsU0FBdkM7QUFBaURDLFlBQVUsRUFBQyxNQUFJQTtBQUFoRSxDQUFkO0FBQTJGLElBQUkxSSxLQUFKLEVBQVVvSixjQUFWO0FBQXlCM0osTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxPQUFLLENBQUNMLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUSxHQUFsQjs7QUFBbUJ5SixnQkFBYyxDQUFDekosQ0FBRCxFQUFHO0FBQUN5SixrQkFBYyxHQUFDekosQ0FBZjtBQUFpQjs7QUFBdEQsQ0FBM0IsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSTBKLGVBQUo7QUFBb0I1SixNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDMkosaUJBQWUsQ0FBQzFKLENBQUQsRUFBRztBQUFDMEosbUJBQWUsR0FBQzFKLENBQWhCO0FBQWtCOztBQUF0QyxDQUFsQyxFQUEwRSxDQUExRTtBQUE2RSxJQUFJMkosSUFBSjtBQUFTN0osTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUMySixRQUFJLEdBQUMzSixDQUFMO0FBQU87O0FBQW5CLENBQTVCLEVBQWlELENBQWpEO0FBQW9ELElBQUk0SixFQUFKO0FBQU85SixNQUFNLENBQUNDLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRKLE1BQUUsR0FBQzVKLENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7QUFLMVY7QUFFckIsSUFBSTZKLEdBQUo7O0FBQ0EsSUFBSWhLLE1BQU0sQ0FBQ2lLLFFBQVgsRUFBcUI7QUFDbkJELEtBQUcsR0FBR0YsSUFBSSxDQUFDRixjQUFjLENBQUNNLDZCQUFmLEdBQStDQyxLQUEvQyxDQUFxREMsRUFBdEQsRUFBMERSLGNBQWMsQ0FBQ1MsU0FBekUsQ0FBVjtBQUNEOztBQUVNLE1BQU1WLFNBQVMsR0FBRyxJQUFJbkosS0FBSyxDQUFDQyxVQUFWLENBQXFCLFVBQXJCLEVBQWlDO0FBQUV5RSxjQUFZLEVBQUU7QUFBaEIsQ0FBakMsQ0FBbEI7O0FBQWdGO0FBQ3ZGLE1BQU1vRixVQUFVLEdBQUcsQ0FBQyxLQUFELEVBQVEsS0FBUixFQUFlLE1BQWYsRUFBdUIsS0FBdkIsRUFBOEIsS0FBOUIsRUFBcUMsS0FBckMsRUFBNEMsTUFBNUMsRUFBb0QsS0FBcEQsRUFBMkQsTUFBM0QsRUFBbUUsS0FBbkUsRUFBMEUsS0FBMUUsQ0FBbkI7QUFFTyxNQUFNckIsU0FBUyxHQUFHLElBQUlZLGVBQUosQ0FBb0I7QUFDM0NVLGdCQUFjLEVBQUUsV0FEMkI7QUFFM0NDLGlCQUFlLEVBQUUsSUFGMEI7O0FBRXBCO0FBQ3ZCQyxnQkFBYyxDQUFDekosSUFBRCxFQUFPO0FBQ25CO0FBQ0EsUUFBSUEsSUFBSSxDQUFDMEosSUFBTCxJQUFhLFVBQWpCLEVBQTZCO0FBQzNCLGFBQU8sdURBQVA7QUFDRCxLQUZELE1BRU8sSUFBSSxDQUFDSixVQUFVLENBQUNLLFFBQVgsQ0FBb0IzSixJQUFJLENBQUM0SixHQUF6QixDQUFMLEVBQW9DO0FBQ3pDLGFBQVEscURBQW9ETixVQUFVLENBQUNPLElBQVgsRUFBa0IsRUFBOUU7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRCxHQVgwQzs7QUFZM0NDLGVBQWEsQ0FBQzlKLElBQUQsRUFBTztBQUNsQjtBQUNBSSxVQUFNLENBQUMySixJQUFQLENBQVkvSixJQUFJLENBQUNnSyxRQUFqQixFQUEyQkMsT0FBM0IsQ0FBbUNDLFdBQVcsSUFBSTtBQUNoRCxZQUFNQyxRQUFRLEdBQUc7QUFBRUQsbUJBQUY7QUFBZXBELGNBQU0sRUFBRTlHLElBQUksQ0FBQ2dELEdBQTVCO0FBQWlDb0gsZ0JBQVEsRUFBRSxJQUFJaEksSUFBSjtBQUEzQyxPQUFqQixDQURnRCxDQUMwQjs7QUFDMUUsWUFBTWlJLFdBQVcsR0FBR3JCLEdBQUcsQ0FBQ3NCLGlCQUFKLENBQXNCO0FBQUVDLGdCQUFRLEVBQUV2SyxJQUFJLENBQUNxQixJQUFqQjtBQUF1QjhJO0FBQXZCLE9BQXRCLENBQXBCO0FBRUFwQixRQUFFLENBQUN5QixnQkFBSCxDQUFvQnhLLElBQUksQ0FBQ2dLLFFBQUwsQ0FBY0UsV0FBZCxFQUEyQjFGLElBQS9DLEVBQXFEaUcsSUFBckQsQ0FBMERKLFdBQTFEO0FBRUFBLGlCQUFXLENBQUNLLEVBQVosQ0FDRSxPQURGLEVBRUUxTCxNQUFNLENBQUMyTCxlQUFQLENBQXVCQyxZQUFZLElBQUk7QUFDckMsY0FBTUMsUUFBUSxHQUFJLFlBQVdYLFdBQVksb0JBQXpDLENBRHFDLENBRXJDO0FBQ0E7O0FBQ0EsYUFBS1ksVUFBTCxDQUFnQjVKLE1BQWhCLENBQXVCbEIsSUFBSSxDQUFDZ0QsR0FBTCxDQUFTK0gsUUFBVCxFQUF2QixFQUE0QztBQUMxQzNILGNBQUksRUFBRTtBQUNKLGFBQUN5SCxRQUFELEdBQVlELFlBQVksQ0FBQzVILEdBQWIsQ0FBaUIrSCxRQUFqQjtBQURSO0FBRG9DLFNBQTVDO0FBS0EsYUFBS0MsTUFBTCxDQUFZLEtBQUtGLFVBQUwsQ0FBZ0IvSCxPQUFoQixDQUF3Qi9DLElBQUksQ0FBQ2dELEdBQUwsQ0FBUytILFFBQVQsRUFBeEIsQ0FBWixFQUEwRGIsV0FBMUQsRUFUcUMsQ0FTbUM7QUFDekUsT0FWRCxDQUZGO0FBY0QsS0FwQkQ7QUFxQkQsR0FuQzBDOztBQW9DM0NlLG1CQUFpQixDQUFDQyxJQUFELEVBQU9sTCxJQUFQLEVBQWFrSyxXQUFiLEVBQTBCO0FBQ3pDLFVBQU1sSCxHQUFHLEdBQUcsQ0FBQ2hELElBQUksQ0FBQ2dLLFFBQUwsQ0FBY0UsV0FBZCxFQUEyQmlCLElBQTNCLElBQW1DLEVBQXBDLEVBQXdDQyxZQUFwRDs7QUFDQSxRQUFJcEksR0FBSixFQUFTO0FBQ1AsWUFBTXFJLFVBQVUsR0FBR3JDLEdBQUcsQ0FBQ3dCLGdCQUFKLENBQXFCO0FBQUV4SDtBQUFGLE9BQXJCLENBQW5CO0FBQ0FxSSxnQkFBVSxDQUFDWCxFQUFYLENBQWMsT0FBZCxFQUF1QlksR0FBRyxJQUFJO0FBQzVCLGNBQU1BLEdBQU47QUFDRCxPQUZEO0FBR0FELGdCQUFVLENBQUNaLElBQVgsQ0FBZ0JTLElBQUksQ0FBQ0ssUUFBckI7QUFDRDs7QUFDRCxXQUFPdEosT0FBTyxDQUFDZSxHQUFELENBQWQ7QUFDRCxHQTlDMEM7O0FBK0MzQ3dJLGVBQWEsQ0FBQ0MsTUFBRCxFQUFTO0FBQ3BCQSxVQUFNLENBQUN4QixPQUFQLENBQWV5QixLQUFLLElBQUk7QUFDdEJ0TCxZQUFNLENBQUMySixJQUFQLENBQVkyQixLQUFLLENBQUMxQixRQUFsQixFQUE0QkMsT0FBNUIsQ0FBb0NDLFdBQVcsSUFBSTtBQUNqRCxjQUFNbEgsR0FBRyxHQUFHLENBQUMwSSxLQUFLLENBQUMxQixRQUFOLENBQWVFLFdBQWYsRUFBNEJpQixJQUE1QixJQUFvQyxFQUFyQyxFQUF5Q0MsWUFBckQ7O0FBQ0EsWUFBSXBJLEdBQUosRUFBUztBQUNQZ0csYUFBRyxDQUFDN0gsTUFBSixDQUFXO0FBQUU2QjtBQUFGLFdBQVgsRUFBb0JzSSxHQUFHLElBQUk7QUFDekIsZ0JBQUlBLEdBQUosRUFBUyxNQUFNQSxHQUFOO0FBQ1YsV0FGRDtBQUdEO0FBQ0YsT0FQRDtBQVFELEtBVEQ7QUFVRDs7QUExRDBDLENBQXBCLENBQWxCOztBQTZEUCxJQUFJdE0sTUFBTSxDQUFDaUssUUFBWCxFQUFxQjtBQUNuQmhCLFdBQVMsQ0FBQzBELFdBQVY7QUFDRDs7QUFFTSxNQUFNekQsVUFBVSxHQUFHLElBQUlXLGVBQUosQ0FBb0I7QUFDNUNVLGdCQUFjLEVBQUUsWUFENEI7QUFFNUNDLGlCQUFlLEVBQUUsS0FGMkI7O0FBRzVDQyxnQkFBYyxDQUFDekosSUFBRCxFQUFPO0FBQ25CO0FBQ0EsUUFBSUEsSUFBSSxDQUFDMEosSUFBTCxJQUFhLFVBQWpCLEVBQTZCO0FBQzNCLGFBQU8sdURBQVA7QUFDRCxLQUZELE1BRU8sSUFBSSxDQUFDSixVQUFVLENBQUNLLFFBQVgsQ0FBb0IzSixJQUFJLENBQUM0SixHQUF6QixDQUFMLEVBQW9DO0FBQ3pDLGFBQVEscURBQW9ETixVQUFVLENBQUNPLElBQVgsRUFBa0IsRUFBOUU7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRCxHQVgyQzs7QUFZNUNDLGVBQWEsQ0FBQzlKLElBQUQsRUFBTztBQUNsQjtBQUNBSSxVQUFNLENBQUMySixJQUFQLENBQVkvSixJQUFJLENBQUNnSyxRQUFqQixFQUEyQkMsT0FBM0IsQ0FBbUNDLFdBQVcsSUFBSTtBQUNoRCxZQUFNQyxRQUFRLEdBQUc7QUFBRUQsbUJBQUY7QUFBZXBELGNBQU0sRUFBRTlHLElBQUksQ0FBQ2dELEdBQTVCO0FBQWlDb0gsZ0JBQVEsRUFBRSxJQUFJaEksSUFBSjtBQUEzQyxPQUFqQixDQURnRCxDQUMwQjs7QUFDMUUsWUFBTWlJLFdBQVcsR0FBR3JCLEdBQUcsQ0FBQ3NCLGlCQUFKLENBQXNCO0FBQUVDLGdCQUFRLEVBQUV2SyxJQUFJLENBQUNxQixJQUFqQjtBQUF1QjhJO0FBQXZCLE9BQXRCLENBQXBCO0FBRUFwQixRQUFFLENBQUN5QixnQkFBSCxDQUFvQnhLLElBQUksQ0FBQ2dLLFFBQUwsQ0FBY0UsV0FBZCxFQUEyQjFGLElBQS9DLEVBQXFEaUcsSUFBckQsQ0FBMERKLFdBQTFEO0FBRUFBLGlCQUFXLENBQUNLLEVBQVosQ0FDRSxPQURGLEVBRUUxTCxNQUFNLENBQUMyTCxlQUFQLENBQXVCQyxZQUFZLElBQUk7QUFDckMsY0FBTUMsUUFBUSxHQUFJLFlBQVdYLFdBQVksb0JBQXpDO0FBRUEsYUFBS1ksVUFBTCxDQUFnQjVKLE1BQWhCLENBQXVCbEIsSUFBSSxDQUFDZ0QsR0FBTCxDQUFTK0gsUUFBVCxFQUF2QixFQUE0QztBQUMxQzNILGNBQUksRUFBRTtBQUNKLGFBQUN5SCxRQUFELEdBQVlELFlBQVksQ0FBQzVILEdBQWIsQ0FBaUIrSCxRQUFqQjtBQURSO0FBRG9DLFNBQTVDO0FBS0EsYUFBS0MsTUFBTCxDQUFZLEtBQUtGLFVBQUwsQ0FBZ0IvSCxPQUFoQixDQUF3Qi9DLElBQUksQ0FBQ2dELEdBQUwsQ0FBUytILFFBQVQsRUFBeEIsQ0FBWixFQUEwRGIsV0FBMUQsRUFScUMsQ0FRbUM7QUFDekUsT0FURCxDQUZGO0FBYUQsS0FuQkQ7QUFvQkQsR0FsQzJDOztBQW1DNUNlLG1CQUFpQixDQUFDQyxJQUFELEVBQU9sTCxJQUFQLEVBQWFrSyxXQUFiLEVBQTBCO0FBQ3pDLFVBQU1sSCxHQUFHLEdBQUcsQ0FBQ2hELElBQUksQ0FBQ2dLLFFBQUwsQ0FBY0UsV0FBZCxFQUEyQmlCLElBQTNCLElBQW1DLEVBQXBDLEVBQXdDQyxZQUFwRDs7QUFDQSxRQUFJcEksR0FBSixFQUFTO0FBQ1AsWUFBTXFJLFVBQVUsR0FBR3JDLEdBQUcsQ0FBQ3dCLGdCQUFKLENBQXFCO0FBQUV4SDtBQUFGLE9BQXJCLENBQW5CO0FBQ0FxSSxnQkFBVSxDQUFDWCxFQUFYLENBQWMsT0FBZCxFQUF1QlksR0FBRyxJQUFJO0FBQzVCLGNBQU1BLEdBQU47QUFDRCxPQUZEO0FBR0FELGdCQUFVLENBQUNaLElBQVgsQ0FBZ0JTLElBQUksQ0FBQ0ssUUFBckI7QUFDRDs7QUFDRCxXQUFPdEosT0FBTyxDQUFDZSxHQUFELENBQWQ7QUFDRCxHQTdDMkM7O0FBOEM1Q3dJLGVBQWEsQ0FBQ0ksS0FBRCxFQUFRO0FBQ25CQSxTQUFLLENBQUMzQixPQUFOLENBQWNqSyxJQUFJLElBQUk7QUFDcEJJLFlBQU0sQ0FBQzJKLElBQVAsQ0FBWS9KLElBQUksQ0FBQ2dLLFFBQWpCLEVBQTJCQyxPQUEzQixDQUFtQ0MsV0FBVyxJQUFJO0FBQ2hELGNBQU1sSCxHQUFHLEdBQUcsQ0FBQ2hELElBQUksQ0FBQ2dLLFFBQUwsQ0FBY0UsV0FBZCxFQUEyQmlCLElBQTNCLElBQW1DLEVBQXBDLEVBQXdDQyxZQUFwRDs7QUFDQSxZQUFJcEksR0FBSixFQUFTO0FBQ1A7QUFDQWdHLGFBQUcsQ0FBQzdILE1BQUosQ0FBVztBQUFFNkI7QUFBRixXQUFYLEVBQW9Cc0ksR0FBRyxJQUFJO0FBQ3pCLGdCQUFJQSxHQUFKLEVBQVMsTUFBTUEsR0FBTjtBQUNWLFdBRkQ7QUFHRDtBQUNGLE9BUkQ7QUFTRCxLQVZEO0FBV0Q7O0FBMUQyQyxDQUFwQixDQUFuQixDOzs7Ozs7Ozs7OztBQ2hGUCxJQUFJdE0sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSTBNLFdBQUo7O0FBQWdCNU0sTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDMk0sYUFBVyxDQUFDMU0sQ0FBRCxFQUFHO0FBQUMwTSxlQUFXLEdBQUMxTSxDQUFaO0FBQWM7O0FBQTlCLENBQXhCLEVBQXdELENBQXhEO0FBR2hGSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLE1BQU13TSxXQUFXLENBQUN2TSxJQUFaLENBQWlCLEVBQWpCLENBQTNCLEU7Ozs7Ozs7Ozs7O0FDSEEsSUFBSU4sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJdUIsS0FBSjtBQUFVekIsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3dCLE9BQUssQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsU0FBSyxHQUFDdkIsQ0FBTjtBQUFROztBQUFsQixDQUFwQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUFrRCxJQUFJME0sV0FBSjs7QUFBZ0I1TSxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUMyTSxhQUFXLENBQUMxTSxDQUFELEVBQUc7QUFBQzBNLGVBQVcsR0FBQzFNLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkIsRUFBdUQsQ0FBdkQ7QUFLak5ILE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I7QUFDQWtNLGtCQUFnQixDQUFDaE0sRUFBRCxFQUFLO0FBQ25CSixTQUFLLENBQUNJLEVBQUQsRUFBS0csTUFBTCxDQUFMOztBQUNBLFFBQUlTLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFb0wsaUJBQVcsQ0FBQzFLLE1BQVosQ0FBbUJyQixFQUFuQjtBQUNELEtBRkQsTUFFTztBQUNMLFlBQU0sSUFBSWQsTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixNQUFqQixFQUF5Qix5Q0FBekIsQ0FBTjtBQUNEO0FBQ0YsR0FUWTs7QUFVYjtBQUNBMEksY0FBWSxFQUFFLFVBQVNqTSxFQUFULEVBQWF1QixJQUFiLEVBQW1CO0FBQy9CM0IsU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUMyQixJQUFELEVBQU9wQixNQUFQLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakVvTCxpQkFBVyxDQUFDM0ssTUFBWixDQUNFO0FBQUU4QixXQUFHLEVBQUVsRDtBQUFQLE9BREYsRUFFRTtBQUNFc0QsWUFBSSxFQUFFO0FBQUUvQixjQUFGO0FBQVEySyxjQUFJLEVBQUU7QUFBZDtBQURSLE9BRkY7QUFNRCxLQVBELE1BT087QUFDTCxZQUFNLElBQUloTixNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLHlDQUF6QixDQUFOO0FBQ0Q7QUFDRixHQXhCWTtBQXlCYjtBQUNBLG1CQUFpQixVQUFTdkQsRUFBVCxFQUFhbU0sR0FBYixFQUFrQjVLLElBQWxCLEVBQXdCc0YsUUFBeEIsRUFBa0M7QUFDakRqSCxTQUFLLENBQUNJLEVBQUQsRUFBS0csTUFBTCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ3VNLEdBQUQsRUFBTTdMLE1BQU4sQ0FBTDtBQUNBVixTQUFLLENBQUMyQixJQUFELEVBQU9wQixNQUFQLENBQUw7QUFDQVAsU0FBSyxDQUFDaUgsUUFBRCxFQUFXMUcsTUFBWCxDQUFMOztBQUVBNEwsZUFBVyxDQUFDeEwsTUFBWixDQUFtQjtBQUNqQjJDLFNBQUcsRUFBRWxELEVBRFk7QUFFakJtTSxTQUZpQjtBQUdqQjVLLFVBSGlCO0FBSWpCc0YsY0FKaUI7QUFLakJ4RSxlQUFTLEVBQUUsSUFBSUMsSUFBSjtBQUxNLEtBQW5CO0FBT0Q7QUF2Q1ksQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBbkQsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ3NNLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUlyTSxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0QixZQUFKO0FBQWlCOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0QixnQkFBWSxHQUFDNUIsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDs7QUFHbkgsTUFBTTBNLFdBQVcsR0FBRyxJQUFJck0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQUV5RSxjQUFZLEVBQUU7QUFBaEIsQ0FBL0IsQ0FBcEI7O0FBRVAySCxXQUFXLENBQUM1SyxJQUFaLENBQWlCO0FBQ2ZaLFFBQU0sRUFBRSxNQUFNLElBREM7QUFFZmEsUUFBTSxFQUFFLE1BQU0sSUFGQztBQUdmQyxRQUFNLEVBQUUsTUFBTTtBQUhDLENBQWpCOztBQU1BLE1BQU02RCxNQUFNLEdBQUcsRUFBZjtBQUVBQSxNQUFNLENBQUNpSCxHQUFQLEdBQWEsSUFBSWxMLFlBQUosQ0FBaUI7QUFDNUI2RixRQUFNLEVBQUU7QUFDTi9FLFFBQUksRUFBRTVCLE1BREE7QUFFTnFDLFlBQVEsRUFBRTtBQUZKLEdBRG9CO0FBSzVCNEosWUFBVSxFQUFFO0FBQ1ZySyxRQUFJLEVBQUU1QixNQURJO0FBRVZxQyxZQUFRLEVBQUU7QUFGQSxHQUxnQjtBQVM1QnVFLFNBQU8sRUFBRTtBQUNQaEYsUUFBSSxFQUFFNUIsTUFEQztBQUVQcUMsWUFBUSxFQUFFO0FBRkgsR0FUbUI7QUFhNUI2SixVQUFRLEVBQUU7QUFDUnRLLFFBQUksRUFBRTVCLE1BREU7QUFFUnFDLFlBQVEsRUFBRTtBQUZGO0FBYmtCLENBQWpCLENBQWI7QUFtQkEwQyxNQUFNLENBQUNvSCxZQUFQLEdBQXNCLElBQUlyTCxZQUFKLENBQWlCO0FBQ3JDa0wsS0FBRyxFQUFFakgsTUFBTSxDQUFDaUgsR0FEeUI7QUFFckM1SyxNQUFJLEVBQUVwQixNQUYrQjtBQUdyQzBHLFVBQVEsRUFBRTFHLE1BSDJCO0FBSXJDa0MsV0FBUyxFQUFFQztBQUowQixDQUFqQixDQUF0Qjs7QUFPQXlKLFdBQVcsQ0FBQ3JKLFlBQVosQ0FBeUJ3QyxNQUFNLENBQUNvSCxZQUFoQyxFOzs7Ozs7Ozs7OztBQ3ZDQSxJQUFJcE4sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJa04sV0FBSjtBQUFnQnBOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNtTixhQUFXLENBQUNsTixDQUFELEVBQUc7QUFBQ2tOLGVBQVcsR0FBQ2xOLENBQVo7QUFBYzs7QUFBOUIsQ0FBN0IsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSW1OLE1BQUo7QUFBV3JOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ29OLFFBQU0sQ0FBQ25OLENBQUQsRUFBRztBQUFDbU4sVUFBTSxHQUFDbk4sQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxDQUE5Qzs7QUFBaUQsSUFBSW9OLFNBQUo7O0FBQWN0TixNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNxTixXQUFTLENBQUNwTixDQUFELEVBQUc7QUFBQ29OLGFBQVMsR0FBQ3BOLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSXFOLE1BQUo7QUFBV3ZOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3NOLFFBQU0sQ0FBQ3JOLENBQUQsRUFBRztBQUFDcU4sVUFBTSxHQUFDck4sQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxDQUE5QztBQU05UkgsTUFBTSxDQUFDSyxPQUFQLENBQWUsSUFBZixFQUFxQixNQUFNa04sU0FBUyxDQUFDak4sSUFBVixDQUFlLEVBQWYsQ0FBM0I7QUFFQU4sTUFBTSxDQUFDSyxPQUFQLENBQWUsUUFBZixFQUF5QixNQUFNbU4sTUFBTSxDQUFDbE4sSUFBUCxDQUFZLEVBQVosQ0FBL0I7QUFFQU4sTUFBTSxDQUFDSyxPQUFQLENBQWUsUUFBZixFQUF5QixNQUFNaU4sTUFBTSxDQUFDaE4sSUFBUCxHQUFjOEksTUFBN0M7QUFDQXBKLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLE1BQWYsRUFBdUIsTUFBTWdOLFdBQVcsQ0FBQy9NLElBQVosR0FBbUI4SSxNQUFoRCxFOzs7Ozs7Ozs7OztBQ1hBbkosTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQzhNLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUl4RCxlQUFKO0FBQW9CNUosTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQzJKLGlCQUFlLENBQUMxSixDQUFELEVBQUc7QUFBQzBKLG1CQUFlLEdBQUMxSixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBbEMsRUFBMEUsQ0FBMUU7QUFFMUQsTUFBTWtOLFdBQVcsR0FBRyxJQUFJeEQsZUFBSixDQUFvQjtBQUM3Q1UsZ0JBQWMsRUFBRSxhQUQ2QjtBQUU3Q2tELGFBQVcsRUFBRyxHQUFFQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsR0FBSSx3QkFGYTtBQUc3Q3BELGlCQUFlLEVBQUUsS0FINEI7O0FBR3JCO0FBQ3hCQyxnQkFBYyxDQUFDekosSUFBRCxFQUFPO0FBQ25CO0FBQ0EsUUFBSUEsSUFBSSxDQUFDMEosSUFBTCxJQUFhLE9BQWIsSUFBd0IsZ0JBQWdCbUQsSUFBaEIsQ0FBcUI3TSxJQUFJLENBQUM4TSxTQUExQixDQUE1QixFQUFrRTtBQUNoRSxhQUFPLElBQVA7QUFDRDs7QUFDRCxXQUFPLHVEQUFQO0FBQ0QsR0FWNEM7O0FBVzdDaEQsZUFBYSxDQUFDOUosSUFBRCxFQUFPO0FBQ2xCLFFBQUloQixNQUFNLENBQUNpSyxRQUFYLEVBQXFCO0FBQ25CO0FBQ0EsWUFBTTtBQUFFOEQsYUFBRjtBQUFTQztBQUFULFVBQTZCQyxPQUFPLENBQUMsU0FBRCxDQUExQyxDQUZtQixDQUVvQzs7O0FBQ3ZELFlBQU1DLEtBQUssR0FBRyxJQUFJSCxLQUFKLENBQVVDLGVBQVYsQ0FBZDtBQUNBRSxXQUFLLENBQUNDLFVBQU4sQ0FDRW5OLElBQUksQ0FBQ3dFLElBRFAsRUFFRXhGLE1BQU0sQ0FBQzJMLGVBQVAsQ0FBdUIsQ0FBQ1csR0FBRCxFQUFNOEIsUUFBTixLQUFtQjtBQUN4QztBQUNBLFlBQUk5QixHQUFHLElBQUksQ0FBQyxDQUFDOEIsUUFBUSxDQUFDQyxPQUFULENBQWlCLE9BQWpCLENBQWIsRUFBd0M7QUFDdEM7QUFDQSxlQUFLbE0sTUFBTCxDQUFZbkIsSUFBSSxDQUFDZ0QsR0FBakI7QUFDRDtBQUNGLE9BTkQsQ0FGRjtBQVVEO0FBQ0Y7O0FBM0I0QyxDQUFwQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUloRSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlPLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7O0FBQWtELElBQUlvTixTQUFKOztBQUFjdE4sTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDcU4sV0FBUyxDQUFDcE4sQ0FBRCxFQUFHO0FBQUNvTixhQUFTLEdBQUNwTixDQUFWO0FBQVk7O0FBQTFCLENBQXpCLEVBQXFELENBQXJEOztBQUF3RCxJQUFJbU8sT0FBSixFQUFZaEIsTUFBWjs7QUFBbUJyTixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNvTyxTQUFPLENBQUNuTyxDQUFELEVBQUc7QUFBQ21PLFdBQU8sR0FBQ25PLENBQVI7QUFBVSxHQUF0Qjs7QUFBdUJtTixRQUFNLENBQUNuTixDQUFELEVBQUc7QUFBQ21OLFVBQU0sR0FBQ25OLENBQVA7QUFBUzs7QUFBMUMsQ0FBdkIsRUFBbUUsQ0FBbkU7QUFBc0UsSUFBSWtOLFdBQUo7QUFBZ0JwTixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNtTixhQUFXLENBQUNsTixDQUFELEVBQUc7QUFBQ2tOLGVBQVcsR0FBQ2xOLENBQVo7QUFBYzs7QUFBOUIsQ0FBNUIsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXFOLE1BQUo7QUFBV3ZOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ3NOLFFBQU0sQ0FBQ3JOLENBQUQsRUFBRztBQUFDcU4sVUFBTSxHQUFDck4sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU9yWEgsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjJOLFlBQVUsQ0FBQ3pOLEVBQUQsRUFBSzBOLEdBQUwsRUFBVXhOLElBQVYsRUFBZ0I7QUFDeEJOLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDOE4sR0FBRCxFQUFNdk4sTUFBTixDQUFMO0FBQ0FQLFNBQUssQ0FBQ00sSUFBRCxFQUFPSSxNQUFQLENBQUw7O0FBQ0EsUUFBSU0sS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDNk0sYUFBTyxDQUFDak4sTUFBUixDQUFlO0FBQ2JnQixZQUFJLEVBQUVtTSxHQURPO0FBRWJ4TixZQUZhO0FBR2JtQyxpQkFBUyxFQUFFLElBQUlDLElBQUosRUFIRTtBQUlicUwsaUJBQVMsRUFBRSxLQUFLaE47QUFKSCxPQUFmO0FBTUQsS0FQRCxNQU9PO0FBQ0wsWUFBTSxJQUFJekIsTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixNQUFqQixFQUF5Qix5Q0FBekIsQ0FBTjtBQUNEO0FBQ0YsR0FmWTs7QUFpQmJxSyxZQUFVLENBQUNDLE9BQUQsRUFBVUMsU0FBVixFQUFxQjtBQUM3QmxPLFNBQUssQ0FBQ2lPLE9BQUQsRUFBVTFOLE1BQVYsQ0FBTDtBQUNBUCxTQUFLLENBQUNrTyxTQUFELEVBQVkzTixNQUFaLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDNkwsWUFBTSxDQUFDcEwsTUFBUCxDQUFjO0FBQUU4QixXQUFHLEVBQUUySztBQUFQLE9BQWQsRUFBZ0M7QUFBRXZLLFlBQUksRUFBRTtBQUFFL0IsY0FBSSxFQUFFdU07QUFBUjtBQUFSLE9BQWhDO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTSxJQUFJNU8sTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixNQUFqQixFQUF5Qix5Q0FBekIsQ0FBTjtBQUNEO0FBQ0YsR0F6Qlk7O0FBMkJid0ssY0FBWSxDQUFDL04sRUFBRCxFQUFLO0FBQ2ZKLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDNkwsWUFBTSxDQUFDbkwsTUFBUCxDQUFjckIsRUFBZDtBQUNELEtBRkQsTUFFTztBQUNMLFlBQU0sSUFBSWQsTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixNQUFqQixFQUF5Qix5Q0FBekIsQ0FBTjtBQUNEO0FBQ0YsR0FsQ1k7O0FBb0NieUssWUFBVSxDQUFDQyxNQUFELEVBQVMxTSxJQUFULEVBQWUyTSxPQUFmLEVBQXdCQyxJQUF4QixFQUE4QmpPLElBQTlCLEVBQW9DO0FBQzVDTixTQUFLLENBQUNxTyxNQUFELEVBQVM5TixNQUFULENBQUw7QUFDQVAsU0FBSyxDQUFDMkIsSUFBRCxFQUFPcEIsTUFBUCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ3NPLE9BQUQsRUFBVS9OLE1BQVYsQ0FBTDtBQUNBUCxTQUFLLENBQUN1TyxJQUFELEVBQU9oTyxNQUFQLENBQUw7QUFDQVAsU0FBSyxDQUFDTSxJQUFELEVBQU9JLE1BQVAsQ0FBTDtBQUVBaU0sZUFBVyxDQUFDbkwsTUFBWixDQUNFO0FBQUU4QixTQUFHLEVBQUUrSztBQUFQLEtBREYsRUFFRTtBQUNFM0ssVUFBSSxFQUFFO0FBQ0ovQixZQURJO0FBRUoyTSxlQUZJO0FBR0pDLFlBSEk7QUFJSmpPO0FBSkk7QUFEUixLQUZGO0FBV0QsR0F0RFk7O0FBdURiO0FBQ0EsaUJBQWVvRSxLQUFmLEVBQXNCOEosU0FBdEIsRUFBaUM7QUFDL0J4TyxTQUFLLENBQUMwRSxLQUFELEVBQVFuRSxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDd08sU0FBRCxFQUFZak8sTUFBWixDQUFMO0FBQ0EsVUFBTWtPLEtBQUssR0FBRyxJQUFJL0wsSUFBSixFQUFkO0FBQ0FvSyxVQUFNLENBQUNuTSxNQUFQLENBQWM7QUFDWitELFdBRFk7QUFFWjhKLGVBRlk7QUFHWkUsY0FBUSxFQUFFRDtBQUhFLEtBQWQ7QUFLRCxHQWpFWTs7QUFrRWI7QUFDQSxpQkFBZXJPLEVBQWYsRUFBbUJzRSxLQUFuQixFQUEwQmlLLEdBQTFCLEVBQStCO0FBQzdCM08sU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUMwRSxLQUFELEVBQVFuRSxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDMk8sR0FBRCxFQUFNcE8sTUFBTixDQUFMO0FBQ0F1TSxVQUFNLENBQUN0TCxNQUFQLENBQ0U7QUFBRThCLFNBQUcsRUFBRWxEO0FBQVAsS0FERixFQUVFO0FBQ0VzRCxVQUFJLEVBQUU7QUFBRWdCLGFBQUY7QUFBUzhKLGlCQUFTLEVBQUVHLEdBQXBCO0FBQXlCRCxnQkFBUSxFQUFFLElBQUloTSxJQUFKO0FBQW5DO0FBRFIsS0FGRjtBQU1ELEdBN0VZOztBQThFYmtNLGNBQVksQ0FBQ3hPLEVBQUQsRUFBS3lPLElBQUwsRUFBV0MsTUFBWCxFQUFtQkMsT0FBbkIsRUFBNEI7QUFDdEMvTyxTQUFLLENBQUNJLEVBQUQsRUFBS0csTUFBTCxDQUFMO0FBQ0FQLFNBQUssQ0FBQzZPLElBQUQsRUFBT3RPLE1BQVAsQ0FBTDtBQUNBUCxTQUFLLENBQUM4TyxNQUFELEVBQVM3TyxLQUFLLENBQUNPLEtBQU4sQ0FBWUUsTUFBWixFQUFvQixJQUFwQixFQUEwQkQsU0FBMUIsQ0FBVCxDQUFMO0FBQ0FULFNBQUssQ0FBQytPLE9BQUQsRUFBVTlPLEtBQUssQ0FBQ08sS0FBTixDQUFZRCxNQUFaLEVBQW9CLElBQXBCLEVBQTBCRSxTQUExQixDQUFWLENBQUw7O0FBQ0FvTSxhQUFTLENBQUNyTCxNQUFWLENBQ0U7QUFBRThCLFNBQUcsRUFBRWxEO0FBQVAsS0FERixFQUVFO0FBQ0VzRCxVQUFJLEVBQUU7QUFDSm1MLFlBREk7QUFFSkMsY0FGSTtBQUdKQztBQUhJO0FBRFIsS0FGRixFQVNFO0FBQUU5SixZQUFNLEVBQUU7QUFBVixLQVRGO0FBV0QsR0E5Rlk7O0FBK0ZiO0FBQ0ErSixnQkFBYyxDQUFDNU8sRUFBRCxFQUFLdUIsSUFBTCxFQUFXc04sR0FBWCxFQUFnQkMsTUFBaEIsRUFBd0JDLFlBQXhCLEVBQXNDO0FBQ2xEblAsU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBUCxTQUFLLENBQUMyQixJQUFELEVBQU9wQixNQUFQLENBQUw7QUFDQVAsU0FBSyxDQUFDaVAsR0FBRCxFQUFNMU8sTUFBTixDQUFMO0FBQ0FQLFNBQUssQ0FBQ2tQLE1BQUQsRUFBUzNPLE1BQVQsQ0FBTDtBQUNBUCxTQUFLLENBQUNtUCxZQUFELEVBQWU1TSxPQUFmLENBQUw7O0FBQ0FzSyxhQUFTLENBQUNyTCxNQUFWLENBQ0U7QUFBRThCLFNBQUcsRUFBRWxEO0FBQVAsS0FERixFQUVFO0FBQ0VzRCxVQUFJLEVBQUU7QUFDSi9CLFlBREk7QUFFSnNOLFdBRkk7QUFHSkMsY0FISTtBQUlKQztBQUpJO0FBRFIsS0FGRjtBQVdELEdBakhZOztBQWtIYjtBQUNBQyxhQUFXLENBQUNDLEtBQUQsRUFBUTtBQUNqQnJQLFNBQUssQ0FBQ3FQLEtBQUQsRUFBUTlNLE9BQVIsQ0FBTDs7QUFDQSxRQUFJLEtBQUt4QixNQUFULEVBQWlCO0FBQ2YsYUFBTzhMLFNBQVMsQ0FBQ3JMLE1BQVYsQ0FDTCxFQURLLEVBRUw7QUFDRWtDLFlBQUksRUFBRTtBQUNKNEwsZ0JBQU0sRUFBRUQ7QUFESjtBQURSLE9BRkssQ0FPTDtBQVBLLE9BQVA7QUFTRDs7QUFDRCxVQUFNLElBQUkvUCxNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLDJCQUF6QixDQUFOO0FBQ0Q7O0FBaklZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQXBFLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNnTixXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUkvTSxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUU1QyxNQUFNb04sU0FBUyxHQUFHLElBQUkvTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsVUFBckIsQ0FBbEI7O0FBRVA4TSxTQUFTLENBQUN0TCxJQUFWLENBQWU7QUFDYlosUUFBTSxFQUFFLE1BQU0sSUFERDtBQUViYSxRQUFNLEVBQUUsTUFBTSxJQUZEO0FBR2JDLFFBQU0sRUFBRSxNQUFNO0FBSEQsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBbEMsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQytNLFFBQU0sRUFBQyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSXpELGVBQUo7QUFBb0I1SixNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDMkosaUJBQWUsQ0FBQzFKLENBQUQsRUFBRztBQUFDMEosbUJBQWUsR0FBQzFKLENBQWhCO0FBQWtCOztBQUF0QyxDQUFsQyxFQUEwRSxDQUExRTtBQUdoRCxNQUFNbU4sTUFBTSxHQUFHLElBQUl6RCxlQUFKLENBQW9CO0FBQ3hDVSxnQkFBYyxFQUFFLFFBRHdCO0FBRXhDa0QsYUFBVyxFQUFHLEdBQUVDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxHQUFJLHlCQUZRO0FBR3hDcEQsaUJBQWUsRUFBRSxLQUh1Qjs7QUFHaEI7QUFDeEJDLGdCQUFjLENBQUN6SixJQUFELEVBQU87QUFDbkI7QUFDQSxRQUFJQSxJQUFJLENBQUMwSixJQUFMLElBQWEsT0FBYixJQUF3QixnQkFBZ0JtRCxJQUFoQixDQUFxQjdNLElBQUksQ0FBQzhNLFNBQTFCLENBQTVCLEVBQWtFO0FBQ2hFLGFBQU8sSUFBUDtBQUNEOztBQUNELFdBQU8sdURBQVA7QUFDRCxHQVZ1Qzs7QUFXeENoRCxlQUFhLENBQUM5SixJQUFELEVBQU87QUFDbEIsUUFBSWhCLE1BQU0sQ0FBQ2lLLFFBQVgsRUFBcUI7QUFDbkI7QUFDQSxZQUFNO0FBQUU4RCxhQUFGO0FBQVNDO0FBQVQsVUFBNkJDLE9BQU8sQ0FBQyxTQUFELENBQTFDLENBRm1CLENBRW9DOzs7QUFDdkQsWUFBTUMsS0FBSyxHQUFHLElBQUlILEtBQUosQ0FBVUMsZUFBVixDQUFkO0FBQ0FFLFdBQUssQ0FBQ0MsVUFBTixDQUNFbk4sSUFBSSxDQUFDd0UsSUFEUCxFQUVFeEYsTUFBTSxDQUFDMkwsZUFBUCxDQUF1QixDQUFDVyxHQUFELEVBQU04QixRQUFOLEtBQW1CO0FBQ3hDO0FBQ0EsWUFBSTlCLEdBQUcsSUFBSSxDQUFDLENBQUM4QixRQUFRLENBQUNDLE9BQVQsQ0FBaUIsT0FBakIsQ0FBYixFQUF3QztBQUN0QztBQUNBLGVBQUtsTSxNQUFMLENBQVluQixJQUFJLENBQUNnRCxHQUFqQjtBQUNEO0FBQ0YsT0FORCxDQUZGO0FBVUQ7QUFDRjs7QUEzQnVDLENBQXBCLENBQWYsQzs7Ozs7Ozs7Ozs7QUNIUC9ELE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNpTixRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUloTixLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0QixZQUFKO0FBQWlCOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0QixnQkFBWSxHQUFDNUIsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUd6RyxNQUFNcU4sTUFBTSxHQUFHLElBQUloTixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZjtBQUVQK00sTUFBTSxDQUFDdkwsSUFBUCxDQUFZO0FBQ1ZaLFFBQU0sRUFBRSxNQUFNLEtBREo7QUFFVmEsUUFBTSxFQUFFLE1BQU0sS0FGSjtBQUdWQyxRQUFNLEVBQUUsTUFBTTtBQUhKLENBQVo7QUFNQSxNQUFNOE4sV0FBVyxHQUFHLElBQUlsTyxZQUFKLENBQWlCO0FBQ25DcUQsT0FBSyxFQUFFbkUsTUFENEI7QUFFbkNpTyxXQUFTLEVBQUU7QUFDVHJNLFFBQUksRUFBRTVCLE1BREc7QUFFVHFDLFlBQVEsRUFBRTtBQUZELEdBRndCO0FBTW5DOEwsVUFBUSxFQUFFaE07QUFOeUIsQ0FBakIsQ0FBcEI7QUFRQW9LLE1BQU0sQ0FBQ2hLLFlBQVAsQ0FBb0J5TSxXQUFwQixFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJalEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSStQLFdBQUo7O0FBQWdCalEsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDZ1EsYUFBVyxDQUFDL1AsQ0FBRCxFQUFHO0FBQUMrUCxlQUFXLEdBQUMvUCxDQUFaO0FBQWM7O0FBQTlCLENBQTVCLEVBQTRELENBQTVEO0FBR2hGSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLE1BQU02UCxXQUFXLENBQUM1UCxJQUFaLENBQWlCLEVBQWpCLENBQTNCLEU7Ozs7Ozs7Ozs7O0FDSEEsSUFBSU4sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSStQLFdBQUo7O0FBQWdCalEsTUFBTSxDQUFDQyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ2dRLGFBQVcsQ0FBQy9QLENBQUQsRUFBRztBQUFDK1AsZUFBVyxHQUFDL1AsQ0FBWjtBQUFjOztBQUE5QixDQUE5QyxFQUE4RSxDQUE5RTtBQUloRixNQUFNaUssRUFBRSxHQUFHO0FBQUUrRixZQUFVLEVBQUVEO0FBQWQsQ0FBWDtBQUVBbFEsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYndQLFdBQVMsQ0FBQ3RFLFVBQUQsRUFBYTtBQUNwQnBMLFNBQUssQ0FBQ29MLFVBQUQsRUFBYWxKLEtBQWIsQ0FBTCxDQURvQixDQUVwQjs7QUFDQSxVQUFNeU4sT0FBTyxHQUFHLElBQWhCLENBSG9CLENBR0U7O0FBQ3RCLFVBQU1DLFNBQVMsR0FBRyxHQUFsQixDQUpvQixDQUlHOztBQUN2QixXQUFPQyxTQUFTLENBQUNDLFdBQVYsQ0FBc0IxRSxVQUF0QixFQUFrQ3VFLE9BQWxDLEVBQTJDQyxTQUEzQyxDQUFQO0FBQ0Q7O0FBUFksQ0FBZjtBQVVBdFEsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjZQLFlBQVUsQ0FBQzNFLFVBQUQsRUFBYTRFLEtBQWIsRUFBb0JDLEtBQXBCLEVBQTJCO0FBQ25DalEsU0FBSyxDQUFDb0wsVUFBRCxFQUFhN0ssTUFBYixDQUFMO0FBQ0FQLFNBQUssQ0FBQ2dRLEtBQUQsRUFBUXRQLE1BQVIsQ0FBTDtBQUNBVixTQUFLLENBQUNpUSxLQUFELEVBQVF2UCxNQUFSLENBQUw7QUFDQSxVQUFNd1AsSUFBSSxHQUFHeEcsRUFBRSxDQUFDMEIsVUFBRCxDQUFGLENBQWV4TCxJQUFmLENBQW9Cb1EsS0FBcEIsRUFBMkI1SixLQUEzQixFQUFiOztBQUVBLFFBQUk4SixJQUFJLENBQUM3SixNQUFMLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLGFBQU8sS0FBUDtBQUNEOztBQUVENkosUUFBSSxDQUFDM0YsT0FBTCxDQUFhOUssQ0FBQyxJQUFJO0FBQ2hCQSxPQUFDLENBQUNrQyxJQUFGLEdBQVUsR0FBRXNPLEtBQUssQ0FBQ3pOLE9BQU4sQ0FBY2IsSUFBSyxFQUEvQjtBQUNBbEMsT0FBQyxDQUFDd0QsS0FBRixHQUFVZ04sS0FBSyxDQUFDaE8sTUFBTixDQUFhLENBQWIsRUFBZ0JrTyxPQUExQjtBQUNBMVEsT0FBQyxDQUFDbUMsTUFBRixHQUFXcU8sS0FBSyxDQUFDek4sT0FBTixDQUFjWixNQUF6QjtBQUNELEtBSkQ7QUFNQSxVQUFNK04sT0FBTyxHQUFHLElBQWhCLENBaEJtQyxDQWdCYjs7QUFDdEIsVUFBTUMsU0FBUyxHQUFHLEdBQWxCLENBakJtQyxDQWlCWjs7QUFDdkIsV0FBT0MsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxJQUF0QixFQUE0QlAsT0FBNUIsRUFBcUNDLFNBQXJDLENBQVA7QUFDRDs7QUFwQlksQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQXJRLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUMyUCxhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJMVAsS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQzs7QUFFaEQsTUFBTStQLFdBQVcsR0FBRyxJQUFJMVAsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSVQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMlEsUUFBSjtBQUFhN1EsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDNFEsVUFBUSxDQUFDM1EsQ0FBRCxFQUFHO0FBQUMyUSxZQUFRLEdBQUMzUSxDQUFUO0FBQVc7O0FBQXhCLENBQTFCLEVBQW9ELENBQXBEO0FBRzdFSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLE1BQU15USxRQUFRLENBQUN4USxJQUFULENBQWMsRUFBZCxDQUFqQyxFOzs7Ozs7Ozs7OztBQ0hBLElBQUlOLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRRLFFBQUo7QUFBYTlRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUM2USxVQUFRLENBQUM1USxDQUFELEVBQUc7QUFBQzRRLFlBQVEsR0FBQzVRLENBQVQ7QUFBVzs7QUFBeEIsQ0FBcEMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSThJLFNBQUosRUFBY0MsVUFBZDtBQUF5QmpKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrSSxXQUFTLENBQUM5SSxDQUFELEVBQUc7QUFBQzhJLGFBQVMsR0FBQzlJLENBQVY7QUFBWSxHQUExQjs7QUFBMkIrSSxZQUFVLENBQUMvSSxDQUFELEVBQUc7QUFBQytJLGNBQVUsR0FBQy9JLENBQVg7QUFBYTs7QUFBdEQsQ0FBckMsRUFBNkYsQ0FBN0Y7O0FBQWdHLElBQUkwRixRQUFKOztBQUFhNUYsTUFBTSxDQUFDQyxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQzJGLFVBQVEsQ0FBQzFGLENBQUQsRUFBRztBQUFDMEYsWUFBUSxHQUFDMUYsQ0FBVDtBQUFXOztBQUF4QixDQUFqQyxFQUEyRCxDQUEzRDs7QUFBOEQsSUFBSTBNLFdBQUo7O0FBQWdCNU0sTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQzJNLGFBQVcsQ0FBQzFNLENBQUQsRUFBRztBQUFDME0sZUFBVyxHQUFDMU0sQ0FBWjtBQUFjOztBQUE5QixDQUEvQixFQUErRCxDQUEvRDs7QUFBa0UsSUFBSStQLFdBQUo7O0FBQWdCalEsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2dRLGFBQVcsQ0FBQy9QLENBQUQsRUFBRztBQUFDK1AsZUFBVyxHQUFDL1AsQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJcU4sTUFBSjtBQUFXdk4sTUFBTSxDQUFDQyxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ3NOLFFBQU0sQ0FBQ3JOLENBQUQsRUFBRztBQUFDcU4sVUFBTSxHQUFDck4sQ0FBUDtBQUFTOztBQUFwQixDQUFqQyxFQUF1RCxDQUF2RDs7QUFBMEQsSUFBSTZRLE9BQUo7O0FBQVkvUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDOFEsU0FBTyxDQUFDN1EsQ0FBRCxFQUFHO0FBQUM2USxXQUFPLEdBQUM3USxDQUFSO0FBQVU7O0FBQXRCLENBQS9CLEVBQXVELENBQXZEOztBQUEwRCxJQUFJcUcsTUFBSjs7QUFBV3ZHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNzRyxRQUFNLENBQUNyRyxDQUFELEVBQUc7QUFBQ3FHLFVBQU0sR0FBQ3JHLENBQVA7QUFBUzs7QUFBcEIsQ0FBN0IsRUFBbUQsQ0FBbkQ7QUFTcHBCO0FBRUEsTUFBTThRLEdBQUcsR0FBRyxJQUFJRixRQUFKLENBQWE7QUFDdkJHLGdCQUFjLEVBQUUsSUFETztBQUV2QkMsWUFBVSxFQUFFO0FBRlcsQ0FBYixDQUFaLEMsQ0FLQTs7QUFDQUYsR0FBRyxDQUFDRyxhQUFKLENBQWtCbEksVUFBbEIsRUFBOEI7QUFDNUJtSSxtQkFBaUIsRUFBRSxDQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLFFBQWhCLENBRFM7QUFFNUJDLGNBQVksRUFBRTtBQUNaQyxnQkFBWSxFQUFFO0FBREYsR0FGYztBQUs1QkMsV0FBUyxFQUFFO0FBQ1RDLE9BQUcsRUFBRTtBQUNIRixrQkFBWSxFQUFFO0FBRFg7QUFESTtBQUxpQixDQUE5QixFLENBV0E7O0FBQ0FOLEdBQUcsQ0FBQ0csYUFBSixDQUFrQnZFLFdBQWxCLEVBQStCO0FBQzdCd0UsbUJBQWlCLEVBQUUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixRQUFoQixDQURVO0FBRTdCQyxjQUFZLEVBQUU7QUFDWkMsZ0JBQVksRUFBRTtBQURGLEdBRmU7QUFLN0JDLFdBQVMsRUFBRTtBQUNUQyxPQUFHLEVBQUU7QUFDSEYsa0JBQVksRUFBRTtBQURYO0FBREk7QUFMa0IsQ0FBL0IsRSxDQVlBOztBQUVBTixHQUFHLENBQUNHLGFBQUosQ0FBa0JsQixXQUFsQixFQUErQjtBQUM3Qm1CLG1CQUFpQixFQUFFLENBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsUUFBaEIsQ0FEVTtBQUU3QkMsY0FBWSxFQUFFO0FBQ1pDLGdCQUFZLEVBQUU7QUFERixHQUZlO0FBSzdCQyxXQUFTLEVBQUU7QUFDVEMsT0FBRyxFQUFFO0FBQ0hGLGtCQUFZLEVBQUU7QUFEWDtBQURJO0FBTGtCLENBQS9CLEUsQ0FZQTs7QUFDQU4sR0FBRyxDQUFDRyxhQUFKLENBQWtCNUQsTUFBbEIsRUFBMEI7QUFDeEI2RCxtQkFBaUIsRUFBRSxDQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLFFBQWhCLENBREs7QUFFeEJDLGNBQVksRUFBRTtBQUNaQyxnQkFBWSxFQUFFO0FBREYsR0FGVTtBQUt4QkMsV0FBUyxFQUFFO0FBQ1RDLE9BQUcsRUFBRTtBQUNIRixrQkFBWSxFQUFFO0FBRFg7QUFESTtBQUxhLENBQTFCLEUsQ0FZQTs7QUFDQU4sR0FBRyxDQUFDRyxhQUFKLENBQWtCSixPQUFsQixFQUEyQjtBQUN6QkssbUJBQWlCLEVBQUUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixRQUFoQixDQURNO0FBRXpCQyxjQUFZLEVBQUU7QUFDWkMsZ0JBQVksRUFBRTtBQURGLEdBRlc7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxPQUFHLEVBQUU7QUFDSEYsa0JBQVksRUFBRTtBQURYO0FBREk7QUFMYyxDQUEzQixFLENBV0E7O0FBQ0FOLEdBQUcsQ0FBQ0csYUFBSixDQUFrQjVLLE1BQWxCLEVBQTBCO0FBQ3hCNkssbUJBQWlCLEVBQUUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixRQUFoQixDQURLO0FBRXhCQyxjQUFZLEVBQUU7QUFDWkMsZ0JBQVksRUFBRTtBQURGLEdBRlU7QUFLeEJDLFdBQVMsRUFBRTtBQUNUQyxPQUFHLEVBQUU7QUFDSEYsa0JBQVksRUFBRTtBQURYO0FBREk7QUFMYSxDQUExQixFLENBV0E7O0FBQ0FOLEdBQUcsQ0FBQ0csYUFBSixDQUFrQnZMLFFBQWxCLEVBQTRCO0FBQzFCd0wsbUJBQWlCLEVBQUUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixRQUFoQixDQURPO0FBRTFCQyxjQUFZLEVBQUU7QUFDWkMsZ0JBQVksRUFBRTtBQURGLEdBRlk7QUFLMUJDLFdBQVMsRUFBRTtBQUNUQyxPQUFHLEVBQUU7QUFDSEYsa0JBQVksRUFBRTtBQURYO0FBREk7QUFMZSxDQUE1QjtBQVlBTixHQUFHLENBQUNHLGFBQUosQ0FBa0JwUixNQUFNLENBQUM2QixLQUF6QixFQUFnQztBQUM5QndQLG1CQUFpQixFQUFFLENBQUMsS0FBRCxFQUFRLE1BQVIsQ0FEVztBQUU5QkMsY0FBWSxFQUFFO0FBQ1pDLGdCQUFZLEVBQUU7QUFERixHQUZnQjtBQUs5QkMsV0FBUyxFQUFFO0FBQ1RDLE9BQUcsRUFBRTtBQUNIRixrQkFBWSxFQUFFO0FBRFg7QUFESTtBQUxtQixDQUFoQztBQVlBTixHQUFHLENBQUNTLFFBQUosQ0FDRSxXQURGLEVBRUU7QUFBRUgsY0FBWSxFQUFFO0FBQWhCLENBRkYsRUFFMkI7QUFDekI7QUFDRUUsS0FBRyxFQUFFO0FBQ0hFLFVBQU0sR0FBRztBQUNQLFlBQU1DLFNBQVMsR0FBRzNJLFNBQVMsQ0FBQzNJLElBQVYsQ0FBZSxFQUFmLEVBQW1Cd0csS0FBbkIsRUFBbEI7O0FBQ0EsVUFBSThLLFNBQUosRUFBZTtBQUNiLGVBQU87QUFBRXJQLGdCQUFNLEVBQUUsU0FBVjtBQUFxQnFPLGNBQUksRUFBRWdCO0FBQTNCLFNBQVA7QUFDRDs7QUFDRCxhQUFPO0FBQ0xDLGtCQUFVLEVBQUUsR0FEUDtBQUVMQyxZQUFJLEVBQUU7QUFBRXZQLGdCQUFNLEVBQUUsTUFBVjtBQUFrQndQLGlCQUFPLEVBQUU7QUFBM0I7QUFGRCxPQUFQO0FBSUQ7O0FBVkU7QUFEUCxDQUhGO0FBbUJBZCxHQUFHLENBQUNTLFFBQUosQ0FDRSxZQURGLEVBRUU7QUFBRUgsY0FBWSxFQUFFO0FBQWhCLENBRkYsRUFHRTtBQUNFRSxLQUFHLEVBQUU7QUFDSEUsVUFBTSxHQUFHO0FBQ1A7QUFDQSxZQUFNSyxVQUFVLEdBQUc5SSxVQUFVLENBQUM1SSxJQUFYLENBQWdCLEVBQWhCLEVBQW9Cd0csS0FBcEIsRUFBbkI7O0FBQ0EsVUFBSWtMLFVBQUosRUFBZ0I7QUFDZCxlQUFPO0FBQUV6UCxnQkFBTSxFQUFFLFNBQVY7QUFBcUJxTyxjQUFJLEVBQUVvQjtBQUEzQixTQUFQO0FBQ0Q7O0FBQ0QsYUFBTztBQUNMSCxrQkFBVSxFQUFFLEdBRFA7QUFFTEMsWUFBSSxFQUFFO0FBQUV2UCxnQkFBTSxFQUFFLE1BQVY7QUFBa0J3UCxpQkFBTyxFQUFFO0FBQTNCO0FBRkQsT0FBUDtBQUlEOztBQVhFO0FBRFAsQ0FIRixFOzs7Ozs7Ozs7OztBQ3hJQSxJQUFJL1IsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOFIsSUFBSjtBQUFTaFMsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDK1IsTUFBSSxDQUFDOVIsQ0FBRCxFQUFHO0FBQUM4UixRQUFJLEdBQUM5UixDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlPLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSStSLFFBQUo7QUFBYWpTLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2dTLFVBQVEsQ0FBQy9SLENBQUQsRUFBRztBQUFDK1IsWUFBUSxHQUFDL1IsQ0FBVDtBQUFXOztBQUF4QixDQUE1QixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJMlEsUUFBSjtBQUFhN1EsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDNFEsVUFBUSxDQUFDM1EsQ0FBRCxFQUFHO0FBQUMyUSxZQUFRLEdBQUMzUSxDQUFUO0FBQVc7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBQXNELElBQUlnUyxNQUFKO0FBQVdsUyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDZ1MsVUFBTSxHQUFDaFMsQ0FBUDtBQUFTOztBQUFqQixDQUFuQyxFQUFzRCxDQUF0RDtBQU14VTtBQUVBLE1BQU07QUFBRXlQO0FBQUYsSUFBYXVDLE1BQW5CO0FBQ0EsTUFBTUMsV0FBVyxHQUFHLENBQ2xCLFFBRGtCLEVBRWxCLE1BRmtCLEVBR2xCLE9BSGtCLEVBSWxCLFdBSmtCLEVBS2xCLFlBTGtCLEVBTWxCLFFBTmtCLEVBT2xCLFFBUGtCLENBQXBCO0FBVUFwUyxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNieVIsY0FBWSxFQUFFLENBQUMxTyxLQUFELEVBQVFDLFFBQVIsS0FBcUI7QUFDakNsRCxTQUFLLENBQUNpRCxLQUFELEVBQVExQyxNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDa0QsUUFBRCxFQUFXM0MsTUFBWCxDQUFMO0FBQ0EsV0FBT2dSLElBQUksQ0FBQ0ssSUFBTCxDQUFXLEdBQUUxQyxNQUFPLGFBQXBCLEVBQWtDO0FBQ3ZDZ0IsVUFBSSxFQUFFO0FBQ0pqTixhQURJO0FBRUpDO0FBRkksT0FEaUM7QUFLdkMyTyxhQUFPLEVBQUU7QUFDUCx3QkFBZ0I7QUFEVDtBQUw4QixLQUFsQyxDQUFQO0FBU0QsR0FiWTtBQWViQyxtQkFBaUIsRUFBRSxDQUFDQyxLQUFELEVBQVFoUixNQUFSLEtBQW1CO0FBQ3BDZixTQUFLLENBQUMrUixLQUFELEVBQVF4UixNQUFSLENBQUw7QUFDQVAsU0FBSyxDQUFDZSxNQUFELEVBQVNSLE1BQVQsQ0FBTDtBQUNBbVIsZUFBVyxDQUFDcEssR0FBWixDQUFnQjBLLElBQUksSUFDbEJULElBQUksQ0FBQ1IsR0FBTCxDQUNHLEdBQUU3QixNQUFPLFFBQU84QyxJQUFLLEdBRHhCLEVBRUU7QUFDRUMsYUFBTyxFQUFFO0FBQ1Asd0JBQWdCRixLQURUO0FBRVAscUJBQWFoUjtBQUZOO0FBRFgsS0FGRixFQVFFLENBQUNtUixLQUFELEVBQVFyRyxRQUFSLEtBQXFCO0FBQ25CLFVBQUlxRyxLQUFKLEVBQVc7QUFDVEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLEtBQUssQ0FBQ0csTUFBbEIsRUFEUyxDQUNrQjtBQUM1Qjs7QUFDRCxVQUFJeEcsUUFBUSxJQUFJQSxRQUFRLENBQUNxRSxJQUF6QixFQUErQjtBQUM3QixjQUFNO0FBQ0pBLGNBQUksRUFBRTtBQUFFQTtBQUFGO0FBREYsWUFFRnJFLFFBRko7QUFHQXVFLGdCQUFRLENBQUM1TyxNQUFULENBQ0U7QUFDRVcsY0FBSSxFQUFFNlA7QUFEUixTQURGLEVBSUU7QUFDRXRPLGNBQUksRUFBRTtBQUNKd00sZ0JBREk7QUFFSjFNLGlCQUFLLEVBQUUwTSxJQUFJLENBQUM3SjtBQUZSO0FBRFIsU0FKRixFQVVFO0FBQ0VwQixnQkFBTSxFQUFFO0FBRFYsU0FWRixFQWFFLENBQUMyRyxHQUFELEVBQU0wRyxHQUFOLEtBQWM7QUFDWixjQUFJMUcsR0FBSixFQUFTO0FBQ1B1RyxtQkFBTyxDQUFDQyxHQUFSLENBQVl4RyxHQUFHLENBQUN5RyxNQUFoQixFQURPLENBQ2tCO0FBQzFCOztBQUNERixpQkFBTyxDQUFDQyxHQUFSLENBQVlFLEdBQVosRUFKWSxDQUlNO0FBQ25CLFNBbEJIO0FBb0JEO0FBQ0YsS0FyQ0gsQ0FERjtBQXdDRCxHQTFEWTtBQTJEYjtBQUNBQyxpQkFBZSxFQUFFLE1BQU07QUFDckJmLFlBQVEsQ0FDTCxHQUFFeEUsT0FBTyxDQUFDQyxHQUFSLENBQVlDLEdBQUksdUJBRGIsRUFFTixDQUFDZ0MsTUFBRCxDQUZNLEVBR04sQ0FBQ2dELEtBQUQsRUFBUU0sTUFBUixLQUFtQjtBQUNqQixVQUFJTixLQUFKLEVBQVc7QUFDVEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLEtBQVosRUFEUyxDQUNXO0FBQ3JCOztBQUNEQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUksTUFBWixFQUppQixDQUlJO0FBQ3RCLEtBUkssQ0FBUixDQURxQixDQVdyQjtBQUNBO0FBQ0Q7QUF6RVksQ0FBZixFOzs7Ozs7Ozs7OztBQ25CQWpULE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUN1USxVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUl0USxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTFDLE1BQU0yUSxRQUFRLEdBQUcsSUFBSXRRLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixFQUFpQztBQUFFeUUsY0FBWSxFQUFFO0FBQWhCLENBQWpDLENBQWpCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSWxGLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThSLElBQUo7QUFBU2hTLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQytSLE1BQUksQ0FBQzlSLENBQUQsRUFBRztBQUFDOFIsUUFBSSxHQUFDOVIsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJZ1QsS0FBSjtBQUFVbFQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDaVQsT0FBSyxDQUFDaFQsQ0FBRCxFQUFHO0FBQUNnVCxTQUFLLEdBQUNoVCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUFrRCxJQUFJcUcsTUFBSjs7QUFBV3ZHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNzRyxRQUFNLENBQUNyRyxDQUFELEVBQUc7QUFBQ3FHLFVBQU0sR0FBQ3JHLENBQVA7QUFBUzs7QUFBcEIsQ0FBN0IsRUFBbUQsQ0FBbkQ7O0FBQXNELElBQUk2USxPQUFKLEVBQVlvQyxVQUFaOztBQUF1Qm5ULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUM4USxTQUFPLENBQUM3USxDQUFELEVBQUc7QUFBQzZRLFdBQU8sR0FBQzdRLENBQVI7QUFBVSxHQUF0Qjs7QUFBdUJpVCxZQUFVLENBQUNqVCxDQUFELEVBQUc7QUFBQ2lULGNBQVUsR0FBQ2pULENBQVg7QUFBYTs7QUFBbEQsQ0FBL0IsRUFBbUYsQ0FBbkY7O0FBQXNGLElBQUkrUCxXQUFKOztBQUFnQmpRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNnUSxhQUFXLENBQUMvUCxDQUFELEVBQUc7QUFBQytQLGVBQVcsR0FBQy9QLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkMsRUFBdUUsQ0FBdkU7O0FBQTBFLElBQUlDLFFBQUo7O0FBQWFILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNFLFVBQVEsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQVEsR0FBQ0QsQ0FBVDtBQUFXOztBQUF4QixDQUFqQyxFQUEyRCxDQUEzRDs7QUFBOEQsSUFBSW9OLFNBQUo7O0FBQWN0TixNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDcU4sV0FBUyxDQUFDcE4sQ0FBRCxFQUFHO0FBQUNvTixhQUFTLEdBQUNwTixDQUFWO0FBQVk7O0FBQTFCLENBQW5DLEVBQStELENBQS9EO0FBWXJoQjtBQUVBO0FBQ0FILE1BQU0sQ0FBQ3FULE9BQVAsQ0FBZSxZQUFXO0FBQ3hCdEosSUFBRSxHQUFHdUosR0FBRyxDQUFDckYsT0FBSixDQUFZLElBQVosQ0FBTCxDQUR3QixDQUNBOztBQUN4Qi9CLE1BQUksR0FBRytCLE9BQU8sQ0FBQyxNQUFELENBQWQ7QUFDQXNGLE1BQUksR0FBR3RGLE9BQU8sQ0FBQyxNQUFELENBQWQ7QUFDQXVGLFNBQU8sR0FBR3ZGLE9BQU8sQ0FBQyxTQUFELENBQWpCO0FBQ0F3RixPQUFLLEdBQUd4RixPQUFPLENBQUMsUUFBRCxDQUFmO0FBQ0F5RixNQUFJLEdBQUd6RixPQUFPLENBQUMsZUFBRCxDQUFQLENBQXlCeUYsSUFBaEMsQ0FOd0IsQ0FPeEI7QUFDQTs7QUFFQSxNQUFJQyxVQUFVLEdBQUdMLEdBQUcsQ0FBQ3JGLE9BQUosQ0FBWSxhQUFaLENBQWpCOztBQUNBMkYsUUFBTSxDQUFDQyxVQUFQLENBQWtCRixVQUFVLENBQUNHLFVBQVgsQ0FBc0I7QUFBRUMsWUFBUSxFQUFFO0FBQVosR0FBdEIsQ0FBbEI7QUFDQUgsUUFBTSxDQUFDQyxVQUFQLENBQWtCRixVQUFVLENBQUNLLElBQVgsRUFBbEI7QUFFQSxNQUFJQyxVQUFVLEdBQUdMLE1BQU0sQ0FBQ00sTUFBUCxDQUFjLFVBQVNDLEdBQVQsRUFBY25CLEdBQWQsRUFBbUI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0EsV0FBT21CLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLE1BQXJCO0FBQ0QsR0FMZ0IsQ0FBakI7QUFNRCxDQXBCRDtBQXNCQSxJQUFJQyxZQUFZLEdBQUcsQ0FBbkI7QUFDQSxJQUFJQyxhQUFhLEdBQUcsQ0FBcEI7QUFDQSxJQUFJMUMsU0FBUyxHQUFHLEVBQWhCO0FBQ0EsSUFBSTJDLGVBQWUsR0FBRyxFQUF0QjtBQUNBLElBQUlDLG1CQUFtQixHQUFHLEVBQTFCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHLEVBQW5CO0FBQ0EsSUFBSUMsU0FBUyxHQUFHLENBQWhCO0FBQ0EsSUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHLEtBQW5CO0FBQ0EsSUFBSUMsZUFBZSxHQUFHLEtBQXRCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHLElBQW5CO0FBQ0EsSUFBSUMsTUFBTSxHQUFHLElBQWI7QUFFQSxNQUFNbkksS0FBSyxHQUFHO0FBQUVvSSxNQUFJLEVBQUUsYUFBUjtBQUF1QkMsT0FBSyxFQUFFLGNBQTlCO0FBQThDM0wsVUFBUSxFQUFFO0FBQXhELENBQWQsQyxDQUNBOztBQUNBLE1BQU00TCxZQUFZLEdBQUc7QUFBRUYsTUFBSSxFQUFFeE8sTUFBUjtBQUFnQnlPLE9BQUssRUFBRWpFLE9BQXZCO0FBQWdDMUgsVUFBUSxFQUFFOEosVUFBMUM7QUFBc0QrQixRQUFNLEVBQUUvVTtBQUE5RCxDQUFyQjtBQUVBLElBQUlnVixPQUFPLEdBQUcsSUFBZCxDLENBQW9COztBQUNwQixJQUFJQyxZQUFZLEdBQUcsSUFBbkIsQyxDQUF5QjtBQUN6QjtBQUNBOztBQUVBLE1BQU1DLFFBQVEsR0FBRzVILE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxHQUFaLEdBQWtCLG1CQUFuQztBQUNBLE1BQU0ySCxVQUFVLEdBQUc3SCxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsR0FBWixHQUFrQixrQkFBckM7QUFDQSxNQUFNNEgsVUFBVSxHQUFHOUgsT0FBTyxDQUFDQyxHQUFSLENBQVlDLEdBQVosR0FBa0Isa0JBQXJDO0FBQ0EsTUFBTTZILFVBQVUsR0FBRy9ILE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxHQUFaLEdBQWtCLFVBQXJDLEMsQ0FDQTtBQUNBO0FBQ0E7QUFFQTs7QUFDQTVOLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I4VSxZQUFVLEVBQUUsVUFBUzFVLElBQVQsRUFBZTtBQUN6Qk4sU0FBSyxDQUFDTSxJQUFELEVBQU9DLE1BQVAsQ0FBTDtBQUVBLFFBQUl1RSxJQUFJLEdBQUcrUCxVQUFVLEdBQUd2VSxJQUF4QjtBQUNBLFFBQUkyVSxVQUFVLEdBQUczVixNQUFNLENBQUM0VixJQUFQLENBQVksZ0JBQVosRUFBOEJwUSxJQUE5QixDQUFqQjs7QUFFQSxRQUFJbVEsVUFBSixFQUFnQjtBQUNkNUwsUUFBRSxDQUFDOEwsVUFBSCxDQUFjclEsSUFBZDtBQUNEO0FBQ0Y7QUFWWSxDQUFmLEUsQ0FhQTs7QUFDQXhGLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2JrVixjQUFZLEVBQUUsWUFBVztBQUN2QixRQUFJQyxPQUFPLEdBQUd4SSxTQUFTLENBQUN4SixPQUFWLENBQWtCO0FBQUVpUyxXQUFLLEVBQUU7QUFBVCxLQUFsQixDQUFkOztBQUNBLFdBQVFaLE9BQU8sR0FBR1csT0FBTyxDQUFDRSxHQUExQjtBQUNEO0FBSlksQ0FBZixFLENBTUE7O0FBQ0FqVyxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNic1YsWUFBVSxFQUFFLFVBQVNGLEtBQVQsRUFBZ0I7QUFDMUIsUUFBSUQsT0FBTyxHQUFHeEksU0FBUyxDQUFDeEosT0FBVixDQUFrQjtBQUFFaVMsV0FBSyxFQUFFQTtBQUFULEtBQWxCLENBQWQ7O0FBQ0EsV0FBUVosT0FBTyxHQUFHVyxPQUFPLENBQUNFLEdBQTFCO0FBQ0Q7QUFKWSxDQUFmLEUsQ0FPQTs7QUFDQWpXLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2J1VixhQUFXLEVBQUUsWUFBVztBQUN0QixRQUFJQyxRQUFRLEdBQUc3SSxTQUFTLENBQUN4SixPQUFWLENBQWtCLEVBQWxCLENBQWY7O0FBQ0EsV0FBUXFSLE9BQU8sR0FBR2dCLFFBQWxCO0FBQ0Q7QUFKWSxDQUFmLEUsQ0FPQTs7QUFDQXBXLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2J5VixlQUFhLEVBQUUsWUFBVztBQUN4QixRQUFJTixPQUFPLEdBQUd4SSxTQUFTLENBQUN4SixPQUFWLENBQWtCO0FBQUVpUyxXQUFLLEVBQUU7QUFBVCxLQUFsQixDQUFkOztBQUNBbkQsV0FBTyxDQUFDQyxHQUFSLENBQVlpRCxPQUFaO0FBQ0EsV0FBUWhCLE1BQU0sR0FBR2dCLE9BQU8sQ0FBQ0UsR0FBekI7QUFDRDtBQUxZLENBQWYsRSxDQVFBOztBQUNBalcsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjBWLGtCQUFnQixFQUFFLFlBQVc7QUFDM0IsUUFBSVAsT0FBTyxHQUFHeEksU0FBUyxDQUFDeEosT0FBVixDQUFrQjtBQUFFaVMsV0FBSyxFQUFFO0FBQVQsS0FBbEIsQ0FBZDs7QUFDQSxXQUFRWixPQUFPLEdBQUdXLE9BQU8sQ0FBQ0UsR0FBMUI7QUFDRDtBQUpZLENBQWYsRSxDQU9BOztBQUNBalcsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjJWLGdCQUFjLEVBQUUsVUFBU3BHLFVBQVQsRUFBcUI7QUFDbkMwQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFVc0MsT0FBdEI7QUFDQSxRQUFJOVAsR0FBRyxHQUFHOFAsT0FBTyxHQUFHLE9BQXBCLENBRm1DLENBRU47QUFDN0I7O0FBRUFuRCxRQUFJLENBQUMyRCxJQUFMLENBQVUsTUFBVixFQUFrQnRRLEdBQWxCLEVBQXVCO0FBQUVrUixZQUFNLEVBQUU7QUFBRXJHLGtCQUFVLEVBQUVBLFVBQWQ7QUFBMEJzRyxnQkFBUSxFQUFFMUI7QUFBcEM7QUFBVixLQUF2QixFQUFpRixVQUMvRW5DLEtBRCtFLEVBRS9FOEQsTUFGK0UsRUFHL0U7QUFDQTdELGFBQU8sQ0FBQ0MsR0FBUixDQUFZeE4sR0FBWixFQUFpQm9SLE1BQWpCOztBQUVBLFVBQUksQ0FBQzlELEtBQUwsRUFBWTtBQUNWLGVBQU8sSUFBUDtBQUNELE9BRkQsTUFFTztBQUNMLGVBQU8sS0FBUDtBQUNEO0FBQ0YsS0FYRDtBQVlEO0FBbEJZLENBQWYsRSxDQXFCQTtBQUNBOztBQUNBNVMsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYitWLFdBQVMsRUFBRSxZQUFXO0FBQ3BCLFFBQUlyUixHQUFHLEdBQUc4UCxPQUFPLEdBQUcsT0FBcEIsQ0FEb0IsQ0FDUztBQUM3Qjs7QUFDQSxRQUFJd0IsU0FBUyxHQUFHNVcsTUFBTSxDQUFDNkIsS0FBUCxDQUFhdkIsSUFBYixDQUFrQjtBQUFFLHdCQUFrQjtBQUFFdVcsV0FBRyxFQUFFO0FBQVA7QUFBcEIsS0FBbEIsQ0FBaEI7QUFDQSxRQUFJaFYsS0FBSyxHQUFHLEVBQVo7QUFFQStVLGFBQVMsQ0FBQzNMLE9BQVYsQ0FBa0IsVUFBUzlLLENBQVQsRUFBWTtBQUM1QjBCLFdBQUssQ0FBQ2lWLElBQU4sQ0FBVzNXLENBQVg7QUFDRCxLQUZEO0FBR0EsUUFBSXVLLElBQUksR0FBRzdJLEtBQUssQ0FBQ2tGLE1BQWpCO0FBQ0FsRixTQUFLLEdBQUdrVixJQUFJLENBQUNDLFNBQUwsQ0FBZW5WLEtBQWYsQ0FBUjtBQUVBb1EsUUFBSSxDQUFDMkQsSUFBTCxDQUFVLE1BQVYsRUFBa0J0USxHQUFsQixFQUF1QjtBQUFFa1IsWUFBTSxFQUFFO0FBQUUzVSxhQUFLLEVBQUVBLEtBQVQ7QUFBZ0I0VSxnQkFBUSxFQUFFMUI7QUFBMUI7QUFBVixLQUF2QixFQUF1RSxVQUFTbkMsS0FBVCxFQUFnQjhELE1BQWhCLEVBQXdCO0FBQzdGLFVBQUksQ0FBQzlELEtBQUwsRUFBWTtBQUNWLGVBQU8sSUFBUDtBQUNBQyxlQUFPLENBQUNDLEdBQVIsQ0FBWXhOLEdBQVosRUFBaUJvUixNQUFqQjtBQUNELE9BSEQsTUFHTztBQUNMLGVBQU8sS0FBUDtBQUNEO0FBQ0YsS0FQRDtBQVNBLFdBQU9oTSxJQUFQO0FBQ0Q7QUF2QlksQ0FBZixFLENBMEJBOztBQUNBMUssTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYnFXLGFBQVcsRUFBRSxVQUFTckcsSUFBVCxFQUFlO0FBQzFCbFEsU0FBSyxDQUFDa1EsSUFBRCxFQUFPeFAsTUFBUCxDQUFMO0FBQ0EsUUFBSU4sRUFBRSxHQUFHOFAsSUFBSSxDQUFDOVAsRUFBZDtBQUNBLFFBQUlvVyxRQUFRLEdBQUd0RyxJQUFJLENBQUNzRyxRQUFwQjtBQUNBLFFBQUk1UixHQUFHLEdBQUdzTCxJQUFJLENBQUN0TCxHQUFmO0FBQ0EsUUFBSTZSLElBQUksR0FBR3ZHLElBQUksQ0FBQ3VHLElBQWhCO0FBQ0EsUUFBSXpULElBQUksR0FBRyxLQUFLakMsTUFBTCxHQUFjbVAsSUFBSSxDQUFDbE4sSUFBbkIsR0FBMEIsV0FBckM7QUFDQSxRQUFJZ0YsSUFBSSxHQUFHa0ksSUFBSSxDQUFDbEksSUFBaEI7O0FBQ0EsUUFBSTFFLEdBQUcsR0FBR2xELEVBQUUsR0FBRzRDLElBQWY7O0FBRUEsUUFBSSxDQUFDa04sSUFBSSxDQUFDd0csTUFBVixFQUFrQjtBQUNoQjtBQUNBcFgsWUFBTSxDQUFDNkIsS0FBUCxDQUFhSyxNQUFiLENBQ0U7QUFDRThCLFdBQUcsRUFBRU47QUFEUCxPQURGLEVBSUU7QUFDRVUsWUFBSSxFQUFFO0FBQ0osMkJBQWlCO0FBRGI7QUFEUixPQUpGLEVBU0UsQ0FBQ3dPLEtBQUQsRUFBUXlFLE9BQVIsS0FBb0I7QUFDbEJ4RSxlQUFPLENBQUNDLEdBQVIsQ0FBWXVFLE9BQVosRUFEa0IsQ0FDSTtBQUN2QixPQVhIO0FBYUQ7O0FBRUQsUUFBSXpHLElBQUksQ0FBQzBHLElBQUwsSUFBYW5XLFNBQWpCLEVBQTRCO0FBQzFCbVcsVUFBSSxHQUFHLENBQVA7QUFDRCxLQUZELE1BRU87QUFDTEEsVUFBSSxHQUFHMUcsSUFBSSxDQUFDMEcsSUFBWjtBQUNEOztBQUVELFFBQUkxRyxJQUFJLENBQUM2RixRQUFMLElBQWlCdFYsU0FBckIsRUFBZ0M7QUFDOUJzVixjQUFRLEdBQUcxQixNQUFYO0FBQ0Q7O0FBRUQ3RSxlQUFXLENBQUNoTyxNQUFaLENBQ0U7QUFBRThCLFNBQUcsRUFBRUE7QUFBUCxLQURGLEVBRUU7QUFDRUksVUFBSSxFQUFFO0FBQ0pxUyxnQkFBUSxFQUFFLFVBRE47QUFFSlMsZ0JBRkk7QUFHSjVSLFdBSEk7QUFJSjZSLFlBSkk7QUFLSnpPLFlBTEk7QUFNSmhGLFlBTkk7QUFPSjVDO0FBUEksT0FEUjtBQVVFeVcsVUFBSSxFQUFFO0FBQUVEO0FBQUY7QUFWUixLQUZGLEVBY0U7QUFBRTNSLFlBQU0sRUFBRTtBQUFWLEtBZEY7QUFnQkQ7QUF0RFksQ0FBZixFLENBeURBOztBQUNBM0YsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjRXLFlBQVUsRUFBRSxVQUFTNUcsSUFBVCxFQUFlNkYsUUFBZixFQUF5QjtBQUNuQyxRQUFJM1YsRUFBRSxHQUFHOFAsSUFBSSxDQUFDNU0sR0FBZDtBQUNBLFFBQUlyQixNQUFNLEdBQUdpTyxJQUFJLENBQUNqTyxNQUFsQjtBQUNBLFFBQUlPLE9BQU8sR0FBRzBOLElBQUksQ0FBQzFOLE9BQW5CO0FBQ0FBLFdBQU8sQ0FBQyxVQUFELENBQVAsR0FBc0J1VCxRQUF0QjtBQUNBdlQsV0FBTyxDQUFDQyxTQUFSLEdBQW9CLElBQUlDLElBQUosRUFBcEI7QUFFQXBELFVBQU0sQ0FBQzZCLEtBQVAsQ0FBYUssTUFBYixDQUNFO0FBQUU4QixTQUFHLEVBQUVsRDtBQUFQLEtBREYsRUFFRTtBQUFFc0QsVUFBSSxFQUFFO0FBQUV6QixjQUFNLEVBQUVBLE1BQVY7QUFBa0JPLGVBQU8sRUFBRUE7QUFBM0I7QUFBUixLQUZGLEVBR0U7QUFBRXlDLFlBQU0sRUFBRTtBQUFWLEtBSEY7QUFLRDtBQWJZLENBQWYsRSxDQWdCQTs7QUFDQTNGLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I2VyxnQkFBYyxFQUFFLFVBQVNDLFFBQVQsRUFBbUJqQixRQUFuQixFQUE2QmtCLEtBQTdCLEVBQW9DO0FBQ2xELFFBQUkxQixHQUFHLEdBQUcsS0FBVjtBQUNBLFFBQUkxVCxNQUFNLEdBQUcsSUFBYjtBQUNBLFFBQUlxVixPQUFPLEdBQUcsSUFBZDs7QUFDQSxRQUFJMUMsWUFBWSxDQUFDd0MsUUFBRCxDQUFaLElBQTBCdlcsU0FBOUIsRUFBeUM7QUFDdkMsYUFBTyxJQUFQO0FBQ0QsS0FGRCxNQUVPLElBQUl3VyxLQUFKLEVBQVc7QUFDaEIxQixTQUFHLEdBQUcsSUFBTjtBQUNBMVQsWUFBTSxHQUFHLEtBQVQ7QUFDRDs7QUFFRCxRQUFJcU8sSUFBSSxHQUFHLEVBQVg7QUFDQSxRQUFJRixLQUFLLEdBQUcsRUFBWjtBQUVBQSxTQUFLLENBQUMsVUFBVStGLFFBQVgsQ0FBTCxHQUE0QlIsR0FBNUI7O0FBRUEsUUFBSXlCLFFBQVEsSUFBSSxVQUFoQixFQUE0QjtBQUMxQkUsYUFBTyxHQUFHMUMsWUFBWSxDQUFDd0MsUUFBRCxDQUFaLENBQXVCcFgsSUFBdkIsQ0FBNEIsRUFBNUIsQ0FBVjtBQUNELEtBRkQsTUFFTyxJQUFJb1gsUUFBUSxJQUFJLE9BQWhCLEVBQXlCO0FBQzlCRSxhQUFPLEdBQUcxQyxZQUFZLENBQUN3QyxRQUFELENBQVosQ0FBdUJwWCxJQUF2QixDQUE0QixFQUE1QixDQUFWO0FBQ0QsS0FGTSxNQUVBO0FBQ0xzWCxhQUFPLEdBQUcxQyxZQUFZLENBQUN3QyxRQUFELENBQVosQ0FBdUJwWCxJQUF2QixDQUE0QjtBQUFFb1E7QUFBRixPQUE1QixDQUFWO0FBQ0Q7O0FBRURrSCxXQUFPLENBQUMzTSxPQUFSLENBQWdCLFVBQVM5SyxDQUFULEVBQVk7QUFDMUIsVUFBSVcsRUFBRSxHQUFHWCxDQUFDLENBQUM2RCxHQUFYO0FBQ0EsVUFBSXpDLElBQUksR0FBR3BCLENBQUMsQ0FBQ29CLElBQWI7O0FBRUEsVUFBSUEsSUFBSSxJQUFJSixTQUFaLEVBQXVCO0FBQ3JCSSxZQUFJLEdBQUcsRUFBUDtBQUNEOztBQUVEQSxVQUFJLENBQUNrVixRQUFELENBQUosR0FBaUJsVSxNQUFqQjtBQUVBOzs7QUFJQTs7QUFDQTJTLGtCQUFZLENBQUN3QyxRQUFELENBQVosQ0FBdUJ4VixNQUF2QixDQUE4QjtBQUFFOEIsV0FBRyxFQUFFbEQ7QUFBUCxPQUE5QixFQUEyQztBQUFFc0QsWUFBSSxFQUFFO0FBQUU3QztBQUFGO0FBQVIsT0FBM0M7QUFFQXFQLFVBQUksQ0FBQ2tHLElBQUwsQ0FBVTNXLENBQVY7QUFDRCxLQWxCRCxFQXhCa0QsQ0EyQ2xEOztBQUVBLFFBQUk7QUFDRjtBQUNBLGFBQU95USxJQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU9pSCxDQUFQLEVBQVU7QUFDVixhQUFPLElBQVA7QUFDRDtBQUNGO0FBcERZLENBQWYsRSxDQXVEQTs7QUFDQTdYLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2JrWCxhQUFXLEVBQUUsVUFBU0MsYUFBVCxFQUF3QjtBQUNuQy9YLFVBQU0sQ0FBQzRWLElBQVAsQ0FBWSxlQUFaO0FBQ0EvQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFhd0IsYUFBekIsRUFBd0MsaUJBQWlCMUMsU0FBUyxDQUFDN0ssTUFBbkU7O0FBRUEsUUFBSW5FLEtBQUssQ0FBQ29WLE9BQU4sQ0FBY0QsYUFBZCxLQUFnQ0EsYUFBYSxDQUFDaFIsTUFBZCxHQUF1QixDQUEzRCxFQUE4RDtBQUM1RHVOLG1CQUFhLEdBQUcsQ0FBaEI7QUFDQTFDLGVBQVMsR0FBR21HLGFBQVo7QUFDQWxGLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUE4QmxCLFNBQVMsQ0FBQzdLLE1BQXBEO0FBQ0QsS0FKRCxNQUlPLElBQUk2SyxTQUFTLENBQUM3SyxNQUFWLElBQW9CLENBQXhCLEVBQTJCO0FBQ2hDO0FBQ0E4TCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWjtBQUNBOEIsa0JBQVksR0FBRyxLQUFmO0FBQ0EsYUFKZ0MsQ0FJeEI7QUFDVCxLQUxNLE1BS0EsSUFBSU4sYUFBYSxJQUFJMUMsU0FBUyxDQUFDN0ssTUFBL0IsRUFBdUM7QUFDNUM7QUFDQThMLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFpQ2xCLFNBQVMsQ0FBQzdLLE1BQXZEO0FBQ0E2TixrQkFBWSxHQUFHLEtBQWY7QUFDQTtBQUNEOztBQUVELFFBQUksQ0FBQ0EsWUFBTCxFQUFtQjtBQUNqQjtBQUNEOztBQUVEL0IsV0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWXdCLGFBQVosR0FBNEIsVUFBNUIsR0FBeUMxQyxTQUFTLENBQUM3SyxNQUEvRDtBQUNBLFFBQUl1QyxRQUFRLEdBQUdzSSxTQUFTLENBQUMwQyxhQUFELENBQXhCLENBekJtQyxDQXlCTTs7QUFDekNHLGdCQUFZLEdBQUduTCxRQUFRLENBQUNqSCxJQUF4QjtBQUNBZ1MsZ0JBQVksR0FBRy9LLFFBQVEsQ0FBQ29CLElBQXhCO0FBQ0FvSyxnQkFBWSxHQUFHUyxVQUFVLEdBQUdkLFlBQTVCO0FBQ0FZLGdCQUFZLEdBQUdELE9BQU8sR0FBRyxVQUFWLEdBQXVCWCxZQUF0QztBQUNBLFFBQUlrQixVQUFVLEdBQUcsSUFBakIsQ0E5Qm1DLENBOEJaO0FBRXZCOztBQUNBNUwsTUFBRSxDQUFDa08sSUFBSCxDQUFRbkQsWUFBUixFQUFzQixVQUFTeEksR0FBVCxFQUFjN0osS0FBZCxFQUFxQjtBQUN6QztBQUNBLFVBQUlBLEtBQUssSUFBSUEsS0FBSyxDQUFDaUksSUFBTixJQUFjMkosWUFBM0IsRUFBeUM7QUFDdkM7QUFDQXhCLGVBQU8sQ0FBQ0MsR0FBUixDQUFZMkIsWUFBWSxHQUFHLEtBQWYsR0FBdUJoUyxLQUFLLENBQUNpSSxJQUE3QixHQUFvQyxPQUFwQyxHQUE4QzJKLFlBQTFEO0FBQ0FRLHVCQUFlLEdBQUcsSUFBbEI7QUFDQWhDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQmdDLFlBQWxDO0FBQ0FSLHFCQUFhO0FBQ2JxQixrQkFBVSxHQUFHLEtBQWI7QUFDQWYsb0JBQVksR0FBRyxLQUFmO0FBQ0FDLHVCQUFlLEdBQUcsSUFBbEI7QUFDRCxPQVRELE1BU08sSUFBSXBTLEtBQUssSUFBSUEsS0FBSyxDQUFDaUksSUFBTixLQUFlMkosWUFBeEIsSUFBd0MsQ0FBQy9ILEdBQTdDLEVBQWtEO0FBQ3ZEdUcsZUFBTyxDQUFDQyxHQUFSLENBQVksaUJBQWlCMkIsWUFBakIsR0FBZ0MsS0FBaEMsR0FBd0NoUyxLQUFLLENBQUNpSSxJQUE5QyxHQUFxRCxPQUFyRCxHQUErRDJKLFlBQTNFLEVBRHVELENBR3ZEOztBQUNBdEssVUFBRSxDQUFDOEwsVUFBSCxDQUFjclEsSUFBZCxFQUp1RCxDQUlsQztBQUNyQjs7QUFDQW1RLGtCQUFVLEdBQUcsSUFBYjtBQUNELE9BUE0sTUFPQSxJQUFJckosR0FBRyxJQUFJQSxHQUFHLENBQUM0TCxLQUFKLEtBQWMsRUFBekIsRUFBNkI7QUFDbEM7QUFFQTtBQUNBO0FBQ0F2QyxrQkFBVSxHQUFHLElBQWI7QUFDRDs7QUFDRCxVQUFJZixZQUFKLEVBQWtCO0FBQ2hCbkIsYUFBSyxDQUFDLFlBQVc7QUFDZjtBQUNBelQsZ0JBQU0sQ0FBQzRWLElBQVAsQ0FBWSxrQkFBWjtBQUNELFNBSEksQ0FBTCxDQUdHdUMsR0FISDtBQUlELE9BTEQsTUFLTztBQUNMO0FBQ0Q7QUFDRixLQWpDRDtBQWtDRDtBQXBFWSxDQUFmLEUsQ0F1RUE7O0FBQ0FuWSxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNid1gscUJBQW1CLEVBQUUsVUFBU0wsYUFBVCxFQUF3QjtBQUMzQyxRQUFJLENBQUNuRCxZQUFMLEVBQW1CLENBRWxCLENBRkQsQ0FDRTtBQUdGO0FBQ0E7OztBQUNBLFdBQU87QUFDTEgsa0JBQVksRUFBRUEsWUFEVDtBQUVMSixrQkFBWSxFQUFFQSxZQUZUO0FBR0xNLG1CQUFhLEVBQUVBLGFBSFY7QUFJTEwsbUJBQWEsRUFBRUEsYUFKVjtBQUtMSSxlQUFTLEVBQUVBLFNBTE47QUFNTDlDLGVBQVMsRUFBRUEsU0FBUyxDQUFDN0ssTUFOaEI7QUFPTHVOLG1CQUFhLEVBQUVBO0FBUFYsS0FBUDtBQVNEO0FBakJZLENBQWYsRSxDQW9CQTs7QUFDQXRVLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2J5WCxlQUFhLEVBQUUsWUFBVztBQUN4QnhELG1CQUFlLEdBQUcsS0FBbEI7QUFDQUosZ0JBQVksR0FBRyxFQUFmO0FBQ0FKLGdCQUFZLEdBQUcsQ0FBZjtBQUNBSyxhQUFTLEdBQUcsQ0FBWjtBQUNBQyxpQkFBYSxHQUFHLENBQWhCO0FBQ0FDLGdCQUFZLEdBQUcsSUFBZjtBQUNEO0FBUlksQ0FBZixFLENBV0E7O0FBQ0E1VSxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiMFgsYUFBVyxFQUFFLFVBQVNoUCxRQUFULEVBQW1CO0FBQzlCLFFBQUlBLFFBQVEsQ0FBQzlELElBQVQsSUFBaUIsUUFBckIsRUFBK0I7QUFDN0JzUCxrQkFBWSxHQUFHVSxVQUFVLEdBQUdsTSxRQUFRLENBQUNqSCxJQUFyQztBQUNELEtBRkQsTUFFTyxJQUFJaUgsUUFBUSxDQUFDOUQsSUFBVCxJQUFpQixRQUFyQixFQUErQjtBQUNwQ3NQLGtCQUFZLEdBQUdTLFVBQVUsR0FBR2pNLFFBQVEsQ0FBQ2pILElBQXJDO0FBQ0QsS0FGTSxNQUVBO0FBQ0x1UyxrQkFBWSxHQUFHLEtBQWY7QUFDQTtBQUNEOztBQUNEUyxnQkFBWSxHQUFHL0wsUUFBUSxDQUFDK0wsWUFBeEI7QUFDQVIsbUJBQWUsR0FBRyxLQUFsQjtBQUNBSixnQkFBWSxHQUFHbkwsUUFBUSxDQUFDakgsSUFBeEI7QUFDQWdTLGdCQUFZLEdBQUcvSyxRQUFRLENBQUNvQixJQUF4QjtBQUNBZ0ssYUFBUyxHQUFHLENBQVo7QUFDQUMsaUJBQWEsR0FBRyxDQUFoQjtBQUNBQyxnQkFBWSxHQUFHLElBQWY7QUFDRDtBQWpCWSxDQUFmLEUsQ0FvQkE7O0FBQ0E1VSxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiMlgsa0JBQWdCLEVBQUUsWUFBVztBQUMzQixRQUFJLENBQUMzRCxZQUFMLEVBQW1CO0FBQ2pCL0IsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQVo7QUFDQTtBQUNEOztBQUVERCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFXdUMsWUFBdkI7QUFFQXhDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZOEIsWUFBWixFQUEwQixtQkFBbUJILFlBQTdDO0FBRUEsUUFBSW5QLEdBQUcsR0FBRytQLFlBQVYsQ0FWMkIsQ0FXM0I7O0FBQ0EsUUFBSXJVLElBQUksR0FBRytJLEVBQUUsQ0FBQ3VCLGlCQUFILENBQXFCd0osWUFBckIsQ0FBWCxDQVoyQixDQWEzQjs7QUFFQSxRQUFJWCxHQUFHLEdBQUdqSSxJQUFJLENBQUNzSCxPQUFMLENBQWFsTyxHQUFiLEVBQWtCLFVBQVNpSCxRQUFULEVBQW1CO0FBQzdDc0csYUFBTyxDQUFDQyxHQUFSLENBQVksa0JBQWtCMkIsWUFBOUI7QUFDQWxJLGNBQVEsQ0FBQ2IsRUFBVCxDQUFZLE1BQVosRUFBb0IsVUFBUzhNLEtBQVQsRUFBZ0I7QUFDbEM7QUFDQSxZQUFJOU4sSUFBSSxHQUFHOE4sS0FBSyxDQUFDelIsTUFBakIsQ0FGa0MsQ0FHbEM7QUFDQTs7QUFDQTJOLGlCQUFTLElBQUloSyxJQUFiLENBTGtDLENBTWxDO0FBQ0E7O0FBQ0FpSyxxQkFBYSxHQUFHOEQsSUFBSSxDQUFDQyxLQUFMLENBQVdyRSxZQUFZLEdBQUdLLFNBQTFCLENBQWhCO0FBRUExVCxZQUFJLENBQUMyWCxLQUFMLENBQVdILEtBQVg7QUFDRCxPQVhEO0FBYUFqTSxjQUFRLENBQUNiLEVBQVQsQ0FBWSxPQUFaLEVBQXFCLFVBQVNZLEdBQVQsRUFBYztBQUNqQ2lJLHVCQUFlLENBQUN1QyxJQUFoQixDQUFxQnJDLFlBQXJCO0FBRUE1QixlQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBd0J4RyxHQUFwQztBQUNELE9BSkQ7QUFNQUMsY0FBUSxDQUFDYixFQUFULENBQVksS0FBWixFQUFtQixZQUFXO0FBQzVCOEksMkJBQW1CLENBQUNzQyxJQUFwQixDQUF5QnJDLFlBQXpCO0FBQ0FILHFCQUFhO0FBQ2JNLG9CQUFZLEdBQUcsS0FBZjtBQUVBL0IsZUFBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNELE9BTkQ7QUFPRCxLQTVCUyxDQUFWO0FBOEJBcUIsT0FBRyxDQUFDekksRUFBSixDQUFPLE9BQVAsRUFBZ0JtTSxDQUFDLElBQUk7QUFDbkJoRixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1QkFBdUIyQixZQUF2QixHQUFzQyxHQUF0QyxHQUE0Q29ELENBQUMsQ0FBQzlGLE9BQTFEO0FBQ0F3QyxxQkFBZSxDQUFDdUMsSUFBaEIsQ0FBcUJyQyxZQUFyQjtBQUNBSCxtQkFBYTtBQUNkLEtBSkQ7QUFNQUgsT0FBRyxDQUFDeUUsR0FBSixDQUFRLDBCQUFSO0FBQ0Q7QUFyRFksQ0FBZixFLENBd0RBOztBQUNBNVksTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYmlZLGdCQUFjLEVBQUUsVUFBU3JULElBQVQsRUFBZTtBQUM3QjlFLFNBQUssQ0FBQzhFLElBQUQsRUFBT3ZFLE1BQVAsQ0FBTDtBQUNBLFFBQUlzQixNQUFNLEdBQUcsS0FBYjs7QUFFQSxRQUFJO0FBQ0YsVUFBSUUsS0FBSyxHQUFHc0gsRUFBRSxDQUFDK08sVUFBSCxDQUFjdFQsSUFBZCxDQUFaO0FBQ0FqRCxZQUFNLEdBQUcsSUFBVDtBQUNELEtBSEQsQ0FHRSxPQUFPc1YsQ0FBUCxFQUFVO0FBQ1Y7QUFDQXRWLFlBQU0sR0FBRyxLQUFUO0FBQ0QsS0FORCxTQU1VO0FBQ1IsYUFBT0EsTUFBUDtBQUNEO0FBQ0Y7QUFkWSxDQUFmLEUsQ0FnQkE7O0FBQ0F3VyxNQUFNLENBQUNDLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLFVBQTNCLEVBQXVDLFVBQVM5RSxHQUFULEVBQWNuQixHQUFkLEVBQW1Ca0csSUFBbkIsRUFBeUI7QUFDOURsRyxLQUFHLENBQUNtRyxTQUFKLENBQWMsNkJBQWQsRUFBNkMsR0FBN0M7QUFDQW5HLEtBQUcsQ0FBQ29HLFNBQUosQ0FBYyxHQUFkO0FBQ0EsTUFBSXBZLElBQUksR0FBR21ULEdBQUcsQ0FBQ3pELEtBQUosQ0FBVTFQLElBQXJCO0FBQ0EsTUFBSXlWLFFBQVEsR0FBR3RDLEdBQUcsQ0FBQ3pELEtBQUosQ0FBVStGLFFBQXpCO0FBQ0EsTUFBSWtCLEtBQUssR0FBR3hELEdBQUcsQ0FBQ3pELEtBQUosQ0FBVWlILEtBQXRCOztBQUVBLE1BQUkzVyxJQUFJLElBQUlHLFNBQVIsSUFBcUJzVixRQUFRLElBQUl0VixTQUFyQyxFQUFnRDtBQUM5QzZSLE9BQUcsQ0FBQzRGLEdBQUosQ0FBUSxtQkFBUjtBQUNELEdBRkQsTUFFTyxJQUFJakIsS0FBSyxJQUFJeFcsU0FBYixFQUF3QjtBQUM3QndXLFNBQUssR0FBRyxLQUFSO0FBQ0Q7O0FBRUQ5RSxTQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCOVIsSUFBdEI7QUFDQSxNQUFJdVIsT0FBTyxHQUFHdlMsTUFBTSxDQUFDNFYsSUFBUCxDQUFZLGdCQUFaLEVBQThCNVUsSUFBOUIsRUFBb0N5VixRQUFwQyxFQUE4Q2tCLEtBQTlDLENBQWQ7QUFDQSxNQUFJL0csSUFBSSxHQUFHLEVBQVg7QUFDQSxNQUFJeUksUUFBUSxHQUFHLEVBQWY7O0FBQ0EsTUFBSXJZLElBQUksSUFBSSxVQUFaLEVBQXdCO0FBQ3RCO0FBQ0EsUUFBSXNZLFNBQVMsR0FBRyxFQUFoQjtBQUNBL0csV0FBTyxDQUFDdEgsT0FBUixDQUFnQixVQUFTOUssQ0FBVCxFQUFZO0FBQzFCLFVBQUlxRixJQUFJLEdBQUcrUCxVQUFVLEdBQUdwVixDQUFDLENBQUNhLElBQUYsQ0FBTyxNQUFQLENBQXhCO0FBQ0EsVUFBSXVCLE1BQU0sR0FBR3ZDLE1BQU0sQ0FBQzRWLElBQVAsQ0FBWSxnQkFBWixFQUE4QnBRLElBQTlCLENBQWIsQ0FGMEIsQ0FHMUI7O0FBQ0EsVUFBSWpELE1BQUosRUFBWTtBQUNWK1csaUJBQVMsQ0FBQ3hDLElBQVYsQ0FBZTNXLENBQWY7QUFDRDtBQUNGLEtBUEQ7QUFTQSxRQUFJeVEsSUFBSSxHQUFHbUcsSUFBSSxDQUFDQyxTQUFMLENBQWVzQyxTQUFmLENBQVg7QUFDQSxRQUFJRCxRQUFRLEdBQUdsRyxLQUFLLENBQUM2RCxTQUFOLENBQWdCcEcsSUFBaEIsQ0FBZjtBQUNELEdBZEQsTUFjTztBQUNMLFFBQUlBLElBQUksR0FBR21HLElBQUksQ0FBQ0MsU0FBTCxDQUFlekUsT0FBZixDQUFYO0FBQ0EsUUFBSThHLFFBQVEsR0FBR2xHLEtBQUssQ0FBQzZELFNBQU4sQ0FBZ0JwRyxJQUFoQixDQUFmO0FBQ0Q7O0FBRURvQyxLQUFHLENBQUM0RixHQUFKLENBQVFTLFFBQVI7QUFDRCxDQXJDRCxFLENBdUNBOztBQUVBekYsTUFBTSxDQUFDMkYsS0FBUCxDQUFhLFNBQWIsRUFBd0IsVUFBUy9DLE1BQVQsRUFBaUJyQyxHQUFqQixFQUFzQm5CLEdBQXRCLEVBQTJCa0csSUFBM0IsRUFBaUM7QUFDdkRsRyxLQUFHLENBQUNtRyxTQUFKLENBQWMsNkJBQWQsRUFBNkMsR0FBN0M7QUFDQW5HLEtBQUcsQ0FBQ29HLFNBQUosQ0FBYyxHQUFkO0FBQ0EsTUFBSWpKLFVBQVUsR0FBR2dFLEdBQUcsQ0FBQ3JDLElBQUosQ0FBUzNCLFVBQTFCO0FBQ0EsTUFBSXNHLFFBQVEsR0FBR3RDLEdBQUcsQ0FBQ3JDLElBQUosQ0FBUzJFLFFBQXhCLENBSnVELENBS3ZEOztBQUVBLE1BQUl0RyxVQUFVLElBQUloUCxTQUFsQixFQUE2QjtBQUMzQjBSLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVo7QUFDQUUsT0FBRyxDQUFDNEYsR0FBSixDQUFRLG1CQUFSO0FBQ0E7QUFDRDs7QUFDRCxNQUFJblcsS0FBSyxHQUFHMFEsS0FBSyxDQUFDcUcsS0FBTixDQUFZckosVUFBWixDQUFaOztBQUVBRCxhQUFXLENBQUMvTixNQUFaLENBQW1CO0FBQUVzVSxZQUFRLEVBQUVBO0FBQVosR0FBbkIsRUFkdUQsQ0FjWDs7O0FBRTVDaFUsT0FBSyxDQUFDd0ksT0FBTixDQUFjLFVBQVM5SyxDQUFULEVBQVlzWixDQUFaLEVBQWVDLEdBQWYsRUFBb0I7QUFDaEMxWixVQUFNLENBQUM0VixJQUFQLENBQVksYUFBWixFQUEyQnpWLENBQTNCLEVBQThCLElBQTlCLEVBQW9Dc1csUUFBcEM7QUFDRCxHQUZEO0FBSUE1RCxTQUFPLENBQUNDLEdBQVIsQ0FBWSwyQkFBMkJyUSxLQUFLLENBQUNzRSxNQUE3QztBQUVBaU0sS0FBRyxDQUFDNEYsR0FBSixDQUFRLDJCQUFSO0FBQ0QsQ0F2QkQsRSxDQXlCQTs7QUFDQWhGLE1BQU0sQ0FBQzJGLEtBQVAsQ0FBYSxTQUFiLEVBQXdCLFVBQVMvQyxNQUFULEVBQWlCckMsR0FBakIsRUFBc0JuQixHQUF0QixFQUEyQmtHLElBQTNCLEVBQWlDO0FBQ3ZEbEcsS0FBRyxDQUFDbUcsU0FBSixDQUFjLDZCQUFkLEVBQTZDLEdBQTdDO0FBQ0FuRyxLQUFHLENBQUNvRyxTQUFKLENBQWMsR0FBZDtBQUNBLE1BQUl2WCxLQUFLLEdBQUdzUyxHQUFHLENBQUNyQyxJQUFKLENBQVNqUSxLQUFyQjtBQUNBLE1BQUk0VSxRQUFRLEdBQUd0QyxHQUFHLENBQUNyQyxJQUFKLENBQVMyRSxRQUF4QixDQUp1RCxDQUt2RDtBQUVBOztBQUNBLE1BQUk1VSxLQUFLLEdBQUdrVixJQUFJLENBQUNDLFNBQUwsQ0FBZW5WLEtBQWYsQ0FBWixDQVJ1RCxDQVN2RDs7QUFDQSxNQUFJQSxLQUFLLElBQUlWLFNBQWIsRUFBd0I7QUFDdEI2UixPQUFHLENBQUM0RixHQUFKLENBQVEsbUJBQVI7QUFDQTtBQUNEOztBQUVEL1csT0FBSyxDQUFDb0osT0FBTixDQUFjLFVBQVM5SyxDQUFULEVBQVlzWixDQUFaLEVBQWVDLEdBQWYsRUFBb0I7QUFDaEMxWixVQUFNLENBQUM0VixJQUFQLENBQVksWUFBWixFQUEwQnpWLENBQTFCLEVBQTZCc1csUUFBN0I7QUFDRCxHQUZEO0FBSUE1RCxTQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBc0JqUixLQUFLLENBQUNrRixNQUF4QztBQUVBaU0sS0FBRyxDQUFDNEYsR0FBSixDQUFRLHlCQUFSO0FBQ0QsQ0F0QkQ7QUF3QkE1WSxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiK1ksVUFBUSxFQUFFLFVBQVMzWSxJQUFULEVBQWU7QUFDdkIsUUFBSXdFLElBQUksR0FBRytQLFVBQVUsR0FBR3ZVLElBQXhCO0FBQ0ErSSxNQUFFLENBQUM2UCxJQUFILENBQVFwVSxJQUFSLEVBQWMsR0FBZCxFQUFtQixDQUFDOEcsR0FBRCxFQUFNdU4sRUFBTixLQUFhO0FBQzlCO0FBQ0EsVUFBSXZOLEdBQUosRUFBUztBQUNQLFlBQUlBLEdBQUcsQ0FBQ2hHLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QnVNLGlCQUFPLENBQUNELEtBQVIsQ0FBYyx1QkFBZDtBQUNBO0FBQ0QsU0FIRCxNQUdPO0FBQ0wsZ0JBQU10RyxHQUFOO0FBQ0Q7QUFDRixPQVQ2QixDQVU5QjtBQUNBOztBQUNELEtBWkQsRUFGdUIsQ0FnQnZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQXRCWSxDQUFmLEUsQ0F5QkE7O0FBQ0F5TSxNQUFNLENBQUNDLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLFVBQTNCLEVBQXVDLFVBQVM5RSxHQUFULEVBQWNuQixHQUFkLEVBQW1Ca0csSUFBbkIsRUFBeUI7QUFDOURsRyxLQUFHLENBQUNtRyxTQUFKLENBQWMsNkJBQWQsRUFBNkMsR0FBN0M7QUFDQW5HLEtBQUcsQ0FBQ29HLFNBQUosQ0FBYyxHQUFkO0FBRUEsTUFBSVUsT0FBTyxHQUFHOVosTUFBTSxDQUFDNFYsSUFBUCxDQUFZLGtCQUFaLENBQWQ7QUFFQTVDLEtBQUcsQ0FBQzRGLEdBQUosQ0FBUWtCLE9BQVI7QUFDRCxDQVBELEUsQ0FTQTs7QUFDQWxHLE1BQU0sQ0FBQzJGLEtBQVAsQ0FBYSxZQUFiLEVBQTJCLFVBQVMvQyxNQUFULEVBQWlCckMsR0FBakIsRUFBc0JuQixHQUF0QixFQUEyQmtHLElBQTNCLEVBQWlDO0FBQzFEbEcsS0FBRyxDQUFDbUcsU0FBSixDQUFjLDZCQUFkLEVBQTZDLEdBQTdDO0FBQ0FuRyxLQUFHLENBQUNvRyxTQUFKLENBQWMsR0FBZCxFQUYwRCxDQUcxRDs7QUFDQSxNQUFJOVAsUUFBUSxHQUFHa04sTUFBTSxDQUFDOUYsS0FBUCxDQUFhMVAsSUFBNUI7QUFDQSxNQUFJd0UsSUFBSSxHQUFHZ1IsTUFBTSxDQUFDOUYsS0FBUCxDQUFhbEwsSUFBeEI7QUFDQSxNQUFJdVUsUUFBUSxHQUFHLElBQWYsQ0FOMEQsQ0FNckM7O0FBQ3JCbEgsU0FBTyxDQUFDQyxHQUFSLENBQVl4SixRQUFaOztBQUVBLE1BQUlBLFFBQVEsSUFBSW5JLFNBQVosSUFBeUJxRSxJQUFJLElBQUlyRSxTQUFyQyxFQUFnRDtBQUM5QzZSLE9BQUcsQ0FBQzRGLEdBQUosQ0FBUSxtQkFBUjtBQUNBO0FBQ0QsR0FIRCxNQUdPLElBQUlwVCxJQUFJLElBQUksUUFBWixFQUFzQjtBQUMzQnVVLFlBQVEsR0FBR3ZFLFVBQVUsR0FBR2xNLFFBQXhCO0FBQ0QsR0FGTSxNQUVBLElBQUk5RCxJQUFJLElBQUksUUFBWixFQUFzQjtBQUMzQnVVLFlBQVEsR0FBR3hFLFVBQVUsR0FBR2pNLFFBQXhCO0FBQ0QsR0FGTSxNQUVBO0FBQ0x5USxZQUFRLEdBQUd0RSxVQUFVLEdBQUduTSxRQUF4QjtBQUNEOztBQUVEUyxJQUFFLENBQUNrTyxJQUFILENBQVE4QixRQUFSLEVBQWtCLFVBQVN6TixHQUFULEVBQWM3SixLQUFkLEVBQXFCO0FBQ3JDLFFBQUlBLEtBQUosRUFBVztBQUNUdVEsU0FBRyxDQUFDNEYsR0FBSixDQUFRLEtBQUtuVyxLQUFLLENBQUNpSSxJQUFuQjtBQUNBO0FBQ0QsS0FIRCxNQUdPO0FBQ0xzSSxTQUFHLENBQUM0RixHQUFKLENBQVEsS0FBSyxDQUFDLENBQWQ7QUFDQTtBQUNEO0FBQ0YsR0FSRDtBQVNELENBN0JEO0FBK0JBNVksTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYm9aLFlBQVUsRUFBRSxVQUFTQyxRQUFULEVBQW1CSCxPQUFuQixFQUE0QjtBQUN0QztBQUNBLFVBQU1JLEtBQUssR0FBR3hHLElBQUksQ0FDaEIsd0JBRGdCLEVBRWhCO0FBQ0VyUixVQUFJLEVBQUU7QUFEUixLQUZnQixFQUtoQixDQUFDdVEsS0FBRCxFQUFRTSxNQUFSLEVBQWdCaUgsTUFBaEIsS0FBMkI7QUFDekIsVUFBSXZILEtBQUosRUFBVztBQUNUQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCRixLQUFyQjtBQUNBLGNBQU1BLEtBQU47QUFDRCxPQUhELE1BR08sSUFBSU0sTUFBSixFQUFZO0FBQ2pCTCxlQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWjtBQUNBVyxhQUFLLENBQUMsWUFBVztBQUNmO0FBQ0EsY0FBSTJHLFFBQVEsR0FBR0MsVUFBVSxDQUFDUCxPQUFELENBQXpCO0FBQ0EsY0FBSVEsVUFBVSxHQUFHLENBQUNGLFFBQVEsR0FBRyxHQUFaLEVBQWlCRyxPQUFqQixDQUF5QixDQUF6QixDQUFqQjtBQUNBLGNBQUloWSxNQUFNLEdBQUd2QyxNQUFNLENBQUM0VixJQUFQLENBQVksa0JBQVosRUFBZ0MwRSxVQUFoQyxDQUFiO0FBQ0F6SCxpQkFBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBb0N3SCxVQUFwQyxFQUFnRC9YLE1BQWhEO0FBQ0QsU0FOSSxDQUFMLENBTUc0VixHQU5IO0FBT0Q7QUFDRixLQW5CZSxDQUFsQjtBQXFCRDtBQXhCWSxDQUFmO0FBMkJBblksTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYjRaLGtCQUFnQixFQUFFLFVBQVNWLE9BQVQsRUFBa0I7QUFDbENXLGNBQVUsR0FBR2xOLFNBQVMsQ0FBQ3hKLE9BQVYsQ0FBa0I7QUFBRWlTLFdBQUssRUFBRTtBQUFULEtBQWxCLENBQWI7QUFDQW5ELFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaLEVBQStCMkgsVUFBL0IsRUFBMkNYLE9BQTNDOztBQUNBLFFBQUlBLE9BQU8sR0FBR1csVUFBVSxDQUFDeEUsR0FBekIsRUFBOEI7QUFDNUIxSSxlQUFTLENBQUNyTCxNQUFWLENBQ0U7QUFDRThULGFBQUssRUFBRTtBQURULE9BREYsRUFJRTtBQUNFNVIsWUFBSSxFQUFFO0FBQ0o2UixhQUFHLEVBQUU2RDtBQUREO0FBRFIsT0FKRjs7QUFVQSxhQUFPLElBQVA7QUFDRCxLQVpELE1BWU87QUFDSixRQUFEO0FBQ0EsYUFBTyxLQUFQO0FBQ0Q7QUFDRjtBQXBCWSxDQUFmLEUsQ0F1QkE7O0FBQ0E5WixNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiOFoscUJBQW1CLEVBQUUsVUFBU1osT0FBVCxFQUFrQjtBQUNyQ3ZNLGFBQVMsQ0FBQ3BMLE1BQVYsQ0FBaUIsRUFBakI7QUFDRDtBQUhZLENBQWYsRTs7Ozs7Ozs7Ozs7QUN4c0JBLElBQUluQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJNlEsT0FBSjs7QUFBWS9RLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQzhRLFNBQU8sQ0FBQzdRLENBQUQsRUFBRztBQUFDNlEsV0FBTyxHQUFDN1EsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJNkUsY0FBSjtBQUFtQi9FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUM4RSxnQkFBYyxDQUFDN0UsQ0FBRCxFQUFHO0FBQUM2RSxrQkFBYyxHQUFDN0UsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFJbEpILE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLFFBQWYsRUFBeUIsTUFBTTtBQUM3QixNQUFJLENBQUMyRSxjQUFjLEVBQW5CLEVBQXVCO0FBQ3JCLFNBQUtwRCxLQUFMO0FBQ0Q7O0FBQ0QsU0FBT29QLE9BQU8sQ0FBQzFRLElBQVIsQ0FBYSxFQUFiLENBQVA7QUFDRCxDQUxELEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSU4sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUFrRCxJQUFJNlEsT0FBSjs7QUFBWS9RLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUM4USxTQUFPLENBQUM3USxDQUFELEVBQUc7QUFBQzZRLFdBQU8sR0FBQzdRLENBQVI7QUFBVTs7QUFBdEIsQ0FBL0IsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSThJLFNBQUo7QUFBY2hKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrSSxXQUFTLENBQUM5SSxDQUFELEVBQUc7QUFBQzhJLGFBQVMsR0FBQzlJLENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFLaE5ILE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I7QUFDQSxpQkFBZUUsRUFBZixFQUFtQjhHLE1BQW5CLEVBQTJCdkYsSUFBM0IsRUFBaUMyUyxJQUFqQyxFQUF1QztBQUNyQ3RVLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDa0gsTUFBRCxFQUFTM0csTUFBVCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ3NVLElBQUQsRUFBTy9ULE1BQVAsQ0FBTDtBQUNBUCxTQUFLLENBQUMyQixJQUFELEVBQU9wQixNQUFQLENBQUwsQ0FKcUMsQ0FLckM7O0FBQ0EsUUFBSVMsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLGlCQUFWLENBQWhDLENBQUosRUFBbUU7QUFDakV1UCxhQUFPLENBQUMzUCxNQUFSLENBQWU7QUFDYjJDLFdBQUcsRUFBRWxELEVBRFE7QUFFYjhHLGNBRmE7QUFHYnZGLFlBSGE7QUFJYjJTLFlBSmE7QUFLYnBELGlCQUFTLEVBQUUsRUFMRTtBQU1iclEsWUFBSSxFQUFFLEVBTk87QUFPYjRCLGlCQUFTLEVBQUUsSUFBSUMsSUFBSixFQVBFO0FBUWJtRCxpQkFBUyxFQUFFLEtBQUs5RTtBQVJILE9BQWY7QUFVRCxLQVhELE1BV087QUFDTCxZQUFNLElBQUl6QixNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLHlDQUF6QixDQUFOO0FBQ0Q7QUFDRixHQXRCWTs7QUF1QmI7QUFDQSxpQkFBZXZELEVBQWYsRUFBbUJtVSxLQUFuQixFQUEwQjtBQUN4QnZVLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDdVUsS0FBRCxFQUFRaFUsTUFBUixDQUFMOztBQUNBLFFBQUlTLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFdVAsYUFBTyxDQUFDOU8sTUFBUixDQUNFO0FBQ0U4QixXQUFHLEVBQUVsRDtBQURQLE9BREYsRUFJRTtBQUNFc0QsWUFBSSxFQUFFO0FBQ0ovQixjQUFJLEVBQUU0UztBQURGO0FBRFIsT0FKRjtBQVVELEtBWEQsTUFXTztBQUNMLFlBQU0sSUFBSWpWLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGLEdBekNZOztBQTBDYjtBQUNBLGlCQUFldkQsRUFBZixFQUFtQjtBQUNqQkosU0FBSyxDQUFDSSxFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBLFVBQU0yUSxTQUFTLEdBQUczSSxTQUFTLENBQUMzSSxJQUFWLENBQWU7QUFBRSxzQkFBZ0JRO0FBQWxCLEtBQWYsRUFBdUNnRyxLQUF2QyxFQUFsQjs7QUFDQSxRQUFJcEYsS0FBSyxDQUFDQyxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxLQUE4QyxDQUFDbVEsU0FBUyxDQUFDN0ssTUFBN0QsRUFBcUU7QUFDbkVpSyxhQUFPLENBQUM3TyxNQUFSLENBQWVyQixFQUFmO0FBQ0QsS0FGRCxNQUVPLElBQUk4USxTQUFTLENBQUM3SyxNQUFkLEVBQXNCO0FBQzNCLFlBQU0sSUFBSS9HLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FDSixPQURJLEVBRUosb0RBRkksQ0FBTjtBQUlELEtBTE0sTUFLQTtBQUNMLFlBQU0sSUFBSXJFLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGLEdBeERZOztBQXlEYjtBQUNBLHdCQUFzQixVQUFTTCxHQUFULEVBQWM0RCxNQUFkLEVBQXNCdkYsSUFBdEIsRUFBNEIyUyxJQUE1QixFQUFrQztBQUN0RHRVLFNBQUssQ0FBQ3NELEdBQUQsRUFBTS9DLE1BQU4sQ0FBTDtBQUNBUCxTQUFLLENBQUNrSCxNQUFELEVBQVMzRyxNQUFULENBQUw7QUFDQVAsU0FBSyxDQUFDMkIsSUFBRCxFQUFPcEIsTUFBUCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ3NVLElBQUQsRUFBTy9ULE1BQVAsQ0FBTDs7QUFDQSxRQUFJUyxLQUFLLENBQUNDLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELEVBQVUsaUJBQVYsQ0FBaEMsQ0FBSixFQUFtRTtBQUNqRXVQLGFBQU8sQ0FBQzNQLE1BQVIsQ0FBZTtBQUNiMkMsV0FEYTtBQUViNEQsY0FGYTtBQUdidkYsWUFIYTtBQUliMlMsWUFKYTtBQUticEQsaUJBQVMsRUFBRSxFQUxFO0FBTWJyUSxZQUFJLEVBQUUsRUFOTztBQU9iNEIsaUJBQVMsRUFBRSxJQUFJQyxJQUFKLEVBUEU7QUFRYm1ELGlCQUFTLEVBQUUsS0FBSzlFO0FBUkgsT0FBZjtBQVVELEtBWEQsTUFXTztBQUNMLFlBQU0sSUFBSXpCLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGO0FBN0VZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQXBFLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUN5USxTQUFPLEVBQUMsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUl4USxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0QixZQUFKO0FBQWlCOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0QixnQkFBWSxHQUFDNUIsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDs7QUFHM0csTUFBTTZRLE9BQU8sR0FBRyxJQUFJeFEsS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLENBQWhCOztBQUVQdVEsT0FBTyxDQUFDL08sSUFBUixDQUFhO0FBQ1haLFFBQU0sRUFBRSxNQUFNLElBREg7QUFFWGEsUUFBTSxFQUFFLE1BQU0sSUFGSDtBQUdYQyxRQUFNLEVBQUUsTUFBTTtBQUhILENBQWI7O0FBTUEsTUFBTXdZLFdBQVcsR0FBRyxJQUFJNVksWUFBSixDQUFpQjtBQUNuQzZGLFFBQU0sRUFBRTNHLE1BRDJCO0FBRW5Db0IsTUFBSSxFQUFFcEIsTUFGNkI7QUFHbkMrVCxNQUFJLEVBQUUvVCxNQUg2QjtBQUluQzJRLFdBQVMsRUFBRWhQLEtBSndCO0FBS25DLGlCQUFleEIsTUFMb0I7QUFNbkNHLE1BQUksRUFBRUgsTUFONkI7QUFPbkMrQixXQUFTLEVBQUVDLElBUHdCO0FBUW5DbUQsV0FBUyxFQUFFdEY7QUFSd0IsQ0FBakIsQ0FBcEI7O0FBV0ErUCxPQUFPLENBQUN4TixZQUFSLENBQXFCbVgsV0FBckIsRTs7Ozs7Ozs7Ozs7QUN0QkEsSUFBSTNhLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlxRyxNQUFKOztBQUFXdkcsTUFBTSxDQUFDQyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDc0csUUFBTSxDQUFDckcsQ0FBRCxFQUFHO0FBQUNxRyxVQUFNLEdBQUNyRyxDQUFQO0FBQVM7O0FBQXBCLENBQXZCLEVBQTZDLENBQTdDO0FBQWdELElBQUk2RSxjQUFKO0FBQW1CL0UsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQzhFLGdCQUFjLENBQUM3RSxDQUFELEVBQUc7QUFBQzZFLGtCQUFjLEdBQUM3RSxDQUFmO0FBQWlCOztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUk5STtBQUNBSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFNBQVN1YSxRQUFULENBQWtCQyxHQUFsQixFQUF1QjtBQUNuRG5hLE9BQUssQ0FBQ21hLEdBQUQsRUFBTWxhLEtBQUssQ0FBQ08sS0FBTixDQUFZRCxNQUFaLEVBQW9CLElBQXBCLENBQU4sQ0FBTDs7QUFDQSxNQUFJLENBQUMrRCxjQUFjLEVBQW5CLEVBQXVCO0FBQ3JCLFNBQUtwRCxLQUFMO0FBQ0Q7O0FBQ0QsU0FBTzRFLE1BQU0sQ0FBQ2xHLElBQVAsQ0FBWTtBQUFFLHdCQUFvQnVhLEdBQXRCO0FBQTJCdFUsYUFBUyxFQUFFLEtBQUs5RTtBQUEzQyxHQUFaLENBQVA7QUFDRCxDQU5EO0FBUUF6QixNQUFNLENBQUNLLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLFNBQVN5YSxXQUFULEdBQXVCO0FBQzdDLE1BQUksQ0FBQzlWLGNBQWMsRUFBbkIsRUFBdUI7QUFDckIsU0FBS3BELEtBQUw7QUFDRDs7QUFDRCxTQUFPNEUsTUFBTSxDQUFDbEcsSUFBUCxDQUFZLEVBQVosRUFBZ0I7QUFBRXlhLFNBQUssRUFBRTtBQUFFMVksVUFBSSxFQUFFLENBQVI7QUFBVzJZLFlBQU0sRUFBRSxDQUFuQjtBQUFzQi9VLGFBQU8sRUFBRTtBQUEvQjtBQUFULEdBQWhCLENBQVA7QUFDRCxDQUxELEUsQ0FPQTs7QUFFQWpHLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFNBQVM0YSxVQUFULENBQW9CbmEsRUFBcEIsRUFBd0I7QUFDM0RKLE9BQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7O0FBQ0EsTUFBSStELGNBQWMsRUFBbEIsRUFBc0I7QUFDcEIsU0FBS3BELEtBQUw7QUFDRDs7QUFDRCxTQUFPNEUsTUFBTSxDQUFDbEcsSUFBUCxDQUFZO0FBQUUwRCxPQUFHLEVBQUVsRDtBQUFQLEdBQVosRUFBeUI7QUFBRW9hLFVBQU0sRUFBRTtBQUFFN1ksVUFBSSxFQUFFO0FBQVI7QUFBVixHQUF6QixDQUFQO0FBQ0QsQ0FORCxFOzs7Ozs7Ozs7OztBQ3RCQSxJQUFJckMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUFrRCxJQUFJcUcsTUFBSjs7QUFBV3ZHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQ3NHLFFBQU0sQ0FBQ3JHLENBQUQsRUFBRztBQUFDcUcsVUFBTSxHQUFDckcsQ0FBUDtBQUFTOztBQUFwQixDQUF0QixFQUE0QyxDQUE1Qzs7QUFBK0MsSUFBSTZRLE9BQUo7O0FBQVkvUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDOFEsU0FBTyxDQUFDN1EsQ0FBRCxFQUFHO0FBQUM2USxXQUFPLEdBQUM3USxDQUFSO0FBQVU7O0FBQXRCLENBQS9CLEVBQXVELENBQXZEO0FBTWxNSCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiLGdCQUFjRSxFQUFkLEVBQWtCdUIsSUFBbEIsRUFBd0IyWSxNQUF4QixFQUFnQ0csUUFBaEMsRUFBMENsVixPQUExQyxFQUFtRDtBQUNqRHZGLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDMkIsSUFBRCxFQUFPcEIsTUFBUCxDQUFMO0FBQ0FQLFNBQUssQ0FBQ3NhLE1BQUQsRUFBU3JhLEtBQUssQ0FBQ08sS0FBTixDQUFZc0IsTUFBWixFQUFvQixJQUFwQixFQUEwQnJCLFNBQTFCLENBQVQsQ0FBTDtBQUNBVCxTQUFLLENBQUN5YSxRQUFELEVBQVdsYSxNQUFYLENBQUw7QUFDQVAsU0FBSyxDQUFDdUYsT0FBRCxFQUFVN0UsTUFBVixDQUFMOztBQUNBLFFBQUlNLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxDQUFKLEVBQW1FO0FBQ2pFK0UsWUFBTSxDQUFDbkYsTUFBUCxDQUFjO0FBQ1oyQyxXQUFHLEVBQUVsRCxFQURPO0FBRVp1QixZQUZZO0FBR1oyWSxjQUhZO0FBSVpHLGdCQUpZO0FBS1psVixlQUxZO0FBTVoxRSxZQUFJLEVBQUUsRUFOTTtBQU9aNEIsaUJBQVMsRUFBRSxJQUFJQyxJQUFKLEVBUEM7QUFRWm1ELGlCQUFTLEVBQUUsS0FBSzlFO0FBUkosT0FBZCxFQURpRSxDQVdqRTs7QUFDRCxLQVpELE1BWU87QUFDTCxZQUFNLElBQUl6QixNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLHlDQUF6QixDQUFOO0FBQ0Q7QUFDRixHQXRCWTs7QUF3QmIsZ0JBQWN2RCxFQUFkLEVBQWtCdUIsSUFBbEIsRUFBd0IrWSxJQUF4QixFQUE4QjtBQUM1QjFhLFNBQUssQ0FBQ0ksRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQVAsU0FBSyxDQUFDMkIsSUFBRCxFQUFPcEIsTUFBUCxDQUFMO0FBQ0FQLFNBQUssQ0FBQzBhLElBQUQsRUFBT25hLE1BQVAsQ0FBTDs7QUFDQSxRQUFJUyxLQUFLLENBQUNDLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELEVBQVUsaUJBQVYsQ0FBaEMsQ0FBSixFQUFtRTtBQUNqRStFLFlBQU0sQ0FBQ3RFLE1BQVAsQ0FBYztBQUFFOEIsV0FBRyxFQUFFbEQ7QUFBUCxPQUFkLEVBQTJCO0FBQUVzRCxZQUFJLEVBQUU7QUFBRS9CLGNBQUY7QUFBUThZLGtCQUFRLEVBQUVDO0FBQWxCO0FBQVIsT0FBM0I7QUFDRCxLQUZELE1BRU87QUFDTCxZQUFNLElBQUlwYixNQUFNLENBQUNxRSxLQUFYLENBQWlCLE1BQWpCLEVBQXlCLHlDQUF6QixDQUFOO0FBQ0Q7QUFDRixHQWpDWTs7QUFrQ2IsZ0JBQWN2RCxFQUFkLEVBQWtCO0FBQ2hCSixTQUFLLENBQUNJLEVBQUQsRUFBS0csTUFBTCxDQUFMOztBQUNBLFVBQU0rWixNQUFNLEdBQUdoSyxPQUFPLENBQUMxUSxJQUFSLENBQWE7QUFBRXNILFlBQU0sRUFBRTlHO0FBQVYsS0FBYixFQUE2QmdHLEtBQTdCLEVBQWY7O0FBQ0EsUUFBSXBGLEtBQUssQ0FBQ0MsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUFnQyxDQUFDLE9BQUQsRUFBVSxpQkFBVixDQUFoQyxLQUFpRSxDQUFDdVosTUFBTSxDQUFDalUsTUFBN0UsRUFBcUY7QUFDbkZQLFlBQU0sQ0FBQ3JFLE1BQVAsQ0FBY3JCLEVBQWQ7QUFDRCxLQUZELE1BRU8sSUFBSWthLE1BQU0sQ0FBQ2pVLE1BQVAsSUFBaUIsQ0FBckIsRUFBd0I7QUFDN0IsWUFBTSxJQUFJL0csTUFBTSxDQUFDcUUsS0FBWCxDQUFpQixPQUFqQixFQUEwQix1REFBMUIsQ0FBTjtBQUNELEtBRk0sTUFFQTtBQUNMLFlBQU0sSUFBSXJFLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FBaUIsTUFBakIsRUFBeUIseUNBQXpCLENBQU47QUFDRDtBQUNGOztBQTVDWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkFwRSxNQUFNLENBQUNNLE1BQVAsQ0FBYztBQUFDaUcsUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJaEcsS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLE9BQUssQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNEIsWUFBSjtBQUFpQjlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzhCLFNBQU8sQ0FBQzdCLENBQUQsRUFBRztBQUFDNEIsZ0JBQVksR0FBQzVCLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7O0FBR3pHLE1BQU1xRyxNQUFNLEdBQUcsSUFBSWhHLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixNQUFyQixFQUE2QjtBQUFFeUUsY0FBWSxFQUFFO0FBQWhCLENBQTdCLENBQWY7O0FBRVBzQixNQUFNLENBQUN2RSxJQUFQLENBQVk7QUFDVlosUUFBTSxFQUFFLE1BQU0sSUFESjtBQUVWYSxRQUFNLEVBQUUsTUFBTSxJQUZKO0FBR1ZDLFFBQU0sRUFBRSxNQUFNO0FBSEosQ0FBWjs7QUFNQSxNQUFNNkQsTUFBTSxHQUFHLEVBQWY7QUFFQUEsTUFBTSxDQUFDcVYsT0FBUCxHQUFpQixJQUFJdFosWUFBSixDQUFpQjtBQUNoQ29MLFVBQVEsRUFBRWxNLE1BRHNCO0FBRWhDa0YsV0FBUyxFQUFFO0FBQ1R0RCxRQUFJLEVBQUU1QixNQURHO0FBRVRxQyxZQUFRLEVBQUU7QUFGRCxHQUZxQjtBQU1oQzhDLFVBQVEsRUFBRW5GO0FBTnNCLENBQWpCLENBQWpCO0FBU0ErRSxNQUFNLENBQUNzVixVQUFQLEdBQW9CLElBQUl2WixZQUFKLENBQWlCO0FBQ25DTSxNQUFJLEVBQUVwQixNQUQ2QjtBQUVuQytaLFFBQU0sRUFBRTtBQUNOblksUUFBSSxFQUFFTCxNQURBO0FBRU5jLFlBQVEsRUFBRTtBQUZKLEdBRjJCO0FBTW5DNlgsVUFBUSxFQUFFbGEsTUFOeUI7QUFPbkNnRixTQUFPLEVBQUVELE1BQU0sQ0FBQ3FWLE9BUG1CO0FBUW5DbFksV0FBUyxFQUFFQyxJQVJ3QjtBQVNuQ21ELFdBQVMsRUFBRXRGLE1BVHdCO0FBVW5DTSxNQUFJLEVBQUVILE1BVjZCLENBVXJCOztBQVZxQixDQUFqQixDQUFwQjs7QUFhQW9GLE1BQU0sQ0FBQ2hELFlBQVAsQ0FBb0J3QyxNQUFNLENBQUNzVixVQUEzQixFOzs7Ozs7Ozs7OztBQ25DQSxJQUFJdGIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0SixFQUFKO0FBQU85SixNQUFNLENBQUNDLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRKLE1BQUUsR0FBQzVKLENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7QUFJbklILE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2IyYSxRQUFNLEVBQUUsQ0FBQ0MsSUFBRCxFQUFPM1ksSUFBUCxLQUFnQjtBQUN0Qm5DLFNBQUssQ0FBQzhhLElBQUQsRUFBT3ZhLE1BQVAsQ0FBTDtBQUNBUCxTQUFLLENBQUNtQyxJQUFELEVBQU81QixNQUFQLENBQUw7QUFDQSxVQUFNdUUsSUFBSSxHQUFJLEdBQUVrSSxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsR0FBSSxJQUFHL0ssSUFBSyxNQUF4QztBQUNBa0gsTUFBRSxDQUFDMFIsVUFBSCxDQUFjalcsSUFBZCxFQUFvQmdXLElBQXBCLEVBQTJCbFAsR0FBRCxJQUFTO0FBQ2pDLFVBQUlBLEdBQUosRUFBUyxNQUFNQSxHQUFOLENBRHdCLENBRWpDOztBQUNBdUcsYUFBTyxDQUFDRCxLQUFSLENBQWMsa0NBQWQ7QUFDRCxLQUpEO0FBS0Q7QUFWWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEzUyxNQUFNLENBQUNNLE1BQVAsQ0FBYztBQUFDbWIsTUFBSSxFQUFDLE1BQUlBLElBQVY7QUFBZTFXLGdCQUFjLEVBQUMsTUFBSUE7QUFBbEMsQ0FBZDtBQUFpRSxJQUFJaEYsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJSyxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl3YixNQUFKO0FBQVcxYixNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDd2IsVUFBTSxHQUFDeGIsQ0FBUDtBQUFTOztBQUFqQixDQUFuQyxFQUFzRCxDQUF0RDtBQUlqTSxNQUFNdWIsSUFBSSxHQUFHLElBQUlsYixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsUUFBckIsRUFBK0I7QUFBRXlFLGNBQVksRUFBRTtBQUFoQixDQUEvQixDQUFiO0FBRVAsTUFBTTtBQUFFMFc7QUFBRixJQUFpQkQsTUFBdkI7O0FBRU8sU0FBUzNXLGNBQVQsR0FBMEI7QUFDL0IsU0FBTzRXLFVBQVUsR0FBRyxDQUFDLENBQUM1YixNQUFNLENBQUMwRCxJQUFQLEVBQUwsR0FBcUIsSUFBdEM7QUFDRCxDOzs7Ozs7Ozs7OztBQ1ZEekQsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ3NiLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSXJiLEtBQUo7QUFBVVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxPQUFLLENBQUNMLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTRCLFlBQUo7QUFBaUI5QixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRCLGdCQUFZLEdBQUM1QixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBRzdHLE1BQU0wYixRQUFRLEdBQUcsSUFBSXJiLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixDQUFqQjtBQUVQLE1BQU11RixNQUFNLEdBQUcsRUFBZjtBQUVBQSxNQUFNLENBQUNJLFFBQVAsR0FBa0IsSUFBSXJFLFlBQUosQ0FBaUI7QUFDakNxRSxVQUFRLEVBQUVuRjtBQUR1QixDQUFqQixDQUFsQjtBQUlBNGEsUUFBUSxDQUFDclksWUFBVCxDQUFzQndDLE1BQU0sQ0FBQ0ksUUFBN0IsRSxDQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE07Ozs7Ozs7Ozs7O0FDbkJBLElBQUkwVixlQUFKO0FBQW9CN2IsTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQzRiLGlCQUFlLENBQUMzYixDQUFELEVBQUc7QUFBQzJiLG1CQUFlLEdBQUMzYixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBMUMsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSTRiLElBQUo7QUFBUzliLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRiLFFBQUksR0FBQzViLENBQUw7QUFBTzs7QUFBbkIsQ0FBbkMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTBiLFFBQUo7QUFBYTViLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQzJiLFVBQVEsQ0FBQzFiLENBQUQsRUFBRztBQUFDMGIsWUFBUSxHQUFDMWIsQ0FBVDtBQUFXOztBQUF4QixDQUF6QixFQUFtRCxDQUFuRDtBQUkxTDtBQUNBO0FBQ0E7QUFDQSxNQUFNNmIsWUFBWSxHQUFHLElBQUlGLGVBQUosQ0FBb0I7QUFDdkN6WixNQUFJLEVBQUUsa0JBRGlDO0FBRXZDNFosVUFBUSxFQUFFLElBRjZCOztBQUd2QzlELEtBQUcsR0FBRztBQUNKLFdBQU80RCxJQUFJLENBQUNDLFlBQUwsRUFBUDtBQUNEOztBQUxzQyxDQUFwQixDQUFyQixDLENBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUFoYyxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNic2IsZ0JBQWMsQ0FBQzlWLFFBQUQsRUFBVztBQUN2QjFGLFNBQUssQ0FBQzBGLFFBQUQsRUFBV25GLE1BQVgsQ0FBTDtBQUNBLFdBQU80YSxRQUFRLENBQUMzWixNQUFULENBQWdCO0FBQUU4QixTQUFHLEVBQUU7QUFBUCxLQUFoQixFQUFzQztBQUFFSSxVQUFJLEVBQUU7QUFBRWdDO0FBQUY7QUFBUixLQUF0QyxFQUE4RDtBQUFFVCxZQUFNLEVBQUU7QUFBVixLQUE5RCxDQUFQO0FBQ0Q7O0FBSlksQ0FBZjtBQXZCQTFGLE1BQU0sQ0FBQ2tjLGFBQVAsQ0E4QmVILFlBOUJmLEU7Ozs7Ozs7Ozs7O0FDQUE7QUFDQUksVUFBVSxDQUFDQyxHQUFYLENBQWU7QUFDYmhhLE1BQUksRUFBRSxpREFETztBQUViaWEsVUFBUSxFQUFFQyxNQUFNLElBQUlBLE1BQU0sQ0FBQ2YsSUFBUCxDQUFZLGdCQUFaLENBRlA7QUFHYmdCLEtBQUcsRUFBRSxNQUFNO0FBQ1R4YyxVQUFNLENBQUM0VixJQUFQLENBQVksbUJBQVo7QUFDRDtBQUxZLENBQWYsRSxDQU9BOztBQUNBd0csVUFBVSxDQUFDSyxLQUFYLEc7Ozs7Ozs7Ozs7O0FDVEEsSUFBSXpjLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlvTixTQUFKOztBQUFjdE4sTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ3FOLFdBQVMsQ0FBQ3BOLENBQUQsRUFBRztBQUFDb04sYUFBUyxHQUFDcE4sQ0FBVjtBQUFZOztBQUExQixDQUExQyxFQUFzRSxDQUF0RTs7QUFHOUU7OztBQUlBO0FBQ0FILE1BQU0sQ0FBQ3FULE9BQVAsQ0FBZSxNQUFNO0FBQ25CO0FBQ0EsTUFBSSxDQUFDOUYsU0FBUyxDQUFDak4sSUFBVixHQUFpQjRELEtBQWpCLEVBQUwsRUFBK0I7QUFDN0JxSixhQUFTLENBQUNsTSxNQUFWLENBQWlCO0FBQ2ZrTyxVQUFJLEVBQUUsU0FEUztBQUVmbU4sY0FBUSxFQUFFO0FBRkssS0FBakI7QUFJRDtBQUNGLENBUkQsRTs7Ozs7Ozs7Ozs7QUNSQXpjLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDJDQUFaO0FBQXlERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWjtBQUEwQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVo7QUFBMENELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaO0FBQXFERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwyQkFBWjtBQUF5Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVkscUNBQVo7QUFBbURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlCQUFaO0FBQXVDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWjtBQUFvREQsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVo7QUFBd0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWjtBQUEyQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaO0FBQTBDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaO0FBQXNCRCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWjtBQUEyQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZDQUFaO0FBQTJERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWjtBQUErQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVo7QUFBcURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWjtBQUEwQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVo7QUFBb0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaO0FBQXdDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksaUNBQVo7QUFBK0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaO0FBQXNDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWjtBQUF1Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVo7QUFBeUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaO0FBQXFERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksNENBQVo7QUFBMERELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlCQUFaO0FBQXVDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWjtBQUEwQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVo7QUFBK0JELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaO0FBQTJDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFOzs7Ozs7Ozs7OztBQ0Eza0QsSUFBSUYsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNEosRUFBSjtBQUFPOUosTUFBTSxDQUFDQyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDOEIsU0FBTyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM0SixNQUFFLEdBQUM1SixDQUFIO0FBQUs7O0FBQWpCLENBQXZCLEVBQTBDLENBQTFDO0FBQTZDLElBQUlnUyxNQUFKO0FBQVdsUyxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDZ1MsVUFBTSxHQUFDaFMsQ0FBUDtBQUFTOztBQUFqQixDQUE3QixFQUFnRCxDQUFoRDtBQU0vSCxNQUFNcUYsSUFBSSxHQUFJLEdBQUVrSSxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsR0FBSSxjQUFoQztBQUVBNU4sTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYitiLFdBQVMsRUFBRSxDQUFDdGEsSUFBRCxFQUFPc04sR0FBUCxFQUFZaU4sSUFBWixFQUFrQkMsWUFBbEIsRUFBZ0NqTixNQUFoQyxLQUEyQztBQUNwRGxQLFNBQUssQ0FBQzJCLElBQUQsRUFBT3BCLE1BQVAsQ0FBTDtBQUNBUCxTQUFLLENBQUNpUCxHQUFELEVBQU0xTyxNQUFOLENBQUw7QUFDQVAsU0FBSyxDQUFDa2MsSUFBRCxFQUFPM1osT0FBUCxDQUFMO0FBQ0F2QyxTQUFLLENBQUNrUCxNQUFELEVBQVMzTyxNQUFULENBQUw7QUFDQVAsU0FBSyxDQUFDbWMsWUFBRCxFQUFlbGMsS0FBSyxDQUFDTyxLQUFOLENBQVkrQixPQUFaLEVBQXFCLElBQXJCLENBQWYsQ0FBTCxDQUxvRCxDQU1wRDs7QUFFQSxVQUFNOE0sS0FBSyxHQUFHb0MsTUFBTSxDQUFDdEMsWUFBckI7QUFDQSxRQUFJaU4sU0FBSjs7QUFDQSxRQUFJL00sS0FBSixFQUFXO0FBQ1QrTSxlQUFTLEdBQUc7QUFDVnphLFlBRFU7QUFFVnNOLFdBRlU7QUFHVmlNLGtCQUFVLEVBQUVnQixJQUhGO0FBSVZDLG9CQUFZLEVBQUUxSyxNQUFNLENBQUMwSyxZQUpYO0FBS1ZoTixvQkFBWSxFQUFFLElBTEo7QUFNVkQ7QUFOVSxPQUFaO0FBUUQsS0FURCxNQVNPO0FBQ0xrTixlQUFTLEdBQUc7QUFDVnphLFlBRFU7QUFFVnNOLFdBRlU7QUFHVmlNLGtCQUFVLEVBQUVnQixJQUhGO0FBSVZDLG9CQUpVO0FBS1ZoTixvQkFBWSxFQUFFLElBTEo7QUFNVkQ7QUFOVSxPQUFaO0FBUUQ7O0FBRUQsUUFBSXhLLEtBQUo7QUFDQSxRQUFJMlgsUUFBSjtBQUNBcmMsU0FBSyxDQUFDb2MsU0FBRCxFQUFZMWIsTUFBWixDQUFMO0FBRUEySSxNQUFFLENBQUNpVCxTQUFILENBQ0V4WCxJQURGLEVBRUV1UixJQUFJLENBQUNDLFNBQUwsQ0FBZThGLFNBQWYsRUFBMEIsSUFBMUIsRUFBZ0MsQ0FBaEMsQ0FGRixFQUdFOWMsTUFBTSxDQUFDMkwsZUFBUCxDQUF1QlcsR0FBRyxJQUFJO0FBQzVCLFVBQUlBLEdBQUosRUFBUztBQUNQLGNBQU0sSUFBSXRNLE1BQU0sQ0FBQ3FFLEtBQVgsQ0FDSiwwQkFESSxFQUVKLDRCQUZJLENBQU47QUFJRCxPQU4yQixDQU81Qjs7O0FBQ0EsVUFBSXdZLFlBQUosRUFBa0I7QUFDaEJ6WCxhQUFLLEdBQUcsVUFBUjtBQUNBMlgsZ0JBQVEsR0FBRyxPQUFYO0FBQ0QsT0FIRCxNQUdPO0FBQ0wzWCxhQUFLLEdBQUcsU0FBUjtBQUNBMlgsZ0JBQVEsR0FBRyxPQUFYO0FBQ0Q7O0FBQ0QvYyxZQUFNLENBQUM0VixJQUFQLENBQVksY0FBWixFQUE0QnhRLEtBQTVCLEVBQW1DMlgsUUFBbkMsRUFBNkNuSyxLQUFLLElBQUk7QUFDcERBLGFBQUssR0FBR0MsT0FBTyxDQUFDdkcsR0FBUixDQUFZc0csS0FBSyxDQUFDRyxNQUFsQixDQUFILEdBQStCRixPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLENBQXBDO0FBQ0QsT0FGRDtBQUdELEtBbEJELENBSEY7QUF1QkQ7QUExRFksQ0FBZixFOzs7Ozs7Ozs7OztBQ1JBLElBQUk5UyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk0SixFQUFKO0FBQU85SixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUM4QixTQUFPLENBQUM3QixDQUFELEVBQUc7QUFBQzRKLE1BQUUsR0FBQzVKLENBQUg7QUFBSzs7QUFBakIsQ0FBdkIsRUFBMEMsQ0FBMUM7QUFJdkVILE1BQU0sQ0FBQ3FULE9BQVAsQ0FBZSxNQUFNO0FBQ25CLFFBQU00SixXQUFXLEdBQUksR0FBRXZQLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxHQUFJLHFCQUF2QztBQUNBLFFBQU1zUCxPQUFPLEdBQUksR0FBRXhQLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxHQUFJLDZCQUFuQzs7QUFDQSxNQUFJO0FBQ0YsUUFBSTdELEVBQUUsQ0FBQ29ULFFBQUgsQ0FBWUYsV0FBWixDQUFKLEVBQThCO0FBQzVCbFQsUUFBRSxDQUFDcVQsSUFBSCxDQUFRSCxXQUFSLEVBQXFCQyxPQUFyQixFQUNHRyxJQURILENBQ1EsTUFBTXhLLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEVBQVosQ0FEZCxFQUVHd0ssS0FGSCxDQUVTaFIsR0FBRyxJQUFJdUcsT0FBTyxDQUFDRCxLQUFSLENBQWN0RyxHQUFkLENBRmhCO0FBR0QsS0FKRCxNQUlPO0FBQ0x1RyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBWjtBQUNEO0FBQ0YsR0FSRCxDQVFFLE9BQU94RyxHQUFQLEVBQVk7QUFDWnVHLFdBQU8sQ0FBQ0QsS0FBUixDQUFjdEcsR0FBZDtBQUNEO0FBQ0YsQ0FkRCxFOzs7Ozs7Ozs7OztBQ0pBck0sTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVo7QUFBc0JELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfRGVsZXRlZCB9IGZyb20gJy4uL2RlbGV0ZWQnO1xuXG5NZXRlb3IucHVibGlzaChudWxsLCAoKSA9PiBfRGVsZXRlZC5maW5kKHt9KSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBfRGVsZXRlZCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdkZWxldGVkJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrLCBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBfRGVsZXRlZCB9IGZyb20gJy4vZGVsZXRlZCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgLy8gIGZvciByZXNvdXJjZXNcbiAgaW5zZXJ0RGVsZXRlZDogKGlkLCBjb2wsIGZpbGUgPSBudWxsKSA9PiB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2soY29sLCBNYXRjaC5PbmVPZihTdHJpbmcsIG51bGwsIHVuZGVmaW5lZCkpO1xuICAgIGNoZWNrKGZpbGUsIE1hdGNoLk9uZU9mKE9iamVjdCwgbnVsbCwgdW5kZWZpbmVkKSk7XG5cbiAgICBfRGVsZXRlZC5pbnNlcnQoe1xuICAgICAgZGVsSWQ6IGlkLFxuICAgICAgZmlsZSxcbiAgICAgIGNvbCxcbiAgICAgIHN5bmM6IHt9LCAvLyB0aGlzIHNob3VsZCBjaGFuZ2UgdG9vXG4gICAgfSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5NZXRlb3IucHVibGlzaCgnYWxsLnVzZXJzJywgZnVuY3Rpb24gYWxsVXNlcnMoKSB7XG4gIGlmICghdGhpcy51c2VySWQgJiYgIVJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgIHJldHVybiB0aGlzLnJlYWR5KCk7XG4gIH1cbiAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChudWxsLCAoKSA9PiBNZXRlb3Iucm9sZXMuZmluZCh7fSkpO1xuXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuTWV0ZW9yLnVzZXJzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbmNvbnN0IFVzZXJQcm9maWxlID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG5hbWU6IFN0cmluZyxcbiAgZ2VuZGVyOiBTdHJpbmcsXG4gIHN0YXR1czogTnVtYmVyLFxuICBzdGF0czogTnVtYmVyLFxufSk7XG5cbmNvbnN0IFVzZXIgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgZW1haWxzOiBBcnJheSxcbiAgJ2VtYWlscy4kJzogT2JqZWN0LFxuICAnZW1haWxzLiQuYWRkcmVzcyc6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5FbWFpbCxcbiAgfSxcbiAgJ2VtYWlscy4kLnZlcmlmaWVkJzogQm9vbGVhbixcbiAgcHJvZmlsZTogVXNlclByb2ZpbGUsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbiAgc2VydmljZXM6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgYmxhY2tib3g6IHRydWUsXG4gIH0sXG4gIHJvbGVzOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgYmxhY2tib3g6IHRydWUsXG4gIH0sXG4gICdyb2xlcy4kJzogU3RyaW5nLFxufSk7XG5cbk1ldGVvci51c2Vycy5hdHRhY2hTY2hlbWEoVXNlcik7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICd1c2VyLmluc2VydCc6IHVzZXIgPT4ge1xuICAgIGNoZWNrKHVzZXIsIHtcbiAgICAgIGVtYWlsOiBTdHJpbmcsXG4gICAgICBwYXNzd29yZDogU3RyaW5nLFxuICAgICAgcHJvZmlsZTogT2JqZWN0LFxuICAgIH0pO1xuICAgIEFjY291bnRzLmNyZWF0ZVVzZXIodXNlcik7XG4gIH0sXG4gICdhY2NvdW50LmNoZWNrJzogZW1haWwgPT4ge1xuICAgIGNoZWNrKGVtYWlsLCBTdHJpbmcpO1xuICAgIGNvbnN0IGluaXRpYWxVc2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoKTtcbiAgICBjb25zdCB1c2VySWQgPSBpbml0aWFsVXNlci5faWQ7XG4gICAgY29uc3QgdXNlciA9IEFjY291bnRzLmZpbmRVc2VyQnlFbWFpbChlbWFpbCk7XG4gICAgaWYgKE1ldGVvci51c2Vycy5maW5kKCkuY291bnQoKSA9PT0gMSkge1xuICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJJZCwgJ2FkbWluJyk7XG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiB1c2VySWQgfSwgeyAkc2V0OiB7ICdwcm9maWxlLnN0YXR1cyc6IDEgfSB9KTtcbiAgICB9IGVsc2UgaWYgKCF1c2VyKSB7XG4gICAgICByZXR1cm4gJ1NvcnJ5IGVtYWlsIG5vdCBpZGVudGlmaWVkJztcbiAgICB9XG4gICAgLy8gcmVtb3ZlZCB0aGUgYWNjb3VudCBhcHByb3ZhbCBmb3Igbm93XG4gICAgLy8gZWxzZSBpZiAoKCF1c2VyLnByb2ZpbGUuc3RhdHVzIHx8IHVzZXIucHJvZmlsZS5zdGF0dXMgPT09IDIpKSB7XG4gICAgLy8gICByZXR1cm4gJ1NvcnJ5IGFjY291bnQgbm90IGFjdGl2YXRlZC4gSW5mb3JtIEFkbWluc3RyYXRvcic7XG4gICAgLy8gfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICd1c2VyLmFwcHJvdmUnOiBmdW5jdGlvbihpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgJ3Byb2ZpbGUuc3RhdHVzJzogMSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcbiAgICAgICAgJ1NvcnJ5JyxcbiAgICAgICAgXCJZb3UgZG9uJ3QgaGF2ZSBwZXJtaXNzaW9ucyB0byByZW1vdmUgYSB1c2VyXCIsXG4gICAgICApO1xuICAgIH1cbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICd1c2VyLnN1c3BlbmQnOiBmdW5jdGlvbihpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgJ3Byb2ZpbGUuc3RhdHVzJzogMixcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcbiAgICAgICAgJ1NvcnJ5JyxcbiAgICAgICAgXCJZb3UgZG9uJ3QgaGF2ZSBwZXJtaXNzaW9ucyB0byByZW1vdmUgYSB1c2VyXCIsXG4gICAgICApO1xuICAgIH1cbiAgfSxcbiAgcHJvbW90ZVVzZXIoaWQsIHJvbGUpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhyb2xlLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIC8vIE1ha2Ugc3VyZSB0aGUgYWRtaW4gZG9lc24ndCBibG9jayBoaW1zZWxmIG91dCBvZiB0aGUgcGxhdGZvcm1cbiAgICAgIC8vIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhpZCwgcm9sZSk7XG4gICAgICBpZiAoaWQgPT09IHRoaXMudXNlcklkKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICAgICAgJ09vcHMnLFxuICAgICAgICAgICdZb3UgY2FuIG5vdCBjaGFuZ2UgeW91ciBvd24gUm9sZSBhcyBhbiBBZG1pbicsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBSb2xlcy5zZXRVc2VyUm9sZXMoaWQsIHJvbGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAnU29ycnknLFxuICAgICAgICBcIllvdSBkb24ndCBoYXZlIHBlcm1pc3Npb25zIHRvIHByb21vdGUgYSB1c2VyXCIsXG4gICAgICApO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlVXNlcihpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIE1ldGVvci51c2Vycy5yZW1vdmUoaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAnU29ycnknLFxuICAgICAgICBcIllvdSBkb24ndCBoYXZlIHBlcm1pc3Npb25zIHRvIHJlbW92ZSBhIHVzZXJcIixcbiAgICAgICk7XG4gICAgfVxuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ3VzZXIudXBkYXRlJzogZnVuY3Rpb24oaWQsIG5hbWVmKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2sobmFtZWYsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiB7ICdwcm9maWxlLm5hbWUnOiBuYW1lZiB9IH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAnU29ycnknLFxuICAgICAgICBcIllvdSBkb24ndCBoYXZlIHBlcm1pc3Npb25zIHRvIHJlbW92ZSBhIHVzZXJcIixcbiAgICAgICk7XG4gICAgfVxuICB9LFxuICBhY2NvdW50RXhpc3QoZW1haWwpIHtcbiAgICBjaGVjayhlbWFpbCwgU3RyaW5nKTtcbiAgICBjb25zdCB1c2VyID0gQWNjb3VudHMuZmluZFVzZXJCeUVtYWlsKGVtYWlsKTtcbiAgICBpZiAodXNlcikge1xuICAgICAgcmV0dXJuICdTb3JyeSBlbWFpbCBhbHJlYWR5IHJlZ2lzdGVyZWQuJztcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuICAvLyByZXR1cm4gdGhlIG51bWJlciBvZiB1c2Vyc1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ251bS51c2Vycyc6IGZ1bmN0aW9uKCkge1xuICAgIGNvbnN0IHVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpO1xuICAgIHJldHVybiB1c2VycztcbiAgfSxcbiAgY2hhbmdlVXNlclBhc3N3b3JkKHVzZXJJZCwgcGFzc3dvcmQpIHtcbiAgICBjaGVjayh1c2VySWQsIFN0cmluZyk7XG4gICAgY2hlY2socGFzc3dvcmQsIFN0cmluZyk7XG4gICAgY29uc3QgaXNBZG1pbiA9IFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKTtcbiAgICBpZiAoaXNBZG1pbikge1xuICAgICAgQWNjb3VudHMuc2V0UGFzc3dvcmQodXNlcklkLCBwYXNzd29yZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ1NvcnJ5JywgJ0FuIEVycm9yIE9jdXJyZWQnKTtcbiAgICB9XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgX0Jvb2ttYXJrIH0gZnJvbSAnLi4vYm9va21hcmtzJztcbmltcG9ydCB7IGlzQXV0aFJlcXVpcmVkIH0gZnJvbSAnLi4vLi4vY29uZmlnL2NvbmZpZyc7XG5cbk1ldGVvci5wdWJsaXNoKCdib29rbWFya3MnLCBmdW5jdGlvbiBnZXRCb29rbWFya3MoKSB7XG4gIGlmICghaXNBdXRoUmVxdWlyZWQoKSkge1xuICAgIHRoaXMucmVhZHkoKTtcbiAgfVxuICByZXR1cm4gX0Jvb2ttYXJrLmZpbmQoe30pO1xufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmV4cG9ydCBjb25zdCBfQm9va21hcmsgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYm9va21hcmtzJywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pO1xuXG5fQm9va21hcmsuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuY29uc3QgYm9va01hcmtTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgdXNlcjogU3RyaW5nLFxuICB0aXRsZTogU3RyaW5nLFxuICBkZXNjcmlwdGlvbjogU3RyaW5nLFxuICB1cmw6IFN0cmluZyxcbiAgY29sb3I6IFN0cmluZyxcbiAgcGF0aDogU3RyaW5nLFxuICBjcmVhdGVkQXQ6IERhdGUsXG59KTtcblxuX0Jvb2ttYXJrLmF0dGFjaFNjaGVtYShib29rTWFya1NjaGVtYSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IF9Cb29rbWFyayB9IGZyb20gJy4vYm9va21hcmtzJztcbi8vIHRoZXJlIHNob3VsZCBiZSBhZGRlZCBhIGJldHRlciB3YXkgb2YgaW5zZXJ0aW5nIGEgYm9va21hcmsgbm90IHVwZGF0aW5nIHRoZSBub24tZXhpc3Rpbmcgb25lXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgdXBkYXRlQm9va21hcmsoYm9va21hcmssIHRpdGxlLCBkZXNjcmlwdGlvbiwgdXJsLCBjb2xvciwgcGF0aCkge1xuICAgIC8vIFRPRE86IGNvbnN0cnVjdCB0aGUgd2hvbGUgaW5wdXQgYXMgYW4gb2JqZWN0IHRvIGhhdmUgaXQgY2hlY2tlZCBvbmNlXG4gICAgY2hlY2soYm9va21hcmssIE1hdGNoLk9uZU9mKHVuZGVmaW5lZCwgbnVsbCwgU3RyaW5nKSk7XG4gICAgY2hlY2sodGl0bGUsIFN0cmluZyk7XG4gICAgY2hlY2soZGVzY3JpcHRpb24sIFN0cmluZyk7XG4gICAgY2hlY2sodXJsLCBTdHJpbmcpO1xuICAgIGNoZWNrKGNvbG9yLCBTdHJpbmcpO1xuICAgIGNoZWNrKHBhdGgsIFN0cmluZyk7XG5cbiAgICBfQm9va21hcmsudXBkYXRlKFxuICAgICAgeyBfaWQ6IGJvb2ttYXJrIH0sXG4gICAgICB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICB1c2VyOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICB0aXRsZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbixcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgY29sb3IsXG4gICAgICAgICAgcGF0aCxcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgeyB1cHNlcnQ6IHRydWUgfSxcbiAgICApO1xuICB9LFxuICByZW1vdmVCb29rbWFyayhpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIF9Cb29rbWFyay5yZW1vdmUoeyBfaWQ6IGlkLCB1c2VyOiB0aGlzLnVzZXJJZCB9KTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfQ291cnNlcyB9IGZyb20gJy4uL2NvdXJzZXMnO1xuaW1wb3J0IHsgaXNBdXRoUmVxdWlyZWQgfSBmcm9tICcuLi8uLi9jb25maWcvY29uZmlnJztcblxuLy8gcHVibGlzaGVzIGFsbCBjb3Vyc2VzO1xuTWV0ZW9yLnB1Ymxpc2goJ2NvdXJzZXMnLCBmdW5jdGlvbiBhbGxDb3Vyc2VzKCkge1xuICBpZiAoIWlzQXV0aFJlcXVpcmVkKCkpIHtcbiAgICByZXR1cm4gdGhpcy5yZWFkeSgpO1xuICB9XG4gIHJldHVybiBfQ291cnNlcy5maW5kKHt9KTtcbn0pO1xuXG4vLyBwdWJsaXNoIHdoZW4gc2Nob29sIGlzIGF2YWlsYWJsZVxuXG5NZXRlb3IucHVibGlzaCgnc2Nob29sLmNvdXJzZXMnLCBmdW5jdGlvbiBwcm9ncmFtQ291cnNlcyhpZCkge1xuICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgaWYgKCFpc0F1dGhSZXF1aXJlZCgpKSB7XG4gICAgcmV0dXJuIHRoaXMucmVhZHkoKTtcbiAgfVxuICByZXR1cm4gX0NvdXJzZXMuZmluZCh7ICdkZXRhaWxzLnByb2dyYW1JZCc6IGlkIH0pO1xufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmV4cG9ydCBjb25zdCBfQ291cnNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb3Vyc2UnKTtcblxuX0NvdXJzZXMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuY29uc3QgU2NoZW1hID0ge307XG5cblNjaGVtYS5kZXRhaWxzID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHNjaG9vbElkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBwcm9ncmFtSWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGxhbmd1YWdlOiBTdHJpbmcsXG59KTtcblxuU2NoZW1hLkNvdXJzZSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBuYW1lOiBTdHJpbmcsXG4gIGNvZGU6IFN0cmluZyxcbiAgZGV0YWlsczogU2NoZW1hLmRldGFpbHMsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbiAgY3JlYXRlZEJ5OiBTdHJpbmcsXG59KTtcblxuX0NvdXJzZXMuYXR0YWNoU2NoZW1hKFNjaGVtYS5Db3Vyc2UpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgeyBfQ291cnNlcyB9IGZyb20gJy4vY291cnNlcyc7XG5pbXBvcnQgeyBfVW5pdHMgfSBmcm9tICcuLi91bml0cy91bml0cyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2NvdXJzZS5hZGQnOiBmdW5jdGlvbiBjb3Vyc2VBZGQoaWQsIGNvdXJzZSwgY291cnNlQ29kZSwgZGV0YWlscykge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGNoZWNrKGNvdXJzZSwgU3RyaW5nKTtcbiAgICBjaGVjayhjb3Vyc2VDb2RlLCBTdHJpbmcpO1xuICAgIGNoZWNrKGRldGFpbHMsIE9iamVjdCk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIF9Db3Vyc2VzLmluc2VydCh7XG4gICAgICAgIF9pZDogaWQsXG4gICAgICAgIG5hbWU6IGNvdXJzZSxcbiAgICAgICAgY29kZTogY291cnNlQ29kZSxcbiAgICAgICAgZGV0YWlscyxcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAnY291cnNlLmVkaXQnKGlkLCBjb3Vyc2UsIGNvdXJzZUNvZGUsIGxhbmd1YWdlLCBvd25lcklkKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2soY291cnNlLCBTdHJpbmcpO1xuICAgIGNoZWNrKGNvdXJzZUNvZGUsIFN0cmluZyk7XG4gICAgY2hlY2sobGFuZ3VhZ2UsIFN0cmluZyk7XG4gICAgY2hlY2sob3duZXJJZCwgU3RyaW5nKTtcblxuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfQ291cnNlcy51cGRhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgbmFtZTogY291cnNlLFxuICAgICAgICAgICAgY29kZTogY291cnNlQ29kZSxcbiAgICAgICAgICAgICdkZXRhaWxzLmxhbmd1YWdlJzogbGFuZ3VhZ2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBub3QgbWFrZSBjaGFuZ2VzJyk7XG4gICAgfVxuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ2NvdXJzZS5yZW1vdmUnOiBmdW5jdGlvbihpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuXG4gICAgY29uc3QgdW5pdHMgPSBfVW5pdHNcbiAgICAgIC5maW5kKHtcbiAgICAgICAgJ2RldGFpbHMuY291cnNlSWQnOiBpZCxcbiAgICAgIH0pXG4gICAgICAuZmV0Y2goKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJywgJ2NvbnRlbnQtbWFuYWdlciddKSkge1xuICAgICAgaWYgKHVuaXRzLmxlbmd0aCA+PSAxKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICAgICAgJ3NvcnJ5JyxcbiAgICAgICAgICAnVGhlIHNlbGVjdGVkIGNvdXJzZSBoYXMgdW5pdHMgdGhhdCBkZXBlbmQgb24gaXQnLFxuICAgICAgICApO1xuICAgICAgfSBlbHNlIGlmICh1bml0cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgX0NvdXJzZXMucmVtb3ZlKGlkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICAgICAgJ25vLXJpZ2h0cycsXG4gICAgICAgICAgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gcmVtb3ZlIHRoZSBzZWxlY3RlZCBjb3Vyc2UnLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICdjb3Vyc2VzLmNvdW50JzogZnVuY3Rpb24oKSB7XG4gICAgX0NvdXJzZXMuZmluZCgpLmNvdW50KCk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgX0V4dGVybmFsTGluayB9IGZyb20gJy4uL2V4dGVybmFsbGluayc7XG5pbXBvcnQgeyBpc0F1dGhSZXF1aXJlZCB9IGZyb20gJy4uLy4uL2NvbmZpZy9jb25maWcnO1xuXG5NZXRlb3IucHVibGlzaCgnZXh0ZXJuYWxsaW5rcycsIGZ1bmN0aW9uIGdldEV4dGVybmFsTGlua3MoKSB7XG4gIGlmICghaXNBdXRoUmVxdWlyZWQoKSkge1xuICAgIHRoaXMucmVhZHkoKTtcbiAgfVxuICByZXR1cm4gX0V4dGVybmFsTGluay5maW5kKHt9KTtcbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5leHBvcnQgY29uc3QgX0V4dGVybmFsTGluayA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdleHRlcm5hbGxpbmtzJywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pO1xuXG5fRXh0ZXJuYWxMaW5rLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbmNvbnN0IGV4dGVybmFsTGlua1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBuYW1lOiBTdHJpbmcsXG4gIHVybDogU3RyaW5nLFxuICBjcmVhdGVkQXQ6IERhdGUsXG59KTtcblxuX0V4dGVybmFsTGluay5hdHRhY2hTY2hlbWEoZXh0ZXJuYWxMaW5rU2NoZW1hKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xuaW1wb3J0IHsgX0V4dGVybmFsTGluayB9IGZyb20gJy4vZXh0ZXJuYWxsaW5rJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnZXh0ZXJuYWxsaW5rLmFkZCc6IGZ1bmN0aW9uIGFkZEV4dGVybmFsTGluayhpZCwgZXh0ZXJuYWxsaW5rLCB1cmwpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhleHRlcm5hbGxpbmssIFN0cmluZyk7XG4gICAgY2hlY2sodXJsLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfRXh0ZXJuYWxMaW5rLmluc2VydCh7XG4gICAgICAgIF9pZDogaWQsXG4gICAgICAgIG5hbWU6IGV4dGVybmFsbGluayxcbiAgICAgICAgdXJsLFxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICB9KTtcbiAgICAgIC8vIFlvdSBjYW4gYWxzbyB0cmlnZ2VyIGlmIHNvbWV0aGluZyB3cm9uZyBoYXBwZW5zXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBub3QgbWFrZSBjaGFuZ2VzJyk7XG4gICAgfVxuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ2V4dGVybmFsbGluay5lZGl0JyhpZCwgZXh0ZXJuYWxsaW5rLCB1cmwpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhleHRlcm5hbGxpbmssIFN0cmluZyk7XG4gICAgY2hlY2sodXJsLCBTdHJpbmcpO1xuXG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIF9FeHRlcm5hbExpbmsudXBkYXRlKFxuICAgICAgICB7IF9pZDogaWQgfSxcbiAgICAgICAge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIG5hbWU6IGV4dGVybmFsbGluayxcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIG5vdCBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAnZXh0ZXJuYWxsaW5rLnJlbW92ZScoaWQpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcblxuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfRXh0ZXJuYWxMaW5rLnJlbW92ZShpZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICAgICduby1yaWdodHMnLFxuICAgICAgICAnWW91IGFyZSBub3QgYWxsb3dlZCB0byByZW1vdmUgdGhlIHNlbGVjdGVkIGV4dGVybmFsIExpbmsnLFxuICAgICAgKTtcbiAgICB9XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgX0ZlZWRiYWNrIH0gZnJvbSAnLi4vZmVlZGJhY2snO1xuXG5NZXRlb3IucHVibGlzaCgnZmVlZGJhY2tzJywgKCkgPT4gX0ZlZWRiYWNrLmZpbmQoe30pKTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuZXhwb3J0IGNvbnN0IF9GZWVkYmFjayA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmZWVkYmFjaycsIHsgaWRHZW5lcmF0aW9uOiAnU1RSSU5HJyB9KTtcblxuLy8gYXR0YWNoIHRoZSBzY2hlbWEgYW5kIGRlZmluZSB0aGUgcnVsZXNcbmNvbnN0IFNjaGVtYSA9IHt9O1xuXG5TY2hlbWEuZmVlZFNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0aXRsZTogU3RyaW5nLFxuICBmZWVkYmFjazogU3RyaW5nLFxuICBsaW5rOiBTdHJpbmcsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbiAgY3JlYXRlZEJ5OiBTdHJpbmcsXG59KTtcblxuX0ZlZWRiYWNrLmF0dGFjaFNjaGVtYShTY2hlbWEuZmVlZFNjaGVtYSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IF9GZWVkYmFjayB9IGZyb20gJy4vZmVlZGJhY2snO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdmZWVkYmFjay5pbnNlcnQnOiAodGl0bGUsIGZlZWRiYWNrLCBsaW5rLCBuYW1lKSA9PiB7XG4gICAgY2hlY2sodGl0bGUsIFN0cmluZyk7XG4gICAgY2hlY2soZmVlZGJhY2ssIFN0cmluZyk7XG4gICAgY2hlY2sobGluaywgU3RyaW5nKTtcbiAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuXG4gICAgX0ZlZWRiYWNrLmluc2VydCh7XG4gICAgICB0aXRsZSxcbiAgICAgIGZlZWRiYWNrLFxuICAgICAgbGluayxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgIGNyZWF0ZWRCeTogbmFtZSxcbiAgICB9KTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfTm90aWZpY2F0aW9ucyB9IGZyb20gJy4uL25vdGlmaWNhdGlvbnMnO1xuaW1wb3J0IHsgaXNBdXRoUmVxdWlyZWQgfSBmcm9tICcuLi8uLi9jb25maWcvY29uZmlnJztcblxuTWV0ZW9yLnB1Ymxpc2goJ25vdGlmaWNhdGlvbnMnLCBmdW5jdGlvbiBwdWJsaXNoTm90ZSgpIHtcbiAgaWYgKCFpc0F1dGhSZXF1aXJlZCgpKSB7XG4gICAgdGhpcy5yZWFkeSgpO1xuICB9XG4gIHJldHVybiBfTm90aWZpY2F0aW9ucy5maW5kKHsgdXNlcklkOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBfTm90aWZpY2F0aW9ucyB9IGZyb20gJy4vbm90aWZpY2F0aW9ucyc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBpbnNlcnROb3RpZmljYXRpb24odGl0bGUsIGNhdGVnb3J5LCB1bml0SWQgPSAnJywgdG9waWNJZCA9ICcnLCBmaWxlSWQgPSAnJykge1xuICAgIGNoZWNrKHVuaXRJZCwgU3RyaW5nKTtcbiAgICBjaGVjayh0b3BpY0lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKGZpbGVJZCwgU3RyaW5nKTtcbiAgICBjaGVjayh0aXRsZSwgU3RyaW5nKTtcbiAgICBjaGVjayhjYXRlZ29yeSwgU3RyaW5nKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJywgJ2NvbnRlbnQtbWFuYWdlciddKSkge1xuICAgICAgY29uc3QgdGVzdFVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoKTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgdGVzdFVzZXJzLm1hcCh1c3IgPT4ge1xuICAgICAgICBjb25zdCBfaWQgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24uT2JqZWN0SUQoKS52YWx1ZU9mKCk7XG4gICAgICAgIGNvbnN0IHVzZXJJZCA9IHVzci5faWQ7XG4gICAgICAgIC8vIGluc2VydCBpbiBOb3RpZmljYXRpb25zXG4gICAgICAgIF9Ob3RpZmljYXRpb25zLmluc2VydCh7XG4gICAgICAgICAgX2lkLFxuICAgICAgICAgIHVzZXJJZCxcbiAgICAgICAgICB1bml0SWQsXG4gICAgICAgICAgdG9waWNJZCxcbiAgICAgICAgICBmaWxlSWQsXG4gICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgY2F0ZWdvcnksXG4gICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICAgIHJlYWQ6IGZhbHNlLFxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1RoZXJlIHdhcyBhIHByb2JsZW0gdXBkYXRpbmcgTm90aWZpY2F0aW9ucycpO1xuICAgIH1cbiAgfSxcbiAgbWFya1JlYWQoaWQsIGJvb2wpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhib29sLCBCb29sZWFuKTtcbiAgICBfTm90aWZpY2F0aW9ucy51cGRhdGUoXG4gICAgICB7XG4gICAgICAgIF9pZDogaWQsXG4gICAgICAgIHVzZXJJZDogdGhpcy51c2VySWQsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgcmVhZDogYm9vbCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgfSxcbiAgLy8gcmVtb3ZlIG5vdGlmaWNhdGlvbnMgdGhhdCBiZWxvbmcgdG8gdGhlIHVzZXIgYW5kIGhhdmUgYmVlbiByZWFkXG4gIGRyb3BVc2VyTm90aWZpY2F0aW9ucygpIHtcbiAgICByZXR1cm4gX05vdGlmaWNhdGlvbnMucmVtb3ZlKHsgcmVhZDogdHJ1ZSwgdXNlcklkOiB0aGlzLnVzZXJJZCB9KTtcbiAgfSxcblxuICAvLyByZW1vdmUgbm90aWZpY2F0aW9ucyB0aGF0IGJlbG9uZyB0byB0aGUgdXNlclxuICBkcm9wQWxsVXNlck5vdGlmaWNhdGlvbnMoKSB7XG4gICAgcmV0dXJuIF9Ob3RpZmljYXRpb25zLnJlbW92ZSh7IHVzZXJJZDogdGhpcy51c2VySWQgfSk7XG4gIH0sXG5cbiAgLy8gcmVtb3ZlIG5vdGlmaWNhdGlvbnMgb2xkZXIgdGhhbiAzMGRheXMgZm9yIGFsbCB1c2Vyc1xuICBkcm9wTm90aWZpY2F0aW9ucygpIHtcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoKTtcbiAgICBjb25zdCBkYXlzVG9EZWxldGlvbiA9IDMwOyAvLyAnRGVsZXRlIGFmdGVyIDMwZGF5cydcbiAgICBjb25zdCBkZWxldGlvbkRhdGUgPSBuZXcgRGF0ZShkYXRlLnNldERhdGUoZGF0ZS5nZXREYXRlKCkgLSBkYXlzVG9EZWxldGlvbikpO1xuICAgIHJldHVybiBfTm90aWZpY2F0aW9ucy5yZW1vdmUoeyBjcmVhdGVkQXQ6IHsgJGx0ZTogZGVsZXRpb25EYXRlIH0gfSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuZXhwb3J0IGNvbnN0IF9Ob3RpZmljYXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ25vdGlmaWNhdGlvbicpO1xuXG5fTm90aWZpY2F0aW9ucy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5jb25zdCBub3RlZlNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB1c2VySWQ6IFN0cmluZyxcbiAgdW5pdElkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICB0b3BpY0lkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBmaWxlSWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHRpdGxlOiBTdHJpbmcsXG4gIGNhdGVnb3J5OiBTdHJpbmcsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbiAgcmVhZDogQm9vbGVhbixcbn0pO1xuXG5fTm90aWZpY2F0aW9ucy5hdHRhY2hTY2hlbWEobm90ZWZTY2hlbWEpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSZXNvdXJjZXMsIFJlZmVyZW5jZXMgfSBmcm9tICcuLi9yZXNvdXJjZXMnO1xuaW1wb3J0IHsgaXNBdXRoUmVxdWlyZWQgfSBmcm9tICcuLi8uLi9jb25maWcvY29uZmlnJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3Jlc291cmNlc3MnLCBmdW5jdGlvbiBhbGxSZXNvdXJjZSgpIHtcbiAgaWYgKCFpc0F1dGhSZXF1aXJlZCgpKSB7XG4gICAgdGhpcy5yZWFkeSgpO1xuICB9XG4gIHJldHVybiBSZXNvdXJjZXMuZmluZCgpLmN1cnNvcjtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgncmVmZXJlbmNlcycsIGZ1bmN0aW9uIGFsbFJlc291cmNlKCkge1xuICBpZiAoIWlzQXV0aFJlcXVpcmVkKCkpIHtcbiAgICB0aGlzLnJlYWR5KCk7XG4gIH1cbiAgcmV0dXJuIFJlZmVyZW5jZXMuZmluZCgpLmN1cnNvcjtcbn0pO1xuXG4vLyBNZXRlb3IucHVibGlzaCgncmVzb3VyY2VzcycsICgpID0+IFJlc291cmNlcy5maW5kKCkuY3Vyc29yKTtcbi8vIE1ldGVvci5wdWJsaXNoKCdyZWZlcmVuY2VzJywgKCkgPT4gUmVmZXJlbmNlcy5maW5kKCkuY3Vyc29yKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgUmVzb3VyY2VzLCBSZWZlcmVuY2VzIH0gZnJvbSAnLi9yZXNvdXJjZXMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIHVwZGF0ZVJlc291cmNlKGlkLCByZXNvdXJjZSkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHJlc291cmNlLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBSZXNvdXJjZXMudXBkYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIG5hbWU6IHJlc291cmNlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcbiAgdXBkYXRlUmVmZXJlbmNlKGlkLCByZWZlcmVuY2UpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhyZWZlcmVuY2UsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIFJlZmVyZW5jZXMudXBkYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIG5hbWU6IHJlZmVyZW5jZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIG5vdCBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG4gIHJlbW92ZVJlc291cmNlKGlkKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIFJlc291cmNlcy5yZW1vdmUoaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gcmVtb3ZlIHRoZSByZXNvdXJjZScpO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlUmVmZXJlbmNlKGlkKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIFJlZmVyZW5jZXMucmVtb3ZlKGlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIHJlbW92ZSB0aGUgcmVzb3VyY2UnKTtcbiAgICB9XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1vbmdvLCBNb25nb0ludGVybmFscyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG4vLyBpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBGaWxlc0NvbGxlY3Rpb24gfSBmcm9tICdtZXRlb3Ivb3N0cmlvOmZpbGVzJztcbmltcG9ydCBHcmlkIGZyb20gJ2dyaWRmcy1zdHJlYW0nO1xuLy8gaW1wb3J0IHsgIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBmcyBmcm9tICdmcyc7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcblxubGV0IGdmcztcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgZ2ZzID0gR3JpZChNb25nb0ludGVybmFscy5kZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlcigpLm1vbmdvLmRiLCBNb25nb0ludGVybmFscy5OcG1Nb2R1bGUpO1xufVxuXG5leHBvcnQgY29uc3QgX0VncmFuYXJ5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2VncmFuYXJ5JywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pOyAvLyB2b2lkIGtlcHQgZm9yIHRoZSBzeW5jXG5jb25zdCB2YWxpZFR5cGVzID0gWydwbmcnLCAnanBnJywgJ2pwZWcnLCAnbXA0JywgJ3BkZicsICdtcDMnLCAncHB0eCcsICdwcHQnLCAnd2VibScsICdvZ2cnLCAndHh0J107XG5cbmV4cG9ydCBjb25zdCBSZXNvdXJjZXMgPSBuZXcgRmlsZXNDb2xsZWN0aW9uKHtcbiAgY29sbGVjdGlvbk5hbWU6ICdSZXNvdXJjZXMnLFxuICBhbGxvd0NsaWVudENvZGU6IHRydWUsIC8vIERpc2FsbG93IHJlbW92ZSBmaWxlcyBmcm9tIENsaWVudFxuICBvbkJlZm9yZVVwbG9hZChmaWxlKSB7XG4gICAgLy8gQWxsb3cgdXBsb2FkIGZpbGVzIHVuZGVyIDVHYiwgYW5kIG9ubHkgaW4gcG5nL2pwZy9qcGVnIGZvcm1hdHNcbiAgICBpZiAoZmlsZS5zaXplID49IDUzNjg3MDkxMjApIHtcbiAgICAgIHJldHVybiAnUGxlYXNlIHVwbG9hZCBmaWxlcywgd2l0aCBzaXplIGVxdWFsIG9yIGxlc3MgdGhhbiA1R0InO1xuICAgIH0gZWxzZSBpZiAoIXZhbGlkVHlwZXMuaW5jbHVkZXMoZmlsZS5leHQpKSB7XG4gICAgICByZXR1cm4gYFBsZWFzZSB1cGxvYWQgZWl0aGVyIG9uZSBvZiB0aGUgZm9sbG93aW5nIGZvcm1hdHMgJHt2YWxpZFR5cGVzLmpvaW4oKX1gO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgb25BZnRlclVwbG9hZChmaWxlKSB7XG4gICAgLy8gTW92ZSBmaWxlIHRvIEdyaWRGU1xuICAgIE9iamVjdC5rZXlzKGZpbGUudmVyc2lvbnMpLmZvckVhY2godmVyc2lvbk5hbWUgPT4ge1xuICAgICAgY29uc3QgbWV0YWRhdGEgPSB7IHZlcnNpb25OYW1lLCBmaWxlSWQ6IGZpbGUuX2lkLCBzdG9yZWRBdDogbmV3IERhdGUoKSB9OyAvLyBPcHRpb25hbFxuICAgICAgY29uc3Qgd3JpdGVTdHJlYW0gPSBnZnMuY3JlYXRlV3JpdGVTdHJlYW0oeyBmaWxlbmFtZTogZmlsZS5uYW1lLCBtZXRhZGF0YSB9KTtcblxuICAgICAgZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlLnZlcnNpb25zW3ZlcnNpb25OYW1lXS5wYXRoKS5waXBlKHdyaXRlU3RyZWFtKTtcblxuICAgICAgd3JpdGVTdHJlYW0ub24oXG4gICAgICAgICdjbG9zZScsXG4gICAgICAgIE1ldGVvci5iaW5kRW52aXJvbm1lbnQodXBsb2FkZWRGaWxlID0+IHtcbiAgICAgICAgICBjb25zdCBwcm9wZXJ0eSA9IGB2ZXJzaW9ucy4ke3ZlcnNpb25OYW1lfS5tZXRhLmdyaWRGc0ZpbGVJZGA7XG4gICAgICAgICAgLy8gSWYgd2Ugc3RvcmUgdGhlIE9iamVjdElEIGl0c2VsZiwgTWV0ZW9yIChFSlNPTj8pIHNlZW1zIHRvIGNvbnZlcnQgaXQgdG8gYVxuICAgICAgICAgIC8vIExvY2FsQ29sbGVjdGlvbi5PYmplY3RJRCwgd2hpY2ggR0ZTIGRvZXNuJ3QgdW5kZXJzdGFuZC5cbiAgICAgICAgICB0aGlzLmNvbGxlY3Rpb24udXBkYXRlKGZpbGUuX2lkLnRvU3RyaW5nKCksIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgW3Byb3BlcnR5XTogdXBsb2FkZWRGaWxlLl9pZC50b1N0cmluZygpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLnVubGluayh0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShmaWxlLl9pZC50b1N0cmluZygpKSwgdmVyc2lvbk5hbWUpOyAvLyBVbmxpbmsgZmlsZSBieSB2ZXJzaW9uIGZyb20gRlNcbiAgICAgICAgfSksXG4gICAgICApO1xuICAgIH0pO1xuICB9LFxuICBpbnRlcmNlcHREb3dubG9hZChodHRwLCBmaWxlLCB2ZXJzaW9uTmFtZSkge1xuICAgIGNvbnN0IF9pZCA9IChmaWxlLnZlcnNpb25zW3ZlcnNpb25OYW1lXS5tZXRhIHx8IHt9KS5ncmlkRnNGaWxlSWQ7XG4gICAgaWYgKF9pZCkge1xuICAgICAgY29uc3QgcmVhZFN0cmVhbSA9IGdmcy5jcmVhdGVSZWFkU3RyZWFtKHsgX2lkIH0pO1xuICAgICAgcmVhZFN0cmVhbS5vbignZXJyb3InLCBlcnIgPT4ge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9KTtcbiAgICAgIHJlYWRTdHJlYW0ucGlwZShodHRwLnJlc3BvbnNlKTtcbiAgICB9XG4gICAgcmV0dXJuIEJvb2xlYW4oX2lkKTtcbiAgfSxcbiAgb25BZnRlclJlbW92ZShpbWFnZXMpIHtcbiAgICBpbWFnZXMuZm9yRWFjaChpbWFnZSA9PiB7XG4gICAgICBPYmplY3Qua2V5cyhpbWFnZS52ZXJzaW9ucykuZm9yRWFjaCh2ZXJzaW9uTmFtZSA9PiB7XG4gICAgICAgIGNvbnN0IF9pZCA9IChpbWFnZS52ZXJzaW9uc1t2ZXJzaW9uTmFtZV0ubWV0YSB8fCB7fSkuZ3JpZEZzRmlsZUlkO1xuICAgICAgICBpZiAoX2lkKSB7XG4gICAgICAgICAgZ2ZzLnJlbW92ZSh7IF9pZCB9LCBlcnIgPT4ge1xuICAgICAgICAgICAgaWYgKGVycikgdGhyb3cgZXJyO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSxcbn0pO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIFJlc291cmNlcy5hbGxvd0NsaWVudCgpO1xufVxuXG5leHBvcnQgY29uc3QgUmVmZXJlbmNlcyA9IG5ldyBGaWxlc0NvbGxlY3Rpb24oe1xuICBjb2xsZWN0aW9uTmFtZTogJ1JlZmVyZW5jZXMnLFxuICBhbGxvd0NsaWVudENvZGU6IGZhbHNlLFxuICBvbkJlZm9yZVVwbG9hZChmaWxlKSB7XG4gICAgLy8gQWxsb3cgdXBsb2FkIGZpbGVzIHVuZGVyIDVHYiwgYW5kIG9ubHkgaW4gbGlzdGVkIGZvcm1hdHNcbiAgICBpZiAoZmlsZS5zaXplID49IDUzNjg3MDkxMjApIHtcbiAgICAgIHJldHVybiAnUGxlYXNlIHVwbG9hZCBmaWxlcywgd2l0aCBzaXplIGVxdWFsIG9yIGxlc3MgdGhhbiA1R0InO1xuICAgIH0gZWxzZSBpZiAoIXZhbGlkVHlwZXMuaW5jbHVkZXMoZmlsZS5leHQpKSB7XG4gICAgICByZXR1cm4gYFBsZWFzZSB1cGxvYWQgZWl0aGVyIG9uZSBvZiB0aGUgZm9sbG93aW5nIGZvcm1hdHMgJHt2YWxpZFR5cGVzLmpvaW4oKX1gO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgb25BZnRlclVwbG9hZChmaWxlKSB7XG4gICAgLy8gTW92ZSBmaWxlIHRvIEdyaWRGU1xuICAgIE9iamVjdC5rZXlzKGZpbGUudmVyc2lvbnMpLmZvckVhY2godmVyc2lvbk5hbWUgPT4ge1xuICAgICAgY29uc3QgbWV0YWRhdGEgPSB7IHZlcnNpb25OYW1lLCBmaWxlSWQ6IGZpbGUuX2lkLCBzdG9yZWRBdDogbmV3IERhdGUoKSB9OyAvLyBPcHRpb25hbFxuICAgICAgY29uc3Qgd3JpdGVTdHJlYW0gPSBnZnMuY3JlYXRlV3JpdGVTdHJlYW0oeyBmaWxlbmFtZTogZmlsZS5uYW1lLCBtZXRhZGF0YSB9KTtcblxuICAgICAgZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlLnZlcnNpb25zW3ZlcnNpb25OYW1lXS5wYXRoKS5waXBlKHdyaXRlU3RyZWFtKTtcblxuICAgICAgd3JpdGVTdHJlYW0ub24oXG4gICAgICAgICdjbG9zZScsXG4gICAgICAgIE1ldGVvci5iaW5kRW52aXJvbm1lbnQodXBsb2FkZWRGaWxlID0+IHtcbiAgICAgICAgICBjb25zdCBwcm9wZXJ0eSA9IGB2ZXJzaW9ucy4ke3ZlcnNpb25OYW1lfS5tZXRhLmdyaWRGc0ZpbGVJZGA7XG5cbiAgICAgICAgICB0aGlzLmNvbGxlY3Rpb24udXBkYXRlKGZpbGUuX2lkLnRvU3RyaW5nKCksIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgW3Byb3BlcnR5XTogdXBsb2FkZWRGaWxlLl9pZC50b1N0cmluZygpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLnVubGluayh0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShmaWxlLl9pZC50b1N0cmluZygpKSwgdmVyc2lvbk5hbWUpOyAvLyBVbmxpbmsgZmlsZSBieSB2ZXJzaW9uIGZyb20gRlNcbiAgICAgICAgfSksXG4gICAgICApO1xuICAgIH0pO1xuICB9LFxuICBpbnRlcmNlcHREb3dubG9hZChodHRwLCBmaWxlLCB2ZXJzaW9uTmFtZSkge1xuICAgIGNvbnN0IF9pZCA9IChmaWxlLnZlcnNpb25zW3ZlcnNpb25OYW1lXS5tZXRhIHx8IHt9KS5ncmlkRnNGaWxlSWQ7XG4gICAgaWYgKF9pZCkge1xuICAgICAgY29uc3QgcmVhZFN0cmVhbSA9IGdmcy5jcmVhdGVSZWFkU3RyZWFtKHsgX2lkIH0pO1xuICAgICAgcmVhZFN0cmVhbS5vbignZXJyb3InLCBlcnIgPT4ge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9KTtcbiAgICAgIHJlYWRTdHJlYW0ucGlwZShodHRwLnJlc3BvbnNlKTtcbiAgICB9XG4gICAgcmV0dXJuIEJvb2xlYW4oX2lkKTtcbiAgfSxcbiAgb25BZnRlclJlbW92ZShmaWxlcykge1xuICAgIGZpbGVzLmZvckVhY2goZmlsZSA9PiB7XG4gICAgICBPYmplY3Qua2V5cyhmaWxlLnZlcnNpb25zKS5mb3JFYWNoKHZlcnNpb25OYW1lID0+IHtcbiAgICAgICAgY29uc3QgX2lkID0gKGZpbGUudmVyc2lvbnNbdmVyc2lvbk5hbWVdLm1ldGEgfHwge30pLmdyaWRGc0ZpbGVJZDtcbiAgICAgICAgaWYgKF9pZCkge1xuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgICAgICBnZnMucmVtb3ZlKHsgX2lkIH0sIGVyciA9PiB7XG4gICAgICAgICAgICBpZiAoZXJyKSB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IF9TZWFyY2hEYXRhIH0gZnJvbSAnLi4vc2VhcmNoJztcblxuTWV0ZW9yLnB1Ymxpc2gobnVsbCwgKCkgPT4gX1NlYXJjaERhdGEuZmluZCh7fSkpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBfU2VhcmNoRGF0YSB9IGZyb20gJy4vc2VhcmNoJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgcmVtb3ZlU2VhcmNoRGF0YShpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfU2VhcmNoRGF0YS5yZW1vdmUoaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gIHVwZGF0ZVNlYXJjaDogZnVuY3Rpb24oaWQsIG5hbWUpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfU2VhcmNoRGF0YS51cGRhdGUoXG4gICAgICAgIHsgX2lkOiBpZCB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDogeyBuYW1lLCBfaWRzOiB7fSB9LFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIG5vdCBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAnaW5zZXJ0LnNlYXJjaCc6IGZ1bmN0aW9uKGlkLCBpZHMsIG5hbWUsIGNhdGVnb3J5KSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2soaWRzLCBPYmplY3QpO1xuICAgIGNoZWNrKG5hbWUsIFN0cmluZyk7XG4gICAgY2hlY2soY2F0ZWdvcnksIFN0cmluZyk7XG5cbiAgICBfU2VhcmNoRGF0YS5pbnNlcnQoe1xuICAgICAgX2lkOiBpZCxcbiAgICAgIGlkcyxcbiAgICAgIG5hbWUsXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICB9KTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5leHBvcnQgY29uc3QgX1NlYXJjaERhdGEgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2VhcmNoJywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pO1xuXG5fU2VhcmNoRGF0YS5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5jb25zdCBTY2hlbWEgPSB7fTtcblxuU2NoZW1hLmlkcyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB1bml0SWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHJlc291cmNlSWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHRvcGljSWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGNvdXJzZUlkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxufSk7XG5cblNjaGVtYS5zZWFyY2hTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgaWRzOiBTY2hlbWEuaWRzLFxuICBuYW1lOiBTdHJpbmcsXG4gIGNhdGVnb3J5OiBTdHJpbmcsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbn0pO1xuXG5fU2VhcmNoRGF0YS5hdHRhY2hTY2hlbWEoU2NoZW1hLnNlYXJjaFNjaGVtYSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEluc3RpdHV0aW9uIH0gZnJvbSAnLi4vaW5zdGl0dXRpb24nO1xuaW1wb3J0IHsgU2xpZGVzIH0gZnJvbSAnLi4vc2xpZGVzJztcbmltcG9ydCB7IF9TZXR0aW5ncyB9IGZyb20gJy4uL3NldHRpbmdzJztcbmltcG9ydCB7IFRpdGxlcyB9IGZyb20gJy4uL3RpdGxlcyc7XG5cbk1ldGVvci5wdWJsaXNoKG51bGwsICgpID0+IF9TZXR0aW5ncy5maW5kKHt9KSk7XG5cbk1ldGVvci5wdWJsaXNoKCd0aXRsZXMnLCAoKSA9PiBUaXRsZXMuZmluZCh7fSkpO1xuXG5NZXRlb3IucHVibGlzaCgnc2xpZGVzJywgKCkgPT4gU2xpZGVzLmZpbmQoKS5jdXJzb3IpO1xuTWV0ZW9yLnB1Ymxpc2goJ2xvZ28nLCAoKSA9PiBJbnN0aXR1dGlvbi5maW5kKCkuY3Vyc29yKTtcbiIsImltcG9ydCB7IEZpbGVzQ29sbGVjdGlvbiB9IGZyb20gJ21ldGVvci9vc3RyaW86ZmlsZXMnO1xuXG5leHBvcnQgY29uc3QgSW5zdGl0dXRpb24gPSBuZXcgRmlsZXNDb2xsZWN0aW9uKHtcbiAgY29sbGVjdGlvbk5hbWU6ICdJbnN0aXR1dGlvbicsXG4gIHN0b3JhZ2VQYXRoOiBgJHtwcm9jZXNzLmVudi5QV0R9L3B1YmxpYy91cGxvYWRzL2xvZ29zL2AsXG4gIGFsbG93Q2xpZW50Q29kZTogZmFsc2UsIC8vIERpc2FsbG93IHJlbW92ZSBmaWxlcyBmcm9tIENsaWVudFxuICBvbkJlZm9yZVVwbG9hZChmaWxlKSB7XG4gICAgLy8gQWxsb3cgdXBsb2FkIGZpbGVzIHVuZGVyIDVHYiwgYW5kIG9ubHkgaW4gcG5nL2pwZy9qcGVnIGZvcm1hdHNcbiAgICBpZiAoZmlsZS5zaXplIDw9IDEwMDkxMjAgJiYgL3BuZ3xqcGd8anBlZy9pLnRlc3QoZmlsZS5leHRlbnNpb24pKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuICdQbGVhc2UgdXBsb2FkIGltYWdlLCB3aXRoIHNpemUgZXF1YWwgb3IgbGVzcyB0aGFuIDFNQic7XG4gIH0sXG4gIG9uQWZ0ZXJVcGxvYWQoZmlsZSkge1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIC8vIGNoZWNrIHJlYWwgbWltZXR5cGVcbiAgICAgIGNvbnN0IHsgTWFnaWMsIE1BR0lDX01JTUVfVFlQRSB9ID0gcmVxdWlyZSgnbW1tYWdpYycpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICBjb25zdCBtYWdpYyA9IG5ldyBNYWdpYyhNQUdJQ19NSU1FX1RZUEUpO1xuICAgICAgbWFnaWMuZGV0ZWN0RmlsZShcbiAgICAgICAgZmlsZS5wYXRoLFxuICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnIsIG1pbWVUeXBlKSA9PiB7XG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgICAgaWYgKGVyciB8fCAhfm1pbWVUeXBlLmluZGV4T2YoJ2ltYWdlJykpIHtcbiAgICAgICAgICAgIC8vIGlzIG5vdCBhIHJlYWwgaW1hZ2UgLS0+IGRlbGV0ZVxuICAgICAgICAgICAgdGhpcy5yZW1vdmUoZmlsZS5faWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICApO1xuICAgIH1cbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBfU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzJztcbmltcG9ydCB7IF9TbGlkZXMsIFNsaWRlcyB9IGZyb20gJy4vc2xpZGVzJztcbmltcG9ydCB7IEluc3RpdHV0aW9uIH0gZnJvbSAnLi9pbnN0aXR1dGlvbic7XG5pbXBvcnQgeyBUaXRsZXMgfSBmcm9tICcuL3RpdGxlcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWRkU2xpZGluZyhpZCwgc2t1LCBmaWxlKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2soc2t1LCBTdHJpbmcpO1xuICAgIGNoZWNrKGZpbGUsIE9iamVjdCk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgICAgX1NsaWRlcy5pbnNlcnQoe1xuICAgICAgICBuYW1lOiBza3UsXG4gICAgICAgIGZpbGUsXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgQ3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcblxuICBlZGl0U2xpZGVzKHNsaWRlSWQsIHNsaWRlTmFtZSkge1xuICAgIGNoZWNrKHNsaWRlSWQsIFN0cmluZyk7XG4gICAgY2hlY2soc2xpZGVOYW1lLCBTdHJpbmcpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIFNsaWRlcy51cGRhdGUoeyBfaWQ6IHNsaWRlSWQgfSwgeyAkc2V0OiB7IG5hbWU6IHNsaWRlTmFtZSB9IH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcblxuICByZW1vdmVTbGlkZXMoaWQpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJ10pKSB7XG4gICAgICBTbGlkZXMucmVtb3ZlKGlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIG5vdCBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG5cbiAgdXBkYXRlTG9nbyhpbnN0SWQsIG5hbWUsIHRhZ2xpbmUsIGxvZ28sIGZpbGUpIHtcbiAgICBjaGVjayhpbnN0SWQsIFN0cmluZyk7XG4gICAgY2hlY2sobmFtZSwgU3RyaW5nKTtcbiAgICBjaGVjayh0YWdsaW5lLCBTdHJpbmcpO1xuICAgIGNoZWNrKGxvZ28sIFN0cmluZyk7XG4gICAgY2hlY2soZmlsZSwgT2JqZWN0KTtcblxuICAgIEluc3RpdHV0aW9uLnVwZGF0ZShcbiAgICAgIHsgX2lkOiBpbnN0SWQgfSxcbiAgICAgIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgdGFnbGluZSxcbiAgICAgICAgICBsb2dvLFxuICAgICAgICAgIGZpbGUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICk7XG4gIH0sXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAnaW5zZXJ0LnRpdGxlJyh0aXRsZSwgc3ViX3RpdGxlKSB7XG4gICAgY2hlY2sodGl0bGUsIFN0cmluZyk7XG4gICAgY2hlY2soc3ViX3RpdGxlLCBTdHJpbmcpO1xuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgICBUaXRsZXMuaW5zZXJ0KHtcbiAgICAgIHRpdGxlLFxuICAgICAgc3ViX3RpdGxlLFxuICAgICAgZWRpdGVkQXQ6IHRvZGF5LFxuICAgIH0pO1xuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ3VwZGF0ZS50aXRsZScoaWQsIHRpdGxlLCBzdWIpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayh0aXRsZSwgU3RyaW5nKTtcbiAgICBjaGVjayhzdWIsIFN0cmluZyk7XG4gICAgVGl0bGVzLnVwZGF0ZShcbiAgICAgIHsgX2lkOiBpZCB9LFxuICAgICAge1xuICAgICAgICAkc2V0OiB7IHRpdGxlLCBzdWJfdGl0bGU6IHN1YiwgZWRpdGVkQXQ6IG5ldyBEYXRlKCkgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgfSxcbiAgdXBkYXRlQ29sb3JzKGlkLCBtYWluLCBidXR0b24sIHNpZGViYXIpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhtYWluLCBTdHJpbmcpO1xuICAgIGNoZWNrKGJ1dHRvbiwgTWF0Y2guT25lT2YoT2JqZWN0LCBudWxsLCB1bmRlZmluZWQpKTtcbiAgICBjaGVjayhzaWRlYmFyLCBNYXRjaC5PbmVPZihTdHJpbmcsIG51bGwsIHVuZGVmaW5lZCkpO1xuICAgIF9TZXR0aW5ncy51cGRhdGUoXG4gICAgICB7IF9pZDogaWQgfSxcbiAgICAgIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIG1haW4sXG4gICAgICAgICAgYnV0dG9uLFxuICAgICAgICAgIHNpZGViYXIsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgeyB1cHNlcnQ6IHRydWUgfSxcbiAgICApO1xuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgdXBkYXRlU2V0dGluZ3MoaWQsIG5hbWUsIHRhZywgc2VydmVyLCBpc0NvbmZpZ3VyZWQpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRhZywgU3RyaW5nKTtcbiAgICBjaGVjayhzZXJ2ZXIsIFN0cmluZyk7XG4gICAgY2hlY2soaXNDb25maWd1cmVkLCBCb29sZWFuKTtcbiAgICBfU2V0dGluZ3MudXBkYXRlKFxuICAgICAgeyBfaWQ6IGlkIH0sXG4gICAgICB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICBuYW1lLFxuICAgICAgICAgIHRhZyxcbiAgICAgICAgICBzZXJ2ZXIsXG4gICAgICAgICAgaXNDb25maWd1cmVkLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICApO1xuICB9LFxuICAvLyBwcmV2ZW50IFVwZGF0aW5nIHdoZW4gdXNlciBpcyBub3QgbG9nZ2VkIGluXG4gIHNldERhcmtNb2RlKGlzU2V0KSB7XG4gICAgY2hlY2soaXNTZXQsIEJvb2xlYW4pO1xuICAgIGlmICh0aGlzLnVzZXJJZCkge1xuICAgICAgcmV0dXJuIF9TZXR0aW5ncy51cGRhdGUoXG4gICAgICAgIHt9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgaXNEYXJrOiBpc1NldCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICAvLyB7IHVwc2VydDogdHJ1ZSB9LFxuICAgICAgKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignQXV0aCcsICdZb3UgYXJlIG5vdCBhdXRoZW50aWNhdGVkJyk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IF9TZXR0aW5ncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzZXR0aW5ncycpO1xuXG5fU2V0dGluZ3MuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcbiIsIi8vIGltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IEZpbGVzQ29sbGVjdGlvbiB9IGZyb20gJ21ldGVvci9vc3RyaW86ZmlsZXMnO1xuXG5leHBvcnQgY29uc3QgU2xpZGVzID0gbmV3IEZpbGVzQ29sbGVjdGlvbih7XG4gIGNvbGxlY3Rpb25OYW1lOiAnU2xpZGVzJyxcbiAgc3RvcmFnZVBhdGg6IGAke3Byb2Nlc3MuZW52LlBXRH0vcHVibGljL3VwbG9hZHMvc2xpZGVzL2AsXG4gIGFsbG93Q2xpZW50Q29kZTogZmFsc2UsIC8vIERpc2FsbG93IHJlbW92ZSBmaWxlcyBmcm9tIENsaWVudFxuICBvbkJlZm9yZVVwbG9hZChmaWxlKSB7XG4gICAgLy8gQWxsb3cgdXBsb2FkIGZpbGVzIHVuZGVyIDVHYiwgYW5kIG9ubHkgaW4gcG5nL2pwZy9qcGVnIGZvcm1hdHNcbiAgICBpZiAoZmlsZS5zaXplIDw9IDEwMDkxMjAgJiYgL3BuZ3xqcGd8anBlZy9pLnRlc3QoZmlsZS5leHRlbnNpb24pKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuICdQbGVhc2UgdXBsb2FkIGltYWdlLCB3aXRoIHNpemUgZXF1YWwgb3IgbGVzcyB0aGFuIDFNQic7XG4gIH0sXG4gIG9uQWZ0ZXJVcGxvYWQoZmlsZSkge1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIC8vIGNoZWNrIHJlYWwgbWltZXR5cGVcbiAgICAgIGNvbnN0IHsgTWFnaWMsIE1BR0lDX01JTUVfVFlQRSB9ID0gcmVxdWlyZSgnbW1tYWdpYycpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICBjb25zdCBtYWdpYyA9IG5ldyBNYWdpYyhNQUdJQ19NSU1FX1RZUEUpO1xuICAgICAgbWFnaWMuZGV0ZWN0RmlsZShcbiAgICAgICAgZmlsZS5wYXRoLFxuICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnIsIG1pbWVUeXBlKSA9PiB7XG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgICAgaWYgKGVyciB8fCAhfm1pbWVUeXBlLmluZGV4T2YoJ2ltYWdlJykpIHtcbiAgICAgICAgICAgIC8vIGlzIG5vdCBhIHJlYWwgaW1hZ2UgLS0+IGRlbGV0ZVxuICAgICAgICAgICAgdGhpcy5yZW1vdmUoZmlsZS5faWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICApO1xuICAgIH1cbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5leHBvcnQgY29uc3QgVGl0bGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RpdGxlJyk7XG5cblRpdGxlcy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZSxcbn0pO1xuXG5jb25zdCB0aXRsZVNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0aXRsZTogU3RyaW5nLFxuICBzdWJfdGl0bGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGVkaXRlZEF0OiBEYXRlLFxufSk7XG5UaXRsZXMuYXR0YWNoU2NoZW1hKHRpdGxlU2NoZW1hKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgX1N0YXRpc3RpY3MgfSBmcm9tICcuLi9zdGF0aXN0aWNzJztcblxuTWV0ZW9yLnB1Ymxpc2gobnVsbCwgKCkgPT4gX1N0YXRpc3RpY3MuZmluZCh7fSkpO1xuXG4iLCIvKiBlc2xpbnQgbm8tcGFyYW0tcmVhc3NpZ246ICdvZmYnICovXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IF9TdGF0aXN0aWNzIH0gZnJvbSAnLi4vLi4vYXBpL3N0YXRpc3RpY3Mvc3RhdGlzdGljcyc7XG5cbmNvbnN0IGRiID0geyBzdGF0aXN0aWNzOiBfU3RhdGlzdGljcyB9O1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIERhdGFUb0NTVihjb2xsZWN0aW9uKSB7XG4gICAgY2hlY2soY29sbGVjdGlvbiwgQXJyYXkpO1xuICAgIC8vICB2YXIgY29sbGVjdGlvbiA9IGNvbGxlY3Rpb24uZmluZChxdWVyeSkuZmV0Y2goKTtcbiAgICBjb25zdCBoZWFkaW5nID0gdHJ1ZTsgLy8gT3B0aW9uYWwsIGRlZmF1bHRzIHRvIHRydWVcbiAgICBjb25zdCBkZWxpbWl0ZXIgPSAnLCc7IC8vIE9wdGlvbmFsLCBkZWZhdWx0cyB0byBcIixcIjtcbiAgICByZXR1cm4gZXhwb3J0Y3N2LmV4cG9ydFRvQ1NWKGNvbGxlY3Rpb24sIGhlYWRpbmcsIGRlbGltaXRlcik7XG4gIH0sXG59KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBnZXRDU1ZEYXRhKGNvbGxlY3Rpb24sIHF1ZXJ5LCBtVXNlcikge1xuICAgIGNoZWNrKGNvbGxlY3Rpb24sIFN0cmluZyk7XG4gICAgY2hlY2socXVlcnksIE9iamVjdCk7XG4gICAgY2hlY2sobVVzZXIsIE9iamVjdCk7XG4gICAgY29uc3QgZGF0YSA9IGRiW2NvbGxlY3Rpb25dLmZpbmQocXVlcnkpLmZldGNoKCk7XG5cbiAgICBpZiAoZGF0YS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBkYXRhLmZvckVhY2godiA9PiB7XG4gICAgICB2Lm5hbWUgPSBgJHttVXNlci5wcm9maWxlLm5hbWV9YDtcbiAgICAgIHYuZW1haWwgPSBtVXNlci5lbWFpbHNbMF0uYWRkcmVzcztcbiAgICAgIHYuZ2VuZGVyID0gbVVzZXIucHJvZmlsZS5nZW5kZXI7XG4gICAgfSk7XG5cbiAgICBjb25zdCBoZWFkaW5nID0gdHJ1ZTsgLy8gT3B0aW9uYWwsIGRlZmF1bHRzIHRvIHRydWVcbiAgICBjb25zdCBkZWxpbWl0ZXIgPSAnOyc7IC8vIE9wdGlvbmFsLCBkZWZhdWx0cyB0byBcIixcIjtcbiAgICByZXR1cm4gZXhwb3J0Y3N2LmV4cG9ydFRvQ1NWKGRhdGEsIGhlYWRpbmcsIGRlbGltaXRlcik7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IF9TdGF0aXN0aWNzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N0YXRpc3RpYycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBzeW5jRGF0YSB9IGZyb20gJy4uL3N5bmNEYXRhJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3N5bmNkYXRhJywgKCkgPT4gc3luY0RhdGEuZmluZCh7fSkpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSZXN0aXZ1cyB9IGZyb20gJ21ldGVvci9tcmVzdDpyZXN0aXZ1cyc7XG5pbXBvcnQgeyBSZXNvdXJjZXMsIFJlZmVyZW5jZXMgfSBmcm9tICcuLi9yZXNvdXJjZXMvcmVzb3VyY2VzJztcbmltcG9ydCB7IF9Db3Vyc2VzIH0gZnJvbSAnLi4vY291cnNlcy9jb3Vyc2VzJztcbmltcG9ydCB7IF9TZWFyY2hEYXRhIH0gZnJvbSAnLi4vc2VhcmNoL3NlYXJjaCc7XG5pbXBvcnQgeyBfU3RhdGlzdGljcyB9IGZyb20gJy4uL3N0YXRpc3RpY3Mvc3RhdGlzdGljcyc7XG5pbXBvcnQgeyBUaXRsZXMgfSBmcm9tICcuLi9zZXR0aW5ncy90aXRsZXMnO1xuaW1wb3J0IHsgX1RvcGljcyB9IGZyb20gJy4uL3RvcGljcy90b3BpY3MnO1xuaW1wb3J0IHsgX1VuaXRzIH0gZnJvbSAnLi4vdW5pdHMvdW5pdHMnO1xuLy8gZGlzYWJsZSB1c2VyIGF1dGggZm9yIEdFVFxuXG5jb25zdCBBcGkgPSBuZXcgUmVzdGl2dXMoe1xuICB1c2VEZWZhdWx0QXV0aDogdHJ1ZSxcbiAgcHJldHR5SnNvbjogdHJ1ZSxcbn0pO1xuXG4vLyBHRVQgZW5kcG9pbnQgZm9yIHRoZSByZWZlcmVuY2VzXG5BcGkuYWRkQ29sbGVjdGlvbihSZWZlcmVuY2VzLCB7XG4gIGV4Y2x1ZGVkRW5kcG9pbnRzOiBbJ3B1dCcsICdwb3N0JywgJ2RlbGV0ZSddLFxuICByb3V0ZU9wdGlvbnM6IHtcbiAgICBhdXRoUmVxdWlyZWQ6IHRydWUsXG4gIH0sXG4gIGVuZHBvaW50czoge1xuICAgIGdldDoge1xuICAgICAgYXV0aFJlcXVpcmVkOiB0cnVlLFxuICAgIH0sXG4gIH0sXG59KTtcbi8vIEdFVCBlbmRwb2ludCBmb3Igc2VhcmNoXG5BcGkuYWRkQ29sbGVjdGlvbihfU2VhcmNoRGF0YSwge1xuICBleGNsdWRlZEVuZHBvaW50czogWydwdXQnLCAncG9zdCcsICdkZWxldGUnXSxcbiAgcm91dGVPcHRpb25zOiB7XG4gICAgYXV0aFJlcXVpcmVkOiB0cnVlLFxuICB9LFxuICBlbmRwb2ludHM6IHtcbiAgICBnZXQ6IHtcbiAgICAgIGF1dGhSZXF1aXJlZDogdHJ1ZSxcbiAgICB9LFxuICB9LFxufSk7XG5cbi8vIEdFVCBlbmRwb2ludCBmb3Igc3RhdGlzdGljc1xuXG5BcGkuYWRkQ29sbGVjdGlvbihfU3RhdGlzdGljcywge1xuICBleGNsdWRlZEVuZHBvaW50czogWydwdXQnLCAncG9zdCcsICdkZWxldGUnXSxcbiAgcm91dGVPcHRpb25zOiB7XG4gICAgYXV0aFJlcXVpcmVkOiB0cnVlLFxuICB9LFxuICBlbmRwb2ludHM6IHtcbiAgICBnZXQ6IHtcbiAgICAgIGF1dGhSZXF1aXJlZDogdHJ1ZSxcbiAgICB9LFxuICB9LFxufSk7XG5cbi8vIEdFVCBlbmRwb2ludCBmb3IgdGl0bGVzXG5BcGkuYWRkQ29sbGVjdGlvbihUaXRsZXMsIHtcbiAgZXhjbHVkZWRFbmRwb2ludHM6IFsncHV0JywgJ3Bvc3QnLCAnZGVsZXRlJ10sXG4gIHJvdXRlT3B0aW9uczoge1xuICAgIGF1dGhSZXF1aXJlZDogdHJ1ZSxcbiAgfSxcbiAgZW5kcG9pbnRzOiB7XG4gICAgZ2V0OiB7XG4gICAgICBhdXRoUmVxdWlyZWQ6IHRydWUsXG4gICAgfSxcbiAgfSxcbn0pO1xuXG4vLyBHRVQgZW5kcG9pbnQgZm9yIFRvcGljc1xuQXBpLmFkZENvbGxlY3Rpb24oX1RvcGljcywge1xuICBleGNsdWRlZEVuZHBvaW50czogWydwdXQnLCAncG9zdCcsICdkZWxldGUnXSxcbiAgcm91dGVPcHRpb25zOiB7XG4gICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcbiAgfSxcbiAgZW5kcG9pbnRzOiB7XG4gICAgZ2V0OiB7XG4gICAgICBhdXRoUmVxdWlyZWQ6IGZhbHNlLFxuICAgIH0sXG4gIH0sXG59KTtcbi8vIEdFVCBlbmRwb2ludCBmb3IgVG9waWNzXG5BcGkuYWRkQ29sbGVjdGlvbihfVW5pdHMsIHtcbiAgZXhjbHVkZWRFbmRwb2ludHM6IFsncHV0JywgJ3Bvc3QnLCAnZGVsZXRlJ10sXG4gIHJvdXRlT3B0aW9uczoge1xuICAgIGF1dGhSZXF1aXJlZDogZmFsc2UsXG4gIH0sXG4gIGVuZHBvaW50czoge1xuICAgIGdldDoge1xuICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcbiAgICB9LFxuICB9LFxufSk7XG4vLyBHRVQgZW5kcG9pbnQgZm9yIENPdXJzZXNcbkFwaS5hZGRDb2xsZWN0aW9uKF9Db3Vyc2VzLCB7XG4gIGV4Y2x1ZGVkRW5kcG9pbnRzOiBbJ3B1dCcsICdwb3N0JywgJ2RlbGV0ZSddLFxuICByb3V0ZU9wdGlvbnM6IHtcbiAgICBhdXRoUmVxdWlyZWQ6IGZhbHNlLFxuICB9LFxuICBlbmRwb2ludHM6IHtcbiAgICBnZXQ6IHtcbiAgICAgIGF1dGhSZXF1aXJlZDogZmFsc2UsXG4gICAgfSxcbiAgfSxcbn0pO1xuXG5BcGkuYWRkQ29sbGVjdGlvbihNZXRlb3IudXNlcnMsIHtcbiAgZXhjbHVkZWRFbmRwb2ludHM6IFsncHV0JywgJ3Bvc3QnXSxcbiAgcm91dGVPcHRpb25zOiB7XG4gICAgYXV0aFJlcXVpcmVkOiB0cnVlLFxuICB9LFxuICBlbmRwb2ludHM6IHtcbiAgICBnZXQ6IHtcbiAgICAgIGF1dGhSZXF1aXJlZDogdHJ1ZSxcbiAgICB9LFxuICB9LFxufSk7XG5cbkFwaS5hZGRSb3V0ZShcbiAgJ3Jlc291cmNlcycsXG4gIHsgYXV0aFJlcXVpcmVkOiBmYWxzZSB9LCAvLyB0ZW1wXG4gIHtcbiAgICBnZXQ6IHtcbiAgICAgIGFjdGlvbigpIHtcbiAgICAgICAgY29uc3QgcmVzb3VyY2VzID0gUmVzb3VyY2VzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGlmIChyZXNvdXJjZXMpIHtcbiAgICAgICAgICByZXR1cm4geyBzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogcmVzb3VyY2VzIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgYm9keTogeyBzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ2dldCBtZSB0aHNpJyB9LFxuICAgICAgICB9O1xuICAgICAgfSxcbiAgICB9LFxuICB9LFxuKTtcblxuQXBpLmFkZFJvdXRlKFxuICAncmVmZXJlbmNlcycsXG4gIHsgYXV0aFJlcXVpcmVkOiB0cnVlIH0sXG4gIHtcbiAgICBnZXQ6IHtcbiAgICAgIGFjdGlvbigpIHtcbiAgICAgICAgLy8gdmFyIGFydGljbGUgPSBBcnRpY2xlcy5maW5kT25lKHRoaXMudXJsUGFyYW1zLmlkKTtcbiAgICAgICAgY29uc3QgcmVmZXJlbmNlcyA9IFJlZmVyZW5jZXMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgaWYgKHJlZmVyZW5jZXMpIHtcbiAgICAgICAgICByZXR1cm4geyBzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogcmVmZXJlbmNlcyB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgIGJvZHk6IHsgc3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6IFwiRXJyb3IgaGFwcGVuZWQsIEkgY291bGRuJ3QgZmV0Y2ggdGhlIGRhdGFcIiB9LFxuICAgICAgICB9O1xuICAgICAgfSxcbiAgICB9LFxuICB9LFxuKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IGV4ZWNGaWxlIH0gZnJvbSAnY2hpbGRfcHJvY2Vzcyc7XG5pbXBvcnQgeyBzeW5jRGF0YSB9IGZyb20gJy4vc3luY0RhdGEnO1xuaW1wb3J0ICogYXMgY29uZmlnIGZyb20gJy4uLy4uLy4uL2NvbmZpZy5qc29uJztcbi8vIGNoZWNrIGludGVybmV0IGNvbm5lY3Rpb25cblxuY29uc3QgeyBzZXJ2ZXIgfSA9IGNvbmZpZztcbmNvbnN0IGNvbGxlY3Rpb25zID0gW1xuICAnY291cnNlJyxcbiAgJ3VuaXQnLFxuICAndG9waWMnLFxuICAncmVzb3VyY2VzJyxcbiAgJ3JlZmVyZW5jZXMnLFxuICAnc2VhcmNoJyxcbiAgJ3NlYXJjaCcsXG5dO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGF1dGhlbnRpY2F0ZTogKGVtYWlsLCBwYXNzd29yZCkgPT4ge1xuICAgIGNoZWNrKGVtYWlsLCBTdHJpbmcpO1xuICAgIGNoZWNrKHBhc3N3b3JkLCBTdHJpbmcpO1xuICAgIHJldHVybiBIVFRQLnBvc3QoYCR7c2VydmVyfS9hcGkvbG9naW4vYCwge1xuICAgICAgZGF0YToge1xuICAgICAgICBlbWFpbCxcbiAgICAgICAgcGFzc3dvcmQsXG4gICAgICB9LFxuICAgICAgY29udGVudDoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcsXG4gICAgICB9LFxuICAgIH0pO1xuICB9LFxuXG4gIGdldEFsbENvbGxlY3Rpb25zOiAodG9rZW4sIHVzZXJJZCkgPT4ge1xuICAgIGNoZWNrKHRva2VuLCBTdHJpbmcpO1xuICAgIGNoZWNrKHVzZXJJZCwgU3RyaW5nKTtcbiAgICBjb2xsZWN0aW9ucy5tYXAoY29sbCA9PlxuICAgICAgSFRUUC5nZXQoXG4gICAgICAgIGAke3NlcnZlcn0vYXBpLyR7Y29sbH0vYCxcbiAgICAgICAge1xuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdYLUF1dGgtVG9rZW4nOiB0b2tlbixcbiAgICAgICAgICAgICdYLVVzZXItSWQnOiB1c2VySWQsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgKGVycm9yLCByZXNwb25zZSkgPT4ge1xuICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IucmVhc29uKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocmVzcG9uc2UgJiYgcmVzcG9uc2UuZGF0YSkge1xuICAgICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgICBkYXRhOiB7IGRhdGEgfSxcbiAgICAgICAgICAgIH0gPSByZXNwb25zZTtcbiAgICAgICAgICAgIHN5bmNEYXRhLnVwZGF0ZShcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGU6IGNvbGwsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgICAgY291bnQ6IGRhdGEubGVuZ3RoLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIChlcnIsIHJlcykgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVyci5yZWFzb24pOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgKSk7XG4gIH0sXG4gIC8vIHJlc3RvcmUgdGhlIGR1bXBlZCBmaWxlcyBmcm9tIHRoZSBzZXJ2ZXJcbiAgcmVzdG9yZURiQ2h1bmtzOiAoKSA9PiB7XG4gICAgZXhlY0ZpbGUoXG4gICAgICBgJHtwcm9jZXNzLmVudi5QV0R9L3NjcmlwdHMvaW1wb3J0ZGJzLnNoYCxcbiAgICAgIFtzZXJ2ZXJdLFxuICAgICAgKGVycm9yLCBzdGRvdXQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coc3Rkb3V0KTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgfSxcbiAgICApO1xuICAgIC8vIHJldHVybiByZXNwb25zZTtcbiAgICAvLyByZXR1cm4gZXhlY0ZpbGVTeW5jKGAke3Byb2Nlc3MuZW52LlBXRH0vc2NyaXB0cy9pbXBvcnRkYnMuc2hgLCBbc2VydmVyXSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IHN5bmNEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N5bmNEYXRhJywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IEVKU09OIH0gZnJvbSAnbWV0ZW9yL2Vqc29uJztcbmltcG9ydCB7IF9Vbml0cyB9IGZyb20gJy4uL3VuaXRzL3VuaXRzJztcbmltcG9ydCB7IF9Ub3BpY3MsIF9SZXNvdXJjZXMgfSBmcm9tICcuLi90b3BpY3MvdG9waWNzJztcbi8vIGltcG9ydCB7IF9SZXNvdXJjZXMgfSBmcm9tICcuLi90b3BpY3MvdG9waWNzJztcbi8vIGltcG9ydCB7IF9TZWFyY2hEYXRhIH0gZnJvbSAnLi4vc2VhcmNoL3NlYXJjaCc7XG5pbXBvcnQgeyBfU3RhdGlzdGljcyB9IGZyb20gJy4uL3N0YXRpc3RpY3Mvc3RhdGlzdGljcyc7XG5pbXBvcnQgeyBfRGVsZXRlZCB9IGZyb20gJy4uL0RlbGV0ZWQvZGVsZXRlZCc7XG5pbXBvcnQgeyBfU2V0dGluZ3MgfSBmcm9tICcuLi9zZXR0aW5ncy9zZXR0aW5ncyc7XG5cbi8vIF9Vbml0cyxfVG9waWNzLF9SZXNvdXJjZXMsX1NlYXJjaERhdGEsIF9TdGF0aXN0aWNzICxfRGVsZXRlZCxfRWdyYW5hcnksX1NldHRpbmdzXG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24oKSB7XG4gIGZzID0gTnBtLnJlcXVpcmUoJ2ZzJyk7IC8vZmlsZSBzeXN0ZW0oZnMpXG4gIGh0dHAgPSByZXF1aXJlKCdodHRwJyk7XG4gIHV0aWwgPSByZXF1aXJlKCd1dGlsJyk7XG4gIHJlcXVlc3QgPSByZXF1aXJlKCdyZXF1ZXN0Jyk7XG4gIEZpYmVyID0gcmVxdWlyZSgnZmliZXJzJyk7XG4gIGV4ZWMgPSByZXF1aXJlKCdjaGlsZF9wcm9jZXNzJykuZXhlYztcbiAgLy8gc3lzID0gcmVxdWlyZSgnc3lzJyk7XG4gIC8vIHN1ZG9Db21tYW5kID0gcmVxdWlyZSgnc3Vkby1wcm9tcHQnKTtcblxuICB2YXIgYm9keVBhcnNlciA9IE5wbS5yZXF1aXJlKCdib2R5LXBhcnNlcicpO1xuICBQaWNrZXIubWlkZGxld2FyZShib2R5UGFyc2VyLnVybGVuY29kZWQoeyBleHRlbmRlZDogZmFsc2UgfSkpO1xuICBQaWNrZXIubWlkZGxld2FyZShib2R5UGFyc2VyLmpzb24oKSk7XG5cbiAgdmFyIHBvc3RSb3V0ZXMgPSBQaWNrZXIuZmlsdGVyKGZ1bmN0aW9uKHJlcSwgcmVzKSB7XG4gICAgLy8geW91IGNhbiB3cml0ZSBhbnkgbG9naWMgeW91IHdhbnQuXG4gICAgLy8gYnV0IHRoaXMgY2FsbGJhY2sgZG9lcyBub3QgcnVuIGluc2lkZSBhIGZpYmVyXG4gICAgLy8gYXQgdGhlIGVuZCwgeW91IG11c3QgcmV0dXJuIGVpdGhlciB0cnVlIG9yIGZhbHNlXG4gICAgcmV0dXJuIHJlcS5tZXRob2QgPT0gJ1BPU1QnO1xuICB9KTtcbn0pO1xuXG52YXIgcmVzb3VyY2VTaXplID0gMDtcbnZhciByZXNvdXJjZUluZGV4ID0gMDtcbnZhciByZXNvdXJjZXMgPSBbXTtcbnZhciBmYWlsZWRSZXNvdXJjZXMgPSBbXTtcbnZhciBkb3dubG9hZGVkUmVzb3VyY2VzID0gW107XG52YXIgcmVzb3VyY2VOYW1lID0gJyc7XG52YXIgY2h1bmtTaXplID0gMDtcbnZhciBjaHVua1NpemVEaWZmID0gMDtcbnZhciBpc1N5bmNSdW5pbmcgPSBmYWxzZTtcbnZhciBza2lwcGVkUmVzb3VyY2UgPSBmYWxzZTtcbnZhciByZXNvdXJjZVBhdGggPSBudWxsO1xudmFyIHNjaG9vbCA9IG51bGw7XG5cbmNvbnN0IGZpbGVzID0geyB1bml0OiAnc3luY1VuaXQuanMnLCB0b3BpYzogJ3N5bmNUb3BpYy5qcycsIHJlc291cmNlOiAnc3luY1Jlc291cmNlLmpzJyB9O1xuLy8gcmVtb3ZlZCBlZ3JhbmFyeSBjb2xsZWN0aW9uIHRlbXBvcmFyeVxuY29uc3QgbUNvbGxlY3Rpb25zID0geyB1bml0OiBfVW5pdHMsIHRvcGljOiBfVG9waWNzLCByZXNvdXJjZTogX1Jlc291cmNlcywgZGVsZXRlOiBfRGVsZXRlZCB9O1xuXG52YXIgaG9zdFVybCA9IG51bGw7IC8vJ2h0dHA6Ly8xOTIuMTY4LjguMTUwOjMwMDAvJztcbnZhciBkb3dubG9hZFBhdGggPSBudWxsOyAvLydodHRwOi8vMTkyLjE2OC44LjE1MDozMDAwLyc7XG4vLyBjb25zdCBob3N0VXJsID0gJ2h0dHA6Ly81Mi40Mi4xNi4xMzQvJztcbi8vY29uc3QgaG9zdFVybCA9ICdsb2NhbGhvc3Q6MzAwMC8nO1xuXG5jb25zdCBzeW5jUGF0aCA9IHByb2Nlc3MuZW52LlBXRCArICcvcHVibGljL3N5bmNGaWxlLyc7XG5jb25zdCB1cGxvYWRQYXRoID0gcHJvY2Vzcy5lbnYuUFdEICsgJy9wdWJsaWMvdXBsb2Fkcy8nO1xuY29uc3QgdXBkYXRlUGF0aCA9IHByb2Nlc3MuZW52LlBXRCArICcvcHVibGljL3VwZGF0ZXMvJztcbmNvbnN0IHB1YmxpY1BhdGggPSBwcm9jZXNzLmVudi5QV0QgKyAnL3B1YmxpYy8nO1xuLy9jb25zdCBzY2hvb2wgPSBudWxsOy8vY29uZmlnXG4vL0Nsb3VkXG4vL2NvbnN0IHVwbG9hZFBhdGggPSAnd3d3L21hbm9hcC9idW5kbGUvcHJvZ3JhbXMvd2ViLmJyb3dzZXIvYXBwL3ByaXZhdGUvJztcblxuLy93cml0ZSB0byBzZWN0aW9uXG5NZXRlb3IubWV0aG9kcyh7XG4gIGRlbGV0ZUZpbGU6IGZ1bmN0aW9uKGZpbGUpIHtcbiAgICBjaGVjayhmaWxlLCBTdHJpbmcpO1xuXG4gICAgdmFyIHBhdGggPSB1cGxvYWRQYXRoICsgZmlsZTtcbiAgICB2YXIgZmlsZVN0YXR1cyA9IE1ldGVvci5jYWxsKCdyZXNvdXJjZUV4aXN0cycsIHBhdGgpO1xuXG4gICAgaWYgKGZpbGVTdGF0dXMpIHtcbiAgICAgIGZzLnVubGlua1N5bmMocGF0aCk7XG4gICAgfVxuICB9LFxufSk7XG5cbi8vZ2V0IHN5bmMgQWRkcmVzc1xuTWV0ZW9yLm1ldGhvZHMoe1xuICBnZXRTZXJ2ZXJVcmw6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZXR0aW5nID0gX1NldHRpbmdzLmZpbmRPbmUoeyBsYWJlbDogJ3N5bmNBZGRyZXNzJyB9KTtcbiAgICByZXR1cm4gKGhvc3RVcmwgPSBzZXR0aW5nLnZhbCk7XG4gIH0sXG59KTtcbi8vZ2V0IG9uZSAgc2V0dGluZyB2YWx1ZVxuTWV0ZW9yLm1ldGhvZHMoe1xuICBnZXRTZXR0aW5nOiBmdW5jdGlvbihsYWJlbCkge1xuICAgIHZhciBzZXR0aW5nID0gX1NldHRpbmdzLmZpbmRPbmUoeyBsYWJlbDogbGFiZWwgfSk7XG4gICAgcmV0dXJuIChob3N0VXJsID0gc2V0dGluZy52YWwpO1xuICB9LFxufSk7XG5cbi8vZ2V0IGFsbCBzZXR0aW5nc1xuTWV0ZW9yLm1ldGhvZHMoe1xuICBnZXRTZXR0aW5nczogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNldHRpbmdzID0gX1NldHRpbmdzLmZpbmRPbmUoe30pO1xuICAgIHJldHVybiAoaG9zdFVybCA9IHNldHRpbmdzKTtcbiAgfSxcbn0pO1xuXG4vL2dldCBzY2hvb2xOYW1lXG5NZXRlb3IubWV0aG9kcyh7XG4gIGdldFNjaG9vbE5hbWU6IGZ1bmN0aW9uKCkge1xuICAgIGxldCBzZXR0aW5nID0gX1NldHRpbmdzLmZpbmRPbmUoeyBsYWJlbDogJ3NjaG9vbE5hbWUnIH0pO1xuICAgIGNvbnNvbGUubG9nKHNldHRpbmcpO1xuICAgIHJldHVybiAoc2Nob29sID0gc2V0dGluZy52YWwpO1xuICB9LFxufSk7XG5cbi8vY2hlY2sgZm9yIHVwZGF0ZXNcbk1ldGVvci5tZXRob2RzKHtcbiAgZ2V0U2VydmVyVmVyc2lvbjogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNldHRpbmcgPSBfU2V0dGluZ3MuZmluZE9uZSh7IGxhYmVsOiAndmVyc2lvbicgfSk7XG4gICAgcmV0dXJuIChob3N0VXJsID0gc2V0dGluZy52YWwpO1xuICB9LFxufSk7XG5cbi8vc2VuZCBTdGF0aXN0aWNzXG5NZXRlb3IubWV0aG9kcyh7XG4gIHNlbmRTdGF0aXN0aWNzOiBmdW5jdGlvbihzdGF0aXN0aWNzKSB7XG4gICAgY29uc29sZS5sb2coJ1VSTCA9JyArIGhvc3RVcmwpO1xuICAgIHZhciB1cmwgPSBob3N0VXJsICsgJ3N0YXRzJzsgLy9cImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9zdGF0c1wiO1xuICAgIC8vdmFyIGRhdGEgPSBFSlNPTi5zdHJpbmdpZnkoc3RhdGlzdGljcyk7XG5cbiAgICBIVFRQLmNhbGwoJ1BPU1QnLCB1cmwsIHsgcGFyYW1zOiB7IHN0YXRpc3RpY3M6IHN0YXRpc3RpY3MsIGlzU2Nob29sOiBzY2hvb2wgfSB9LCBmdW5jdGlvbihcbiAgICAgIGVycm9yLFxuICAgICAgcmVzdWx0LFxuICAgICkge1xuICAgICAgY29uc29sZS5sb2codXJsLCByZXN1bHQpO1xuXG4gICAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxufSk7XG5cbi8vc2VuZCB1c2VyIGFjY291bnRzLWJhc2Vcbi8vc2VuZCBTdGF0aXN0aWNzXG5NZXRlb3IubWV0aG9kcyh7XG4gIHNlbmRVc2VyczogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHVybCA9IGhvc3RVcmwgKyAndXNlcnMnOyAvL1wiaHR0cDovL2xvY2FsaG9zdDozMDAwL3N0YXRzXCI7XG4gICAgLy9jb25zb2xlLmxvZyh1c2Vycyk7XG4gICAgdmFyIHVzZXJzRGF0YSA9IE1ldGVvci51c2Vycy5maW5kKHsgJ2VtYWlscy5hZGRyZXNzJzogeyAkbmU6ICdhZG1pbkBhZG1pbi5jb20nIH0gfSk7XG4gICAgdmFyIHVzZXJzID0gW107XG5cbiAgICB1c2Vyc0RhdGEuZm9yRWFjaChmdW5jdGlvbih2KSB7XG4gICAgICB1c2Vycy5wdXNoKHYpO1xuICAgIH0pO1xuICAgIHZhciBzaXplID0gdXNlcnMubGVuZ3RoO1xuICAgIHVzZXJzID0gSlNPTi5zdHJpbmdpZnkodXNlcnMpO1xuXG4gICAgSFRUUC5jYWxsKCdQT1NUJywgdXJsLCB7IHBhcmFtczogeyB1c2VyczogdXNlcnMsIGlzU2Nob29sOiBzY2hvb2wgfSB9LCBmdW5jdGlvbihlcnJvciwgcmVzdWx0KSB7XG4gICAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICBjb25zb2xlLmxvZyh1cmwsIHJlc3VsdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gc2l6ZTtcbiAgfSxcbn0pO1xuXG4vL3NhdmUgU3RhdGlzdGljc1xuTWV0ZW9yLm1ldGhvZHMoe1xuICBpbnNlcnRVc2FnZTogZnVuY3Rpb24oZGF0YSkge1xuICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG4gICAgdmFyIGlkID0gZGF0YS5pZDtcbiAgICB2YXIgbWF0ZXJpYWwgPSBkYXRhLm1hdGVyaWFsO1xuICAgIHZhciB1cmwgPSBkYXRhLnVybDtcbiAgICB2YXIgcGFnZSA9IGRhdGEucGFnZTtcbiAgICB2YXIgdXNlciA9IHRoaXMudXNlcklkID8gZGF0YS51c2VyIDogJ2Fub255bW91cyc7XG4gICAgdmFyIGRhdGUgPSBkYXRhLmRhdGU7XG4gICAgdmFyIF9pZCA9IGlkICsgdXNlcjtcblxuICAgIGlmICghZGF0YS5zdGF0c2cpIHtcbiAgICAgIC8vY2hlY2sgaWYgdXNlciBoYXMgc3RhdGlzdGljcy5cbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICBfaWQ6IHVzZXIsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAncHJvZmlsZS5zdGF0cyc6IDEsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgKGVycm9yLCBzdWNjZXNzKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5sb2coc3VjY2Vzcyk7IC8vVG9ET1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoZGF0YS5mcmVxID09IHVuZGVmaW5lZCkge1xuICAgICAgZnJlcSA9IDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZyZXEgPSBkYXRhLmZyZXE7XG4gICAgfVxuXG4gICAgaWYgKGRhdGEuaXNTY2hvb2wgPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpc1NjaG9vbCA9IHNjaG9vbDtcbiAgICB9XG5cbiAgICBfU3RhdGlzdGljcy51cGRhdGUoXG4gICAgICB7IF9pZDogX2lkIH0sXG4gICAgICB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICBpc1NjaG9vbDogJ2lzU2Nob29sJyxcbiAgICAgICAgICBtYXRlcmlhbCxcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgcGFnZSxcbiAgICAgICAgICBkYXRlLFxuICAgICAgICAgIHVzZXIsXG4gICAgICAgICAgaWQsXG4gICAgICAgIH0sXG4gICAgICAgICRpbmM6IHsgZnJlcSB9LFxuICAgICAgfSxcbiAgICAgIHsgdXBzZXJ0OiB0cnVlIH0sXG4gICAgKTtcbiAgfSxcbn0pO1xuXG4vL3NhdmUgdXNlciBhY2NvdW50cyBzZW50IGZyb20gcmVtb3RlIHNjaG9vbFxuTWV0ZW9yLm1ldGhvZHMoe1xuICBpbnNlcnRVc2VyOiBmdW5jdGlvbihkYXRhLCBpc1NjaG9vbCkge1xuICAgIHZhciBpZCA9IGRhdGEuX2lkO1xuICAgIHZhciBlbWFpbHMgPSBkYXRhLmVtYWlscztcbiAgICB2YXIgcHJvZmlsZSA9IGRhdGEucHJvZmlsZTtcbiAgICBwcm9maWxlWydpc1NjaG9vbCddID0gaXNTY2hvb2w7XG4gICAgcHJvZmlsZS5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgIHsgX2lkOiBpZCB9LFxuICAgICAgeyAkc2V0OiB7IGVtYWlsczogZW1haWxzLCBwcm9maWxlOiBwcm9maWxlIH0gfSxcbiAgICAgIHsgdXBzZXJ0OiB0cnVlIH0sXG4gICAgKTtcbiAgfSxcbn0pO1xuXG4vL2dldEpTT05GaWxlQ29udGVudFxuTWV0ZW9yLm1ldGhvZHMoe1xuICBnZXRTeW5jQ29udGVudDogZnVuY3Rpb24oZmlsZVR5cGUsIGlzU2Nob29sLCByZXNldCkge1xuICAgIHZhciB2YWwgPSBmYWxzZTtcbiAgICB2YXIgc3RhdHVzID0gdHJ1ZTtcbiAgICB2YXIgcmVzdWx0cyA9IG51bGw7XG4gICAgaWYgKG1Db2xsZWN0aW9uc1tmaWxlVHlwZV0gPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9IGVsc2UgaWYgKHJlc2V0KSB7XG4gICAgICB2YWwgPSB0cnVlO1xuICAgICAgc3RhdHVzID0gZmFsc2U7XG4gICAgfVxuXG4gICAgdmFyIGRhdGEgPSBbXTtcbiAgICB2YXIgcXVlcnkgPSB7fTtcblxuICAgIHF1ZXJ5WydzeW5jLicgKyBpc1NjaG9vbF0gPSB2YWw7XG5cbiAgICBpZiAoZmlsZVR5cGUgPT0gJ2VncmFuYXJ5Jykge1xuICAgICAgcmVzdWx0cyA9IG1Db2xsZWN0aW9uc1tmaWxlVHlwZV0uZmluZCh7fSk7XG4gICAgfSBlbHNlIGlmIChmaWxlVHlwZSA9PSAnYWRtaW4nKSB7XG4gICAgICByZXN1bHRzID0gbUNvbGxlY3Rpb25zW2ZpbGVUeXBlXS5maW5kKHt9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzdWx0cyA9IG1Db2xsZWN0aW9uc1tmaWxlVHlwZV0uZmluZCh7IHF1ZXJ5IH0pO1xuICAgIH1cblxuICAgIHJlc3VsdHMuZm9yRWFjaChmdW5jdGlvbih2KSB7XG4gICAgICBsZXQgaWQgPSB2Ll9pZDtcbiAgICAgIGxldCBzeW5jID0gdi5zeW5jO1xuXG4gICAgICBpZiAoc3luYyA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgc3luYyA9IHt9O1xuICAgICAgfVxuXG4gICAgICBzeW5jW2lzU2Nob29sXSA9IHN0YXR1cztcblxuICAgICAgLyp1cGRhdGUgZGJcbiAgICAgbUNvbGxlY3Rpb25zW2ZpbGVUeXBlXS51cGRhdGUoe19pZDppZH0seyRzZXQ6e3N5bmM6e2tpamFiZTpmYWxzZSxraXN1bXU6ZmFsc2V9fX0pO1xuICAgICAqKi9cblxuICAgICAgLy91cGRhdGUgdGhlIGRiLiB0ZWxsIHRoZSBzeXMgdGhhdCB3aGljaCBzY2hvb2wgaGFzIHN5bmNlZFxuICAgICAgbUNvbGxlY3Rpb25zW2ZpbGVUeXBlXS51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogeyBzeW5jIH0gfSk7XG5cbiAgICAgIGRhdGEucHVzaCh2KTtcbiAgICB9KTtcbiAgICAvL2NvbnNvbGUubG9nKFwiREFUQVwiLGRhdGEpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vY29uc29sZS5sb2coSlNPTi5wYXJzZShkYXRhKSk7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH0sXG59KTtcblxuLy8gZ2V0UmVzb3VyY2UgZW5zdXJlcyByZXNvdXJjZSBpcyBhdmFpbGFibGUgb24gc2VydmVyXG5NZXRlb3IubWV0aG9kcyh7XG4gIGdldFJlc291cmNlOiBmdW5jdGlvbihyZXNvdXJjZXNEYXRhKSB7XG4gICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0UmVzb3VyY2UnKTtcbiAgICBjb25zb2xlLmxvZygnSU5ERVggPSAnICsgcmVzb3VyY2VJbmRleCwgJ1JFU09VUkNFUyA9PicgKyByZXNvdXJjZXMubGVuZ3RoKTtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KHJlc291cmNlc0RhdGEpICYmIHJlc291cmNlc0RhdGEubGVuZ3RoID4gMCkge1xuICAgICAgcmVzb3VyY2VJbmRleCA9IDA7XG4gICAgICByZXNvdXJjZXMgPSByZXNvdXJjZXNEYXRhO1xuICAgICAgY29uc29sZS5sb2coJ25ldyAgcmVzb3VyY2VzIGxvYWRlZCA9PT4nICsgcmVzb3VyY2VzLmxlbmd0aCk7XG4gICAgfSBlbHNlIGlmIChyZXNvdXJjZXMubGVuZ3RoID09IDApIHtcbiAgICAgIC8vbm8gcmVzb3VyY2VzIGZvdW5kIHJlc291cmNlcy5sZW5ndGggPCAxICYmIEFycmF5LmlzQXJyYXkocmVzb3VyY2VzRGF0YSlcbiAgICAgIGNvbnNvbGUubG9nKCdubyByZXNvdXJjZXMgZm91bmQgJyk7XG4gICAgICBpc1N5bmNSdW5pbmcgPSBmYWxzZTtcbiAgICAgIHJldHVybjsgLy9yZW1vdmUgaW4gcHJvZHVjdGlvbiBcInx8IHJlc291cmNlSW5kZXggPiAxXCJcbiAgICB9IGVsc2UgaWYgKHJlc291cmNlSW5kZXggPj0gcmVzb3VyY2VzLmxlbmd0aCkge1xuICAgICAgLy9BbGwgcmVzb3VyY2VzIGRvd25sb2FkZWQgICAgICAgICAgICAgICAvL3JlbW92ZSBpbiBwcm9kdWN0aW9uXG4gICAgICBjb25zb2xlLmxvZygnQWxsIHJlc291cmNlcyBkb3dubG9hZGVkID0+ICcgKyByZXNvdXJjZXMubGVuZ3RoKTtcbiAgICAgIGlzU3luY1J1bmluZyA9IGZhbHNlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICghaXNTeW5jUnVuaW5nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ0lOREVYOiAnICsgcmVzb3VyY2VJbmRleCArICcgVE9UQUw6ICcgKyByZXNvdXJjZXMubGVuZ3RoKTtcbiAgICB2YXIgcmVzb3VyY2UgPSByZXNvdXJjZXNbcmVzb3VyY2VJbmRleF07IC8vYXNzaWduIGVhY2ggcmVzb3VjZSBtZXRhLWRhdGEob2JqZWN0KSB0byByZXNvdXJjZSB2YXJpYWJsZVxuICAgIHJlc291cmNlTmFtZSA9IHJlc291cmNlLm5hbWU7XG4gICAgcmVzb3VyY2VTaXplID0gcmVzb3VyY2Uuc2l6ZTtcbiAgICByZXNvdXJjZVBhdGggPSB1cGxvYWRQYXRoICsgcmVzb3VyY2VOYW1lO1xuICAgIGRvd25sb2FkUGF0aCA9IGhvc3RVcmwgKyAndXBsb2Fkcy8nICsgcmVzb3VyY2VOYW1lO1xuICAgIHZhciBmaWxlU3RhdHVzID0gdHJ1ZTsgLy9pZiBzZXQgdG8gZmFsc2UuIGZpbGUgd29uJ3QgYmUgZG93bmxvYWRlZFxuXG4gICAgLy9jaGVja2luZyBpZiBmaWxlIGFscmVhZHkgZXhpc3Qgb24gc2VydmVyXG4gICAgZnMuc3RhdChyZXNvdXJjZVBhdGgsIGZ1bmN0aW9uKGVyciwgc3RhdHMpIHtcbiAgICAgIC8vY2hlY2sgaWYgZmlsZSBhbHJlYWR5IGV4aXN0cyBhbmQgaXMgb2YgdGhlIHNhbWUgc2l6ZVxuICAgICAgaWYgKHN0YXRzICYmIHN0YXRzLnNpemUgPT0gcmVzb3VyY2VTaXplKSB7XG4gICAgICAgIC8vZmlsZSBhbHJlYWR5IGV4aXN0IGFuZCBpcyBvayBza2lwIGZpbGVcbiAgICAgICAgY29uc29sZS5sb2cocmVzb3VyY2VOYW1lICsgJyA9PicgKyBzdGF0cy5zaXplICsgJyA8PT4gJyArIHJlc291cmNlU2l6ZSk7XG4gICAgICAgIHNraXBwZWRSZXNvdXJjZSA9IHRydWU7XG4gICAgICAgIGNvbnNvbGUubG9nKCdza2lwcGVkIHJlc291cmNlICcgKyByZXNvdXJjZVBhdGgpO1xuICAgICAgICByZXNvdXJjZUluZGV4Kys7XG4gICAgICAgIGZpbGVTdGF0dXMgPSBmYWxzZTtcbiAgICAgICAgaXNTeW5jUnVuaW5nID0gZmFsc2U7XG4gICAgICAgIHNraXBwZWRSZXNvdXJjZSA9IHRydWU7XG4gICAgICB9IGVsc2UgaWYgKHN0YXRzICYmIHN0YXRzLnNpemUgIT09IHJlc291cmNlU2l6ZSAmJiAhZXJyKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdCUk9LRU4gRklMRSAnICsgcmVzb3VyY2VOYW1lICsgJyA9PicgKyBzdGF0cy5zaXplICsgJyA8PT4gJyArIHJlc291cmNlU2l6ZSk7XG5cbiAgICAgICAgLy8gZmlsZSBhbHJlYWR5IGV4aXN0IGFuZCBpcyBicm9rZW4gb3IgbmVlZHMgdG8gYmUgcmVwbGFjZWRcbiAgICAgICAgZnMudW5saW5rU3luYyhwYXRoKTsgLy9kZWxldGUgZmlsZSAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuICAgICAgICAvLyBkb3dubG9hZCBtaXNzaW5nIGZpbGVcbiAgICAgICAgZmlsZVN0YXR1cyA9IHRydWU7XG4gICAgICB9IGVsc2UgaWYgKGVyciAmJiBlcnIuZXJybm8gPT09IDM0KSB7XG4gICAgICAgIC8vICBjb25zb2xlLmxvZyhcIkZJTEUgTUlTU0lORyxTVEFUU1wiLHN0YXRzLFwiRVJST1JcIixlcnIpO1xuXG4gICAgICAgIC8vZmlsZSBkb2VzIG5vdCBleGl0IChlcnIgJiYgZXJyLmVycm5vID09PSAzNClcbiAgICAgICAgLy9kb3dubG9hZCBtaXNzaW5nIGZpbGVcbiAgICAgICAgZmlsZVN0YXR1cyA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoaXNTeW5jUnVuaW5nKSB7XG4gICAgICAgIEZpYmVyKGZ1bmN0aW9uKCkge1xuICAgICAgICAgIC8vZG93bmxvYWQgbmV4dCBmaWxlXG4gICAgICAgICAgTWV0ZW9yLmNhbGwoJ2Rvd25sb2FkUmVzb3VyY2UnKTtcbiAgICAgICAgfSkucnVuKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG59KTtcblxuLy9nZXQgUmVzb3VyY2UgcHJvZ2VyZXNzXG5NZXRlb3IubWV0aG9kcyh7XG4gIGdldFJlc291cmNlUHJvZ3Jlc3M6IGZ1bmN0aW9uKHJlc291cmNlc0RhdGEpIHtcbiAgICBpZiAoIWlzU3luY1J1bmluZykge1xuICAgICAgLy9yZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLy8gbGV0IHJlc291cmNlcyA9cmVzb3VyY2VzLmxlbmd0aDtcbiAgICAvL2NvbnNvbGUubG9nKHJlc291cmNlcy5sZW5ndGgpO1xuICAgIHJldHVybiB7XG4gICAgICByZXNvdXJjZU5hbWU6IHJlc291cmNlTmFtZSxcbiAgICAgIHJlc291cmNlU2l6ZTogcmVzb3VyY2VTaXplLFxuICAgICAgY2h1bmtTaXplRGlmZjogY2h1bmtTaXplRGlmZixcbiAgICAgIHJlc291cmNlSW5kZXg6IHJlc291cmNlSW5kZXgsXG4gICAgICBjaHVua1NpemU6IGNodW5rU2l6ZSxcbiAgICAgIHJlc291cmNlczogcmVzb3VyY2VzLmxlbmd0aCxcbiAgICAgIHJlc291cmNlSW5kZXg6IHJlc291cmNlSW5kZXgsXG4gICAgfTtcbiAgfSxcbn0pO1xuXG4vL3Jlc2V0cyBtZXRhIGRhdGEgdG8gZGVmYXVsdHNcbk1ldGVvci5tZXRob2RzKHtcbiAgcmVzZXRSZXNvdXJjZTogZnVuY3Rpb24oKSB7XG4gICAgc2tpcHBlZFJlc291cmNlID0gZmFsc2U7XG4gICAgcmVzb3VyY2VOYW1lID0gJyc7XG4gICAgcmVzb3VyY2VTaXplID0gMDtcbiAgICBjaHVua1NpemUgPSAwO1xuICAgIGNodW5rU2l6ZURpZmYgPSAwO1xuICAgIGlzU3luY1J1bmluZyA9IHRydWU7XG4gIH0sXG59KTtcblxuLy9nZXQgUmVzb3VyY2UgcHJvZ2VyZXNzXG5NZXRlb3IubWV0aG9kcyh7XG4gIHNldFJlc291cmNlOiBmdW5jdGlvbihyZXNvdXJjZSkge1xuICAgIGlmIChyZXNvdXJjZS5wYXRoID09ICd1cGRhdGUnKSB7XG4gICAgICByZXNvdXJjZVBhdGggPSB1cGRhdGVQYXRoICsgcmVzb3VyY2UubmFtZTtcbiAgICB9IGVsc2UgaWYgKHJlc291cmNlLnBhdGggPT0gJ3VwbG9hZCcpIHtcbiAgICAgIHJlc291cmNlUGF0aCA9IHVwbG9hZFBhdGggKyByZXNvdXJjZS5uYW1lO1xuICAgIH0gZWxzZSB7XG4gICAgICBpc1N5bmNSdW5pbmcgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZG93bmxvYWRQYXRoID0gcmVzb3VyY2UuZG93bmxvYWRQYXRoO1xuICAgIHNraXBwZWRSZXNvdXJjZSA9IGZhbHNlO1xuICAgIHJlc291cmNlTmFtZSA9IHJlc291cmNlLm5hbWU7XG4gICAgcmVzb3VyY2VTaXplID0gcmVzb3VyY2Uuc2l6ZTtcbiAgICBjaHVua1NpemUgPSAwO1xuICAgIGNodW5rU2l6ZURpZmYgPSAwO1xuICAgIGlzU3luY1J1bmluZyA9IHRydWU7XG4gIH0sXG59KTtcblxuLy9nZXQgUmVzb3VyY2UgcHJvZ2VyZXNzXG5NZXRlb3IubWV0aG9kcyh7XG4gIGRvd25sb2FkUmVzb3VyY2U6IGZ1bmN0aW9uKCkge1xuICAgIGlmICghaXNTeW5jUnVuaW5nKSB7XG4gICAgICBjb25zb2xlLmxvZygnaXNTeW5jUnVuaW5nIGlzIG5vdCBSdW5pbmcnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygnVVJMID0+JyArIGRvd25sb2FkUGF0aCk7XG5cbiAgICBjb25zb2xlLmxvZyhpc1N5bmNSdW5pbmcsICdkb3dubG9hZGluZy4uLicgKyByZXNvdXJjZU5hbWUpO1xuXG4gICAgdmFyIHVybCA9IGRvd25sb2FkUGF0aDtcbiAgICAvL2NyZWF0ZSBmaWxlIHRvIGRvd25sb2FkXG4gICAgdmFyIGZpbGUgPSBmcy5jcmVhdGVXcml0ZVN0cmVhbShyZXNvdXJjZVBhdGgpO1xuICAgIC8vdmFyIGlzTmV4dCA9ZmFsc2U7XG5cbiAgICB2YXIgcmVxID0gaHR0cC5yZXF1ZXN0KHVybCwgZnVuY3Rpb24ocmVzcG9uc2UpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdyZXF1ZWRzdCBzZW50JyArIHJlc291cmNlTmFtZSk7XG4gICAgICByZXNwb25zZS5vbignZGF0YScsIGZ1bmN0aW9uKGNodW5rKSB7XG4gICAgICAgIC8vY2hlY2sgcHJvZ3Jlc3MuXG4gICAgICAgIGxldCBzaXplID0gY2h1bmsubGVuZ3RoO1xuICAgICAgICAvLyAgICBjb25zb2xlLmxvZygnY2h1bmsgZm91bmQgZm9yID0+ICcrcmVzb3VyY2VOYW1lKycgU0laRSA9PicrcmVzb3VyY2VTaXplKTtcbiAgICAgICAgLy8gIGNvbnNvbGUubG9nKCdjaHVuayBzaXplID0+ICcrc2l6ZSk7XG4gICAgICAgIGNodW5rU2l6ZSArPSBzaXplO1xuICAgICAgICAvLyAgIGNvbnNvbGUubG9nKCdjaHVuayBwcm9ncmVzcyA9PiAnK2NodW5rU2l6ZSk7XG4gICAgICAgIC8vc3RhcnQgIGRvd25sb2FkaW5nIGEgbmV3IGZpbGUgaWYgY3VycmVudCBmaWxlIGlzIGFsbW9zdCBkb25lXG4gICAgICAgIGNodW5rU2l6ZURpZmYgPSBNYXRoLmZsb29yKHJlc291cmNlU2l6ZSAtIGNodW5rU2l6ZSk7XG5cbiAgICAgICAgZmlsZS53cml0ZShjaHVuayk7XG4gICAgICB9KTtcblxuICAgICAgcmVzcG9uc2Uub24oJ2Vycm9yJywgZnVuY3Rpb24oZXJyKSB7XG4gICAgICAgIGZhaWxlZFJlc291cmNlcy5wdXNoKHJlc291cmNlTmFtZSk7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ0VSUk9SIE9OIHJlc3BvbnNlOiAnICsgZXJyKTtcbiAgICAgIH0pO1xuXG4gICAgICByZXNwb25zZS5vbignZW5kJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIGRvd25sb2FkZWRSZXNvdXJjZXMucHVzaChyZXNvdXJjZU5hbWUpO1xuICAgICAgICByZXNvdXJjZUluZGV4Kys7XG4gICAgICAgIGlzU3luY1J1bmluZyA9IGZhbHNlO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdET05FOiAnKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmVxLm9uKCdlcnJvcicsIGUgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ2ZpbGUgbm90IGZvdW5kID0+ICcgKyByZXNvdXJjZU5hbWUgKyAnICcgKyBlLm1lc3NhZ2UpO1xuICAgICAgZmFpbGVkUmVzb3VyY2VzLnB1c2gocmVzb3VyY2VOYW1lKTtcbiAgICAgIHJlc291cmNlSW5kZXgrKztcbiAgICB9KTtcblxuICAgIHJlcS5lbmQoJ2FsbCByZXNvdXJjZWQgZG93bmxvYWRlZCcpO1xuICB9LFxufSk7XG5cbi8vY2hlY2sgaWYgZmlsZSBleGlzdCBvbiB0aGUgc3lzdGVtXG5NZXRlb3IubWV0aG9kcyh7XG4gIHJlc291cmNlRXhpc3RzOiBmdW5jdGlvbihwYXRoKSB7XG4gICAgY2hlY2socGF0aCwgU3RyaW5nKTtcbiAgICB2YXIgc3RhdHVzID0gZmFsc2U7XG5cbiAgICB0cnkge1xuICAgICAgdmFyIHN0YXRzID0gZnMuYWNjZXNzU3luYyhwYXRoKTtcbiAgICAgIHN0YXR1cyA9IHRydWU7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy9jb25zb2xlLmxvZyhlKTtcbiAgICAgIHN0YXR1cyA9IGZhbHNlO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZXR1cm4gc3RhdHVzO1xuICAgIH1cbiAgfSxcbn0pO1xuLy9zeW5jQXBwXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3N5bmNBcHAnLCBmdW5jdGlvbihyZXEsIHJlcywgbmV4dCkge1xuICByZXMuc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCAnKicpO1xuICByZXMud3JpdGVIZWFkKDIwMCk7XG4gIHZhciBmaWxlID0gcmVxLnF1ZXJ5LmZpbGU7XG4gIHZhciBpc1NjaG9vbCA9IHJlcS5xdWVyeS5pc1NjaG9vbDtcbiAgdmFyIHJlc2V0ID0gcmVxLnF1ZXJ5LnJlc2V0O1xuXG4gIGlmIChmaWxlID09IHVuZGVmaW5lZCB8fCBpc1NjaG9vbCA9PSB1bmRlZmluZWQpIHtcbiAgICByZXMuZW5kKCdyZXF1ZXN0IHVuZGVmaW5lZCcpO1xuICB9IGVsc2UgaWYgKHJlc2V0ID09IHVuZGVmaW5lZCkge1xuICAgIHJlc2V0ID0gZmFsc2U7XG4gIH1cblxuICBjb25zb2xlLmxvZygnbGlua2VkJywgZmlsZSk7XG4gIHZhciBjb250ZW50ID0gTWV0ZW9yLmNhbGwoJ2dldFN5bmNDb250ZW50JywgZmlsZSwgaXNTY2hvb2wsIHJlc2V0KTtcbiAgdmFyIGRhdGEgPSBbXTtcbiAgdmFyIGRhdGFKU09OID0gJyc7XG4gIGlmIChmaWxlID09ICdyZXNvdXJjZScpIHtcbiAgICAvL2NoZWNrIHRvIG1ha2Ugc3VyZSB0aGF0IHRoZSBmaWxlIGFjdHVhbGx5IGV4aXN0c1xuICAgIHZhciBjbGVhbkRhdGEgPSBbXTtcbiAgICBjb250ZW50LmZvckVhY2goZnVuY3Rpb24odikge1xuICAgICAgbGV0IHBhdGggPSB1cGxvYWRQYXRoICsgdi5maWxlWyduYW1lJ107XG4gICAgICB2YXIgc3RhdHVzID0gTWV0ZW9yLmNhbGwoJ3Jlc291cmNlRXhpc3RzJywgcGF0aCk7XG4gICAgICAvLyAgY29uc29sZS5sb2coc3RhdHVzKTtcbiAgICAgIGlmIChzdGF0dXMpIHtcbiAgICAgICAgY2xlYW5EYXRhLnB1c2godik7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB2YXIgZGF0YSA9IEpTT04uc3RyaW5naWZ5KGNsZWFuRGF0YSk7XG4gICAgdmFyIGRhdGFKU09OID0gRUpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICB9IGVsc2Uge1xuICAgIHZhciBkYXRhID0gSlNPTi5zdHJpbmdpZnkoY29udGVudCk7XG4gICAgdmFyIGRhdGFKU09OID0gRUpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICB9XG5cbiAgcmVzLmVuZChkYXRhSlNPTik7XG59KTtcblxuLy9yZWNlaXZlIFN0YXRpc3RpY3NcblxuUGlja2VyLnJvdXRlKCcvc3RhdHMvJywgZnVuY3Rpb24ocGFyYW1zLCByZXEsIHJlcywgbmV4dCkge1xuICByZXMuc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCAnKicpO1xuICByZXMud3JpdGVIZWFkKDIwMCk7XG4gIHZhciBzdGF0aXN0aWNzID0gcmVxLmJvZHkuc3RhdGlzdGljcztcbiAgdmFyIGlzU2Nob29sID0gcmVxLmJvZHkuaXNTY2hvb2w7XG4gIC8vY29uc29sZS5sb2coJ21tbW1tbW1tbW1tbW0nKTtcblxuICBpZiAoc3RhdGlzdGljcyA9PSB1bmRlZmluZWQpIHtcbiAgICBjb25zb2xlLmxvZygnU1RBVEFTIEZBSUxFRCcpO1xuICAgIHJlcy5lbmQoJ3JlcXVlc3QgdW5kZWZpbmVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciBzdGF0cyA9IEVKU09OLnBhcnNlKHN0YXRpc3RpY3MpO1xuXG4gIF9TdGF0aXN0aWNzLnJlbW92ZSh7IGlzU2Nob29sOiBpc1NjaG9vbCB9KTsgLy9jbGVhciBvbGQgc3RhdGlzdGljc1xuXG4gIHN0YXRzLmZvckVhY2goZnVuY3Rpb24odiwgaywgYXJyKSB7XG4gICAgTWV0ZW9yLmNhbGwoJ2luc2VydFVzYWdlJywgdiwgdHJ1ZSwgaXNTY2hvb2wpO1xuICB9KTtcblxuICBjb25zb2xlLmxvZygnaW5zZXJ0ZWQgc3RhdGlzdGljcz0+ICcgKyBzdGF0cy5sZW5ndGgpO1xuXG4gIHJlcy5lbmQoJ3N0YXRpc3RpY3Mgc2F2ZWQgdG8gY2xvdWQnKTtcbn0pO1xuXG4vL3JlY2VpdmUgdXNlcnMgYWNjb3VudHNcblBpY2tlci5yb3V0ZSgnL3VzZXJzcycsIGZ1bmN0aW9uKHBhcmFtcywgcmVxLCByZXMsIG5leHQpIHtcbiAgcmVzLnNldEhlYWRlcignQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJywgJyonKTtcbiAgcmVzLndyaXRlSGVhZCgyMDApO1xuICB2YXIgdXNlcnMgPSByZXEuYm9keS51c2VycztcbiAgdmFyIGlzU2Nob29sID0gcmVxLmJvZHkuaXNTY2hvb2w7XG4gIC8vY29uc29sZS5sb2coJ21tbW1tbW1tbW1tbW0nKTtcblxuICAvLyB2YXIgdXNlcnMgPSBFSlNPTi5wYXJzZSh1c2Vycyk7XG4gIHZhciB1c2VycyA9IEpTT04uc3RyaW5naWZ5KHVzZXJzKVxuICAvL2NvbnNvbGUubG9nKHVzZXJzKTtcbiAgaWYgKHVzZXJzID09IHVuZGVmaW5lZCkge1xuICAgIHJlcy5lbmQoJ3JlcXVlc3QgdW5kZWZpbmVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdXNlcnMuZm9yRWFjaChmdW5jdGlvbih2LCBrLCBhcnIpIHtcbiAgICBNZXRlb3IuY2FsbCgnaW5zZXJ0VXNlcicsIHYsIGlzU2Nob29sKTtcbiAgfSk7XG5cbiAgY29uc29sZS5sb2coJ3VzZXJzIGluc2VydGVkPT4gJyArIHVzZXJzLmxlbmd0aCk7XG5cbiAgcmVzLmVuZCgnYWNjb3VudHMgc2F2ZWQgdG8gY2xvdWQnKTtcbn0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIHJlYWRGaWxlOiBmdW5jdGlvbihmaWxlKSB7XG4gICAgdmFyIHBhdGggPSB1cGxvYWRQYXRoICsgZmlsZTtcbiAgICBmcy5vcGVuKHBhdGgsICdyJywgKGVyciwgZmQpID0+IHtcbiAgICAgIC8vIGNvbnNvbGUubG9nKHBhdGgpO1xuICAgICAgaWYgKGVycikge1xuICAgICAgICBpZiAoZXJyLmNvZGUgPT09ICdFTk9FTlQnKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignbXlmaWxlIGRvZXMgbm90IGV4aXN0Jyk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gY29uc29sZS5sb2coJ2ZpbGUnLGZkKTtcbiAgICAgIC8vIHJlYWRNeURhdGEoZmQpO1xuICAgIH0pO1xuXG4gICAgLy8gZnMucmVhZEZpbGUocGRmRmlsZVBhdGgsIChlcnIsIHBkZkJ1ZmZlcikgPT4ge1xuICAgIC8vICAgIGlmICghZXJyKSB7XG4gICAgLy8gICAgICBwZGZQYXJzZXIucGFyc2VCdWZmZXIocGRmQnVmZmVyKTtcbiAgICAvLyAgICB9XG4gICAgLy8gIH0pXG4gIH0sXG59KTtcblxuLy9zeW5jQXBwXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3ZlcnNpb24nLCBmdW5jdGlvbihyZXEsIHJlcywgbmV4dCkge1xuICByZXMuc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCAnKicpO1xuICByZXMud3JpdGVIZWFkKDIwMCk7XG5cbiAgdmFyIHZlcnNpb24gPSBNZXRlb3IuY2FsbCgnZ2V0U2VydmVyVmVyc2lvbicpO1xuXG4gIHJlcy5lbmQodmVyc2lvbik7XG59KTtcblxuLy9nZXQgZmlsZXNpemVcblBpY2tlci5yb3V0ZSgnL2ZpbGVzaXplLycsIGZ1bmN0aW9uKHBhcmFtcywgcmVxLCByZXMsIG5leHQpIHtcbiAgcmVzLnNldEhlYWRlcignQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJywgJyonKTtcbiAgcmVzLndyaXRlSGVhZCgyMDApO1xuICAvLyAvZmlsZVNpemU/ZmlsZT17bmFtZX1cbiAgbGV0IHJlc291cmNlID0gcGFyYW1zLnF1ZXJ5LmZpbGU7XG4gIGxldCBwYXRoID0gcGFyYW1zLnF1ZXJ5LnBhdGg7XG4gIHZhciBmaWxlUGF0aCA9IG51bGw7IC8vc3BlY2lmaWMgcGF0aCBvZiBmaWxlIG9uIHRoZSBzZXJ2ZXJcbiAgY29uc29sZS5sb2cocmVzb3VyY2UpO1xuXG4gIGlmIChyZXNvdXJjZSA9PSB1bmRlZmluZWQgfHwgcGF0aCA9PSB1bmRlZmluZWQpIHtcbiAgICByZXMuZW5kKCdyZXF1ZXN0IHVuZGVmaW5lZCcpO1xuICAgIHJldHVybjtcbiAgfSBlbHNlIGlmIChwYXRoID09ICd1cGRhdGUnKSB7XG4gICAgZmlsZVBhdGggPSB1cGRhdGVQYXRoICsgcmVzb3VyY2U7XG4gIH0gZWxzZSBpZiAocGF0aCA9PSAndXBsb2FkJykge1xuICAgIGZpbGVQYXRoID0gdXBsb2FkUGF0aCArIHJlc291cmNlO1xuICB9IGVsc2Uge1xuICAgIGZpbGVQYXRoID0gcHVibGljUGF0aCArIHJlc291cmNlO1xuICB9XG5cbiAgZnMuc3RhdChmaWxlUGF0aCwgZnVuY3Rpb24oZXJyLCBzdGF0cykge1xuICAgIGlmIChzdGF0cykge1xuICAgICAgcmVzLmVuZCgnJyArIHN0YXRzLnNpemUpO1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXMuZW5kKCcnICsgLTEpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfSk7XG59KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBydW5VcGdyYWRlOiBmdW5jdGlvbihzdWRvUGFzcywgdmVyc2lvbikge1xuICAgIC8vc2ggbWFub2FwLmxpdGUuc2hcbiAgICBjb25zdCBjaGlsZCA9IGV4ZWMoXG4gICAgICAnIGJhc2ggfi9tYW5vYXAubGl0ZS5zaCcsXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdVcGdyYWRlJyxcbiAgICAgIH0sXG4gICAgICAoZXJyb3IsIHN0ZG91dCwgc3RkZXJyKSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvcicsIGVycm9yKTtcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfSBlbHNlIGlmIChzdGRvdXQpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygndXBkYXRlIHN5cy4gdmVyc2lvbicpO1xuICAgICAgICAgIEZpYmVyKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgLy9cbiAgICAgICAgICAgIHZhciBtVmVyc2lvbiA9IHBhcnNlRmxvYXQodmVyc2lvbik7XG4gICAgICAgICAgICB2YXIgbmV3VmVyc2lvbiA9IChtVmVyc2lvbiArIDAuMSkudG9GaXhlZCgxKTtcbiAgICAgICAgICAgIHZhciBzdGF0dXMgPSBNZXRlb3IuY2FsbCgndXBkYXRlU3lzVmVyc2lvbicsIG5ld1ZlcnNpb24pO1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ25ldyB2ZXJzaW9uIGRldGVjdGVkJywgbmV3VmVyc2lvbiwgc3RhdHVzKTtcbiAgICAgICAgICB9KS5ydW4oKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICApO1xuICB9LFxufSk7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgdXBkYXRlU3lzVmVyc2lvbjogZnVuY3Rpb24odmVyc2lvbikge1xuICAgIGN1cnJlbnRWZXIgPSBfU2V0dGluZ3MuZmluZE9uZSh7IGxhYmVsOiAndmVyc2lvbicgfSk7XG4gICAgY29uc29sZS5sb2coJ0N1dXJlbnQgdmVyc2lvbicsIGN1cnJlbnRWZXIsIHZlcnNpb24pO1xuICAgIGlmICh2ZXJzaW9uID4gY3VycmVudFZlci52YWwpIHtcbiAgICAgIF9TZXR0aW5ncy51cGRhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICBsYWJlbDogJ3ZlcnNpb24nLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgdmFsOiB2ZXJzaW9uLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICApO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGBgO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfSxcbn0pO1xuXG4vL3Jlc2V0IHNldHRpbmdzXG5NZXRlb3IubWV0aG9kcyh7XG4gIHJlc2V0U3lzdGVtU2V0dGluZ3M6IGZ1bmN0aW9uKHZlcnNpb24pIHtcbiAgICBfU2V0dGluZ3MucmVtb3ZlKHt9KTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfVG9waWNzIH0gZnJvbSAnLi4vdG9waWNzJztcbmltcG9ydCB7IGlzQXV0aFJlcXVpcmVkIH0gZnJvbSAnLi4vLi4vY29uZmlnL2NvbmZpZyc7XG5cbk1ldGVvci5wdWJsaXNoKCd0b3BpY3MnLCAoKSA9PiB7XG4gIGlmICghaXNBdXRoUmVxdWlyZWQoKSkge1xuICAgIHRoaXMucmVhZHkoKTtcbiAgfVxuICByZXR1cm4gX1RvcGljcy5maW5kKHt9KTtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBfVG9waWNzIH0gZnJvbSAnLi4vdG9waWNzL3RvcGljcyc7XG5pbXBvcnQgeyBSZXNvdXJjZXMgfSBmcm9tICcuLi9yZXNvdXJjZXMvcmVzb3VyY2VzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ3RvcGljLmluc2VydCcoaWQsIHVuaXRJZCwgbmFtZSwgdW5pdCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHVuaXRJZCwgU3RyaW5nKTtcbiAgICBjaGVjayh1bml0LCBTdHJpbmcpO1xuICAgIGNoZWNrKG5hbWUsIFN0cmluZyk7XG4gICAgLy8gY2hlY2ssIE9iamVjdCk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIF9Ub3BpY3MuaW5zZXJ0KHtcbiAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgdW5pdElkLFxuICAgICAgICBuYW1lLFxuICAgICAgICB1bml0LFxuICAgICAgICByZXNvdXJjZXM6IFtdLFxuICAgICAgICBzeW5jOiB7fSxcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBub3QgbWFrZSBjaGFuZ2VzJyk7XG4gICAgfVxuICB9LFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgJ3RvcGljLnVwZGF0ZScoaWQsIHRvcGljKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY2hlY2sodG9waWMsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIF9Ub3BpY3MudXBkYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIG5hbWU6IHRvcGljLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICd0b3BpYy5yZW1vdmUnKGlkKSB7XG4gICAgY2hlY2soaWQsIFN0cmluZyk7XG4gICAgY29uc3QgcmVzb3VyY2VzID0gUmVzb3VyY2VzLmZpbmQoeyAnbWV0YS50b3BpY0lkJzogaWQgfSkuZmV0Y2goKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJ10pICYmICFyZXNvdXJjZXMubGVuZ3RoKSB7XG4gICAgICBfVG9waWNzLnJlbW92ZShpZCk7XG4gICAgfSBlbHNlIGlmIChyZXNvdXJjZXMubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAnc29ycnknLFxuICAgICAgICAnVGhlIHNlbGVjdGVkIHRvcGljIGhhcyByZXNvdXJjZXMgdGhhdCBkZXBlbmQgb24gaXQnLFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignb29wcycsICdZb3UgYXJlIG5vdCBhbGxvd2VkIHRvIG5vdCBtYWtlIGNoYW5nZXMnKTtcbiAgICB9XG4gIH0sXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAnc2luZ2xldG9waWMuaW5zZXJ0JzogZnVuY3Rpb24oX2lkLCB1bml0SWQsIG5hbWUsIHVuaXQpIHtcbiAgICBjaGVjayhfaWQsIFN0cmluZyk7XG4gICAgY2hlY2sodW5pdElkLCBTdHJpbmcpO1xuICAgIGNoZWNrKG5hbWUsIFN0cmluZyk7XG4gICAgY2hlY2sodW5pdCwgU3RyaW5nKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJywgJ2NvbnRlbnQtbWFuYWdlciddKSkge1xuICAgICAgX1RvcGljcy5pbnNlcnQoe1xuICAgICAgICBfaWQsXG4gICAgICAgIHVuaXRJZCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdW5pdCxcbiAgICAgICAgcmVzb3VyY2VzOiBbXSxcbiAgICAgICAgc3luYzoge30sXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5leHBvcnQgY29uc3QgX1RvcGljcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0b3BpYycpO1xuXG5fVG9waWNzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbmNvbnN0IHRvcGljU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHVuaXRJZDogU3RyaW5nLFxuICBuYW1lOiBTdHJpbmcsXG4gIHVuaXQ6IFN0cmluZyxcbiAgcmVzb3VyY2VzOiBBcnJheSxcbiAgJ3Jlc291cmNlcy4kJzogT2JqZWN0LFxuICBzeW5jOiBPYmplY3QsXG4gIGNyZWF0ZWRBdDogRGF0ZSxcbiAgY3JlYXRlZEJ5OiBTdHJpbmcsXG59KTtcblxuX1RvcGljcy5hdHRhY2hTY2hlbWEodG9waWNTY2hlbWEpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfVW5pdHMgfSBmcm9tICcuLi91bml0cyc7XG5pbXBvcnQgeyBpc0F1dGhSZXF1aXJlZCB9IGZyb20gJy4uLy4uL2NvbmZpZy9jb25maWcnO1xuXG4vLyBkb24ndCB1c2UgYXJyb3cgZnVuY3Rpb25zIGhlcmUgYmVjYXVzZSBvZiB0aGUgY29udGV4dFxuTWV0ZW9yLnB1Ymxpc2goJ3NlYXJjaFVuaXRzJywgZnVuY3Rpb24gZ2V0VW5pdHMoY0lkKSB7XG4gIGNoZWNrKGNJZCwgTWF0Y2guT25lT2YoU3RyaW5nLCBudWxsKSk7XG4gIGlmICghaXNBdXRoUmVxdWlyZWQoKSkge1xuICAgIHRoaXMucmVhZHkoKTtcbiAgfVxuICByZXR1cm4gX1VuaXRzLmZpbmQoeyAnZGV0YWlscy5jb3Vyc2VJZCc6IGNJZCwgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndW5pdHMnLCBmdW5jdGlvbiBnZXRBbGxVbml0cygpIHtcbiAgaWYgKCFpc0F1dGhSZXF1aXJlZCgpKSB7XG4gICAgdGhpcy5yZWFkeSgpO1xuICB9XG4gIHJldHVybiBfVW5pdHMuZmluZCh7fSwgeyBmaWVsczogeyBuYW1lOiAxLCB0b3BpY3M6IDEsIGRldGFpbHM6IDEgfSB9KTtcbn0pO1xuXG4vLyBwdWJsaXNoIHVuaXQgbmFtZVxuXG5NZXRlb3IucHVibGlzaCgnaXNIaWdoU2Nob29sLnVuaXRzJywgZnVuY3Rpb24gZ2V0U2VjVW5pdChpZCkge1xuICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgaWYgKGlzQXV0aFJlcXVpcmVkKCkpIHtcbiAgICB0aGlzLnJlYWR5KCk7XG4gIH1cbiAgcmV0dXJuIF9Vbml0cy5maW5kKHsgX2lkOiBpZCB9LCB7IGZpZWxkczogeyBuYW1lOiAxIH0gfSk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IF9Vbml0cyB9IGZyb20gJy4vdW5pdHMnO1xuaW1wb3J0IHsgX1RvcGljcyB9IGZyb20gJy4uL3RvcGljcy90b3BpY3MnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICd1bml0Lmluc2VydCcoaWQsIG5hbWUsIHRvcGljcywgdW5pdERlc2MsIGRldGFpbHMpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRvcGljcywgTWF0Y2guT25lT2YoTnVtYmVyLCBudWxsLCB1bmRlZmluZWQpKTtcbiAgICBjaGVjayh1bml0RGVzYywgU3RyaW5nKTtcbiAgICBjaGVjayhkZXRhaWxzLCBPYmplY3QpO1xuICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsIFsnYWRtaW4nLCAnY29udGVudC1tYW5hZ2VyJ10pKSB7XG4gICAgICBfVW5pdHMuaW5zZXJ0KHtcbiAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdG9waWNzLFxuICAgICAgICB1bml0RGVzYyxcbiAgICAgICAgZGV0YWlscyxcbiAgICAgICAgc3luYzoge30sXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgIH0pO1xuICAgICAgLy8gIFlvdSBjYW4gYWxzbyB0cmlnZ2VyIGlmIHNvbWV0aGluZyB3cm9uZyBoYXBwZW5zXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBub3QgbWFrZSBjaGFuZ2VzJyk7XG4gICAgfVxuICB9LFxuXG4gICd1bml0LnVwZGF0ZScoaWQsIG5hbWUsIGRlc2MpIHtcbiAgICBjaGVjayhpZCwgU3RyaW5nKTtcbiAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuICAgIGNoZWNrKGRlc2MsIFN0cmluZyk7XG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdjb250ZW50LW1hbmFnZXInXSkpIHtcbiAgICAgIF9Vbml0cy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogeyBuYW1lLCB1bml0RGVzYzogZGVzYyB9IH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdvb3BzJywgJ1lvdSBhcmUgbm90IGFsbG93ZWQgdG8gbm90IG1ha2UgY2hhbmdlcycpO1xuICAgIH1cbiAgfSxcbiAgJ3VuaXQucmVtb3ZlJyhpZCkge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgIGNvbnN0IHRvcGljcyA9IF9Ub3BpY3MuZmluZCh7IHVuaXRJZDogaWQgfSkuZmV0Y2goKTtcbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJywgJ2NvbnRlbnQtbWFuYWdlciddKSAmJiAhdG9waWNzLmxlbmd0aCkge1xuICAgICAgX1VuaXRzLnJlbW92ZShpZCk7XG4gICAgfSBlbHNlIGlmICh0b3BpY3MubGVuZ3RoID49IDEpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3NvcnJ5JywgJ1RoZSBzZWxlY3RlZCBjb3Vyc2UgdW5pdCBoYXMgdG9waWNzIHRoYXQgZGVwZW5kIG9uIGl0Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ29vcHMnLCAnWW91IGFyZSBub3QgYWxsb3dlZCB0byBub3QgbWFrZSBjaGFuZ2VzJyk7XG4gICAgfVxuICB9LFxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmV4cG9ydCBjb25zdCBfVW5pdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndW5pdCcsIHsgaWRHZW5lcmF0aW9uOiAnU1RSSU5HJyB9KTtcblxuX1VuaXRzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbmNvbnN0IFNjaGVtYSA9IHt9O1xuXG5TY2hlbWEuRGV0YWlscyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBjb3Vyc2VJZDogU3RyaW5nLFxuICBwcm9ncmFtSWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGxhbmd1YWdlOiBTdHJpbmcsXG59KTtcblxuU2NoZW1hLnVuaXRTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgbmFtZTogU3RyaW5nLFxuICB0b3BpY3M6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHVuaXREZXNjOiBTdHJpbmcsXG4gIGRldGFpbHM6IFNjaGVtYS5EZXRhaWxzLFxuICBjcmVhdGVkQXQ6IERhdGUsXG4gIGNyZWF0ZWRCeTogU3RyaW5nLFxuICBzeW5jOiBPYmplY3QsIC8vIFN5bmMgd2lsbCBoYXZlIHRvIGJlIGRlZmluZWQgd2hlbiBpdCBnZXRzIHByb3BlcnR5IG5hbWVzXG59KTtcblxuX1VuaXRzLmF0dGFjaFNjaGVtYShTY2hlbWEudW5pdFNjaGVtYSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgbG9nZ2VyOiAodGV4dCwgdHlwZSkgPT4ge1xuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG4gICAgY2hlY2sodHlwZSwgU3RyaW5nKTtcbiAgICBjb25zdCBwYXRoID0gYCR7cHJvY2Vzcy5lbnYuUFdEfS8ke3R5cGV9LmxvZ2A7XG4gICAgZnMuYXBwZW5kRmlsZShwYXRoLCB0ZXh0LCAoZXJyKSA9PiB7XG4gICAgICBpZiAoZXJyKSB0aHJvdyBlcnI7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ3RoZSBsb2cgd2FzIHN1Y2Nlc3NmdWxseSB3cml0dGVuJyk7XG4gICAgfSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0ICogYXMgQ29uZmlnIGZyb20gJy4uLy4uLy4uL2NvbmZpZy5qc29uJztcblxuZXhwb3J0IGNvbnN0IENvbmYgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlnJywgeyBpZEdlbmVyYXRpb246ICdTVFJJTkcnIH0pO1xuXG5jb25zdCB7IGlzVXNlckF1dGggfSA9IENvbmZpZztcblxuZXhwb3J0IGZ1bmN0aW9uIGlzQXV0aFJlcXVpcmVkKCkge1xuICByZXR1cm4gaXNVc2VyQXV0aCA/ICEhTWV0ZW9yLnVzZXIoKSA6IHRydWU7XG59XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmV4cG9ydCBjb25zdCBMYW5ndWFnZSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdsYW5ndWFnZScpO1xuXG5jb25zdCBTY2hlbWEgPSB7fTtcblxuU2NoZW1hLmxhbmd1YWdlID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIGxhbmd1YWdlOiBTdHJpbmcsXG59KTtcblxuTGFuZ3VhZ2UuYXR0YWNoU2NoZW1hKFNjaGVtYS5sYW5ndWFnZSk7XG5cbi8vIGV4cG9ydCBjb25zdCB1cGRhdGVMYW5ndWFnZSA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuLy8gICBuYW1lOiAnbGFuZ3VhZ2UudXBkYXRlJyxcbi8vICAgdmFsaWRhdGU6IG51bGwsXG4vLyAgIHJ1bih7IGlkLCBsYW5ndWFnZSB9KSB7XG4vLyAgICAgcmV0dXJuIExhbmd1YWdlLnVwZGF0ZSh7IF9pZDogJzM0NTM0NTczMCcgfSwgeyAkc2V0OiB7IGxhbmd1YWdlIH0gfSwgeyB1cHNlcnQ6IHRydWUgfSk7XG4vLyAgIH0sXG4vLyB9KTtcbiIsImltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgaTE4biBmcm9tICdtZXRlb3IvdW5pdmVyc2U6aTE4bic7XG5pbXBvcnQgeyBMYW5ndWFnZSB9IGZyb20gJy4vbGFuZ3VhZ2UnO1xuXG4vLyB1bml2ZXJzZTppMThuIG9ubHkgYnVuZGxlcyB0aGUgZGVmYXVsdCBsYW5ndWFnZSBvbiB0aGUgY2xpZW50IHNpZGUuXG4vLyBUbyBnZXQgYSBsaXN0IG9mIGFsbCBhdmlhbGJsZSBsYW5ndWFnZXMgd2l0aCBhdCBsZWFzdCBvbmUgdHJhbnNsYXRpb24sXG4vLyBpMThuLmdldExhbmd1YWdlcygpIG11c3QgYmUgY2FsbGVkIHNlcnZlciBzaWRlLlxuY29uc3QgZ2V0TGFuZ3VhZ2VzID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICdsYW5ndWFnZXMuZ2V0QWxsJyxcbiAgdmFsaWRhdGU6IG51bGwsXG4gIHJ1bigpIHtcbiAgICByZXR1cm4gaTE4bi5nZXRMYW5ndWFnZXMoKTtcbiAgfSxcbn0pO1xuXG4vLyBleHBvcnQgY29uc3QgdXBkYXRlTGFuZ3VhZ2UgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbi8vICAgbmFtZTogJ2xhbmd1YWdlLnVwZGF0ZScsXG4vLyAgIHZhbGlkYXRlOiBudWxsLFxuLy8gICBydW4oeyBpZCwgbGFuZ3VhZ2UgfSkge1xuLy8gICAgIHJldHVybiBMYW5ndWFnZS51cGRhdGUoeyBfaWQ6ICczNDUzNDU3MzAnIH0sIHsgJHNldDogeyBsYW5ndWFnZSB9IH0sIHsgdXBzZXJ0OiB0cnVlIH0pO1xuLy8gICB9LFxuLy8gfSk7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgdXBkYXRlTGFuZ3VhZ2UobGFuZ3VhZ2UpIHtcbiAgICBjaGVjayhsYW5ndWFnZSwgU3RyaW5nKTtcbiAgICByZXR1cm4gTGFuZ3VhZ2UudXBkYXRlKHsgX2lkOiAnMzQ1MzQ1NzMwJyB9LCB7ICRzZXQ6IHsgbGFuZ3VhZ2UgfSB9LCB7IHVwc2VydDogdHJ1ZSB9KTtcbiAgfSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBnZXRMYW5ndWFnZXM7XG4iLCIvKiBlc2xpbnQgbm8tdW5kZWY6IDAgKi9cblN5bmNlZENyb24uYWRkKHtcbiAgbmFtZTogJ0RlbGV0ZSBOb3RpZmljYXRpb25zIHRoYXQgYXJlIG9sZGVyIHRoYW4gMzBkYXlzJyxcbiAgc2NoZWR1bGU6IHBhcnNlciA9PiBwYXJzZXIudGV4dCgnZXZlcnkgMjQgaG91cnMnKSxcbiAgam9iOiAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2Ryb3BOb3RpZmljYXRpb25zJyk7XG4gIH0sXG59KTtcbi8vIHN0YXJ0IHRoZSBjcm9uam9iXG5TeW5jZWRDcm9uLnN0YXJ0KCk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IF9TZXR0aW5ncyB9IGZyb20gJy4uLy4uL2FwaS9zZXR0aW5ncy9zZXR0aW5ncyc7XG5cbi8qXG4gIFRoZSBmaWxlIGNvbnRhaW5zIHRoZSBpbml0aWFsIGRhdGFiYXNlIG9mIHRoZSBJbnN0aXR1dGlvbiBhbmQgdGhlIHVzZXJzXG4qL1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBpbml0aWFsaXplIHRoZSBtYWluIGNvbG9yXG4gIGlmICghX1NldHRpbmdzLmZpbmQoKS5jb3VudCgpKSB7XG4gICAgX1NldHRpbmdzLmluc2VydCh7XG4gICAgICBtYWluOiAnIzAwNmI3NicsXG4gICAgICBtYWluRGFyazogJyMwYzBjMGMnLFxuICAgIH0pO1xuICB9XG59KTtcbiIsImltcG9ydCAnLi4vLi4vYXBpL2FjY291bnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvYWNjb3VudHMvYWNjb3VudCc7XG5pbXBvcnQgJy4uLy4uL2FwaS9hY2NvdW50cy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL2NvdXJzZXMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9jb3Vyc2VzL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdW5pdHMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS91bml0cy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL3RvcGljcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL3RvcGljcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL3Jlc291cmNlcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL3Jlc291cmNlcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL3NldHRpbmdzL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc2V0dGluZ3MvbWV0aG9kcyc7XG5pbXBvcnQgJy4vaW5pdCc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ib29rbWFya3MvbWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ib29rbWFya3Mvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ub3RpZmljYXRpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvbm90aWZpY2F0aW9ucy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9mZWVkYmFjay9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL2ZlZWRiYWNrL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc2VhcmNoL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc2VhcmNoL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc3RhdGlzdGljcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL3N0YXRpc3RpY3MvY3N2TWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9zeW5jL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc3luYy9zeW5jRmlsZSc7XG5pbXBvcnQgJy4uLy4uL2FwaS9EZWxldGVkL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvRGVsZXRlZC9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL2V4dGVybmFsbGluay9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL2V4dGVybmFsbGluay9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL3N5bmMvZW5kcG9pbnQnO1xuaW1wb3J0ICcuLi8uLi9hcGkvc3luYy9zZXJ2ZXIvc3luYyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9jcm9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9sYW5ndWFnZXMvbWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9Mb2cvbG9nZ2VyJztcbiIsIi8qIGVzbGludCBvbmUtdmFyOiAnb2ZmJywgbm8tY29uc29sZTogJ29mZicgICovXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJztcbmltcG9ydCAqIGFzIGNvbmZpZyBmcm9tICcuLi9jb25maWcuanNvbic7XG5cbmNvbnN0IHBhdGggPSBgJHtwcm9jZXNzLmVudi5QV0R9L2NvbmZpZy5qc29uYDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBhZGRDb25maWc6IChuYW1lLCB0YWcsIGF1dGgsIGlzSGlnaFNjaG9vbCwgc2VydmVyKSA9PiB7XG4gICAgY2hlY2sobmFtZSwgU3RyaW5nKTtcbiAgICBjaGVjayh0YWcsIFN0cmluZyk7XG4gICAgY2hlY2soYXV0aCwgQm9vbGVhbik7XG4gICAgY2hlY2soc2VydmVyLCBTdHJpbmcpO1xuICAgIGNoZWNrKGlzSGlnaFNjaG9vbCwgTWF0Y2guT25lT2YoQm9vbGVhbiwgbnVsbCkpO1xuICAgIC8vIGNoZWNrKHNldCwgQm9vbGVhbik7XG5cbiAgICBjb25zdCBpc1NldCA9IGNvbmZpZy5pc0NvbmZpZ3VyZWQ7XG4gICAgbGV0IG5ld0NvbmZpZztcbiAgICBpZiAoaXNTZXQpIHtcbiAgICAgIG5ld0NvbmZpZyA9IHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdGFnLFxuICAgICAgICBpc1VzZXJBdXRoOiBhdXRoLFxuICAgICAgICBpc0hpZ2hTY2hvb2w6IGNvbmZpZy5pc0hpZ2hTY2hvb2wsXG4gICAgICAgIGlzQ29uZmlndXJlZDogdHJ1ZSxcbiAgICAgICAgc2VydmVyLFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmV3Q29uZmlnID0ge1xuICAgICAgICBuYW1lLFxuICAgICAgICB0YWcsXG4gICAgICAgIGlzVXNlckF1dGg6IGF1dGgsXG4gICAgICAgIGlzSGlnaFNjaG9vbCxcbiAgICAgICAgaXNDb25maWd1cmVkOiB0cnVlLFxuICAgICAgICBzZXJ2ZXIsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGxldCB0aXRsZTtcbiAgICBsZXQgc3ViVGl0bGU7XG4gICAgY2hlY2sobmV3Q29uZmlnLCBPYmplY3QpO1xuXG4gICAgZnMud3JpdGVGaWxlKFxuICAgICAgcGF0aCxcbiAgICAgIEpTT04uc3RyaW5naWZ5KG5ld0NvbmZpZywgbnVsbCwgMiksXG4gICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KGVyciA9PiB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAgICAgJ3NvbWV0aGluZyB3cm9uZyBoYXBwZW5lZCcsXG4gICAgICAgICAgICBcIkNvdWxkbid0IHdyaXRlIHRvIHRoZSBmaWxlXCIsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDcmVhdGUgYSBjb25maWcgZnJvbSBoZXJlXG4gICAgICAgIGlmIChpc0hpZ2hTY2hvb2wpIHtcbiAgICAgICAgICB0aXRsZSA9ICdTdWJqZWN0cyc7XG4gICAgICAgICAgc3ViVGl0bGUgPSAnVW5pdHMnO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRpdGxlID0gJ0NvdXJzZXMnO1xuICAgICAgICAgIHN1YlRpdGxlID0gJ1VuaXRzJztcbiAgICAgICAgfVxuICAgICAgICBNZXRlb3IuY2FsbCgnaW5zZXJ0LnRpdGxlJywgdGl0bGUsIHN1YlRpdGxlLCBlcnJvciA9PiB7XG4gICAgICAgICAgZXJyb3IgPyBjb25zb2xlLmVycihlcnJvci5yZWFzb24pIDogY29uc29sZS5sb2coJ1NhdmVkIHRpdGxlcycpO1xuICAgICAgICB9KTtcbiAgICAgIH0pLFxuICAgICk7XG4gIH0sXG59KTtcbiIsIi8qIGVzbGludCBuby1jb25zb2xlOiAnb2ZmJyAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgZnMgZnJvbSAnZnMtZXh0cmEnO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIGNvbnN0IGN1cnJlbnRQYXRoID0gYCR7cHJvY2Vzcy5lbnYuUFdEfS9wdWJsaWMvc3BhcmtlZC5wbmdgO1xuICBjb25zdCBuZXdQYXRoID0gYCR7cHJvY2Vzcy5lbnYuUFdEfS9wdWJsaWMvdXBsb2Fkcy9zcGFya2VkLnBuZ2A7XG4gIHRyeSB7XG4gICAgaWYgKGZzLnN0YXRTeW5jKGN1cnJlbnRQYXRoKSkge1xuICAgICAgZnMuY29weShjdXJyZW50UGF0aCwgbmV3UGF0aClcbiAgICAgICAgLnRoZW4oKCkgPT4gY29uc29sZS5sb2coJycpKVxuICAgICAgICAuY2F0Y2goZXJyID0+IGNvbnNvbGUuZXJyb3IoZXJyKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUubG9nKCdubyBzdWNoIGZpbGUgZXhpc3RzIScpO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihlcnIpO1xuICB9XG59KTtcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9zdGFydHVwL3NlcnZlci9yZWdpc3Rlci1hcGknO1xuaW1wb3J0ICcuL2luaXQnO1xuaW1wb3J0ICcuL2NvbmZpZy5qcyc7XG4iXX0=
